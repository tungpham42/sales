<?php
/**
 * Plugin Name: Soft AI Chat (All-in-One)
 * Plugin URI:  https://soft.io.vn/soft-ai-chat
 * Description: AI Chat Widget & Sales Bot. Supports RAG + WooCommerce + Coupons + VietQR/PayPal + Facebook/Zalo + Live Chat + Canned Responses + Auto Suggestions + Group Quantity + Analytics + Referrer URL tracking + Device & Country filter + Voice Chat + Realtime JSON RAG + Pre-chat Leads Form.
 * Version:     3.9.2
 * Author:      Tung Pham
 * License:     GPL-2.0+
 * Text Domain: soft-ai-chat
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// ==============================================================================
// 1. LICENSE VERIFICATION API
// ==============================================================================

function soft_ai_chat_verify_license( $license_key, $force_check = false ) {
    $transient_key = 'soft_ai_chat_license_' . md5( $license_key );
    
    if ( ! $force_check ) {
        $cached_status = get_transient( $transient_key );
        if ( false !== $cached_status ) {
            return $cached_status;
        }
    }

    $site_url = home_url();
    $parsed_url = wp_parse_url( $site_url );
    $domain = isset( $parsed_url['host'] ) ? $parsed_url['host'] : '';
    $domain = preg_replace( '/^www\./', '', $domain );

    $api_url = 'https://license.soft.io.vn/api/verify-license';

    $response = wp_remote_post( $api_url, array(
        'timeout'     => 15,
        'headers'     => array(
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json'
        ),
        'body'        => wp_json_encode( array(
            'licenseKey' => sanitize_text_field( $license_key ),
            'domain'     => $domain,
        ) ),
    ) );

    if ( is_wp_error( $response ) ) {
        return array( 'valid' => false, 'message' => 'Lỗi kết nối: ' . $response->get_error_message() );
    }

    $response_code = wp_remote_retrieve_response_code( $response );
    $body          = wp_remote_retrieve_body( $response );
    $data          = json_decode( $body, true );

    $result = array(
        'valid'   => false,
        'message' => isset( $data['message'] ) ? $data['message'] : 'Lỗi không xác định.',
    );

    if ( $response_code === 200 && ! empty( $data['valid'] ) ) {
        $result['valid'] = true;
    }

    set_transient( $transient_key, $result, 12 * HOUR_IN_SECONDS );
    return $result;
}

// ==============================================================================
// 2. ADMIN LICENSE SETTINGS PAGE
// ==============================================================================

function soft_ai_chat_license_menu_only() {
    add_menu_page('Bản quyền Soft AI', 'Bản quyền AI Chat', 'manage_options', 'soft-ai-chat-license', 'soft_ai_chat_license_page', 'dashicons-lock', 80);
}

function soft_ai_chat_license_page() {
    if ( isset( $_POST['soft_ai_chat_save_license'] ) && check_admin_referer( 'soft_ai_chat_save_nonce' ) ) {
        $license_key = sanitize_text_field( $_POST['soft_ai_chat_license_key'] );
        update_option( 'soft_ai_chat_license_key', $license_key );
        
        $verification = soft_ai_chat_verify_license( $license_key, true );
        
        if ( $verification['valid'] ) {
            echo '<div class="notice notice-success is-dismissible"><p>Kích hoạt bản quyền thành công!</p></div>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>Lỗi: ' . esc_html( $verification['message'] ) . '</p></div>';
        }
    }

    $current_key = get_option( 'soft_ai_chat_license_key', '' );
    ?>
    <div class="wrap">
        <h1>Cấu hình bản quyền Soft AI Chat</h1>
        <form method="post" action="">
            <?php wp_nonce_field( 'soft_ai_chat_save_nonce' ); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Mã bản quyền</th>
                    <td>
                        <input type="text" name="soft_ai_chat_license_key" value="<?php echo esc_attr( $current_key ); ?>" class="regular-text" autocomplete="off" />
                        <p class="description">Nhập mã bản quyền hợp lệ để mở khóa các tính năng của AI Chat.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button( 'Lưu bản quyền', 'primary', 'soft_ai_chat_save_license' ); ?>
        </form>
    </div>
    <?php
}

function soft_ai_chat_no_key_notice() {
    echo '<div class="notice notice-warning"><p><strong>Soft AI Chat</strong> cần có mã bản quyền hợp lệ để hoạt động. Vui lòng <a href="' . esc_url( admin_url( 'admin.php?page=soft-ai-chat-license' ) ) . '">nhập mã tại đây</a>.</p></div>';
}

// ==============================================================================
// 3. PLUGIN INITIALIZATION & ENFORCEMENT
// ==============================================================================

register_activation_hook(__FILE__, 'soft_ai_chat_activate');

add_action( 'plugins_loaded', 'soft_ai_chat_init' );
function soft_ai_chat_init() {
    $license_key = get_option( 'soft_ai_chat_license_key' );
    
    if ( ! $license_key ) {
        add_action( 'admin_notices', 'soft_ai_chat_no_key_notice' );
        add_action( 'admin_menu', 'soft_ai_chat_license_menu_only' );
        return;
    }

    $status = soft_ai_chat_verify_license( $license_key );

    if ( $status['valid'] ) {
        add_action('admin_menu', 'soft_ai_chat_add_admin_menu');
        add_action('admin_init', 'soft_ai_chat_settings_init');
        add_action('admin_enqueue_scripts', 'soft_ai_chat_admin_enqueue');
        add_action('update_option_soft_ai_chat_settings', 'soft_ai_clear_all_caches_on_save', 10, 2);
        
        add_action('wp_ajax_sac_get_sessions', 'soft_ai_ajax_get_sessions');
        add_action('wp_ajax_sac_get_messages', 'soft_ai_ajax_get_messages');
        add_action('wp_ajax_sac_send_reply', 'soft_ai_ajax_send_reply');
        add_action('wp_ajax_sac_delete_conversation', 'soft_ai_ajax_delete_conversation');
        add_action('wp_ajax_sac_get_canned_msgs', 'soft_ai_ajax_get_canned_msgs'); 
        
        add_filter('cron_schedules', 'soft_ai_add_cron_interval');
        if (!wp_next_scheduled('soft_ai_transcript_cron_hook')) {
            wp_schedule_event(time(), 'soft_ai_5min', 'soft_ai_transcript_cron_hook');
        }
        add_action('soft_ai_transcript_cron_hook', 'soft_ai_process_transcripts');
        
        add_action('rest_api_init', 'soft_ai_chat_register_rest_routes');
        
        add_action('wp_footer', 'soft_ai_chat_inject_widget');
        add_action('wp_footer', 'soft_ai_social_widgets_render');
    } else {
        add_action( 'admin_notices', function() use ( $status ) {
            echo '<div class="notice notice-error"><p><strong>Soft AI Chat xác thực thất bại:</strong> ' . esc_html( $status['message'] ) . '</p></div>';
        });
        add_action( 'admin_menu', 'soft_ai_chat_license_menu_only' );
    }
}

function soft_ai_chat_register_rest_routes() {
    register_rest_route('soft-ai-chat/v1', '/ask', [
        'methods' => 'POST',
        'callback' => 'soft_ai_chat_handle_widget_request',
        'permission_callback' => '__return_true',
    ]);
    register_rest_route('soft-ai-chat/v1', '/poll', [
        'methods' => 'POST',
        'callback' => 'soft_ai_chat_poll_messages',
        'permission_callback' => '__return_true',
    ]);
    register_rest_route('soft-ai-chat/v1', '/submit-lead', [
        'methods' => 'POST',
        'callback' => 'soft_ai_chat_submit_lead',
        'permission_callback' => '__return_true',
    ]);
    register_rest_route('soft-ai-chat/v1', '/webhook/facebook/(?P<channel_id>\d+)', [
        'methods' => ['GET', 'POST'],
        'callback' => 'soft_ai_chat_webhook_facebook',
        'permission_callback' => '__return_true',
    ]);
    register_rest_route('soft-ai-chat/v1', '/webhook/zalo/(?P<channel_id>\d+)', [
        'methods' => 'POST',
        'callback' => 'soft_ai_chat_webhook_zalo',
        'permission_callback' => '__return_true',
    ]);
}

// ---------------------------------------------------------
// 0. ACTIVATION: CREATE DATABASE TABLES
// ---------------------------------------------------------

function soft_ai_chat_activate() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    $table_logs = $wpdb->prefix . 'soft_ai_chat_logs';
    $sql_logs = "CREATE TABLE $table_logs (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        user_ip varchar(100) DEFAULT '' NOT NULL,
        provider varchar(50) DEFAULT '' NOT NULL,
        model varchar(100) DEFAULT '' NOT NULL,
        question text NOT NULL,
        answer longtext NOT NULL,
        source varchar(50) DEFAULT 'widget' NOT NULL, 
        is_read tinyint(1) DEFAULT 0 NOT NULL,
        current_url varchar(500) DEFAULT '' NOT NULL,
        referrer_url varchar(500) DEFAULT '' NOT NULL,
        device varchar(50) DEFAULT '' NOT NULL,
        country varchar(50) DEFAULT '' NOT NULL,
        PRIMARY KEY  (id),
        KEY time (time),
        KEY user_ip (user_ip)
    ) $charset_collate;";
    dbDelta($sql_logs);

    $table_canned = $wpdb->prefix . 'soft_ai_canned_msgs';
    $sql_canned = "CREATE TABLE $table_canned (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        shortcut varchar(50) NOT NULL,
        content text NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id)
    ) $charset_collate;";
    dbDelta($sql_canned);

    $table_stats = $wpdb->prefix . 'soft_ai_chat_stats';
    $sql_stats = "CREATE TABLE $table_stats (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        date_day date NOT NULL,
        user_ip varchar(100) NOT NULL,
        is_taken_over tinyint(1) DEFAULT 0 NOT NULL,
        ai_msgs int(11) DEFAULT 0 NOT NULL,
        admin_msgs int(11) DEFAULT 0 NOT NULL,
        ai_orders int(11) DEFAULT 0 NOT NULL,
        first_user_time datetime DEFAULT NULL,
        first_admin_time datetime DEFAULT NULL,
        last_admin_time datetime DEFAULT NULL,
        transcript_sent tinyint(1) DEFAULT 0 NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY ip_date (date_day, user_ip)
    ) $charset_collate;";
    dbDelta($sql_stats);

    $table_rag = $wpdb->prefix . 'soft_ai_rag_docs';
    $sql_rag = "CREATE TABLE $table_rag (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        title varchar(255) NOT NULL,
        source_type varchar(50) NOT NULL,
        source_url text NOT NULL,
        content longtext NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id)
    ) $charset_collate;";
    dbDelta($sql_rag);

    $table_channels = $wpdb->prefix . 'soft_ai_social_channels';
    $sql_channels = "CREATE TABLE $table_channels (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        platform varchar(50) NOT NULL,
        name varchar(255) NOT NULL,
        page_id varchar(255) DEFAULT '' NOT NULL,
        access_token varchar(500) DEFAULT '' NOT NULL,
        verify_token varchar(255) DEFAULT '' NOT NULL,
        is_active tinyint(1) DEFAULT 1 NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id)
    ) $charset_collate;";
    dbDelta($sql_channels);

    $table_leads = $wpdb->prefix . 'soft_ai_leads';
    $sql_leads = "CREATE TABLE $table_leads (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name varchar(100) NOT NULL,
        phone varchar(20) NOT NULL,
        ip_address varchar(100) DEFAULT '' NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id)
    ) $charset_collate;";
    dbDelta($sql_leads);
}

// ---------------------------------------------------------
// 0.5. STATS HELPER 
// ---------------------------------------------------------

function soft_ai_update_stats_table($ip, $event_type) {
    global $wpdb;
    $table = $wpdb->prefix . 'soft_ai_chat_stats';
    $date = current_time('Y-m-d');
    $now = current_time('mysql');
    
    $wpdb->query($wpdb->prepare("INSERT IGNORE INTO $table (date_day, user_ip) VALUES (%s, %s)", $date, $ip));
    
    if ($event_type === 'user_msg') {
        $wpdb->query($wpdb->prepare("UPDATE $table SET first_user_time = IFNULL(first_user_time, %s), transcript_sent = 0 WHERE date_day = %s AND user_ip = %s", $now, $date, $ip));
    } elseif ($event_type === 'ai_reply') {
        $wpdb->query($wpdb->prepare("UPDATE $table SET ai_msgs = ai_msgs + 1, transcript_sent = 0 WHERE date_day = %s AND user_ip = %s", $date, $ip));
    } elseif ($event_type === 'admin_reply') {
        $wpdb->query($wpdb->prepare("UPDATE $table SET admin_msgs = admin_msgs + 1, first_admin_time = IFNULL(first_admin_time, %s), last_admin_time = %s, transcript_sent = 0 WHERE date_day = %s AND user_ip = %s", $now, $now, $date, $ip));
    } elseif ($event_type === 'takeover') {
        $wpdb->query($wpdb->prepare("UPDATE $table SET is_taken_over = 1, transcript_sent = 0 WHERE date_day = %s AND user_ip = %s", $date, $ip));
    } elseif ($event_type === 'ai_order') {
        $wpdb->query($wpdb->prepare("UPDATE $table SET ai_orders = ai_orders + 1 WHERE date_day = %s AND user_ip = %s", $date, $ip));
    }
}

// ---------------------------------------------------------
// 0.6. DEVICE & COUNTRY HELPER
// ---------------------------------------------------------

function soft_ai_get_device() {
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (preg_match('/Mobile|Android|iP(hone|od)|IEMobile|BlackBerry|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/i', $ua)) {
        return 'Mobile';
    }
    if (preg_match('/Tablet|iPad|Playbook|Silk/i', $ua)) {
        return 'Tablet';
    }
    return 'Desktop';
}

function soft_ai_get_country() {
    if (!empty($_SERVER['HTTP_CF_IPCOUNTRY'])) return $_SERVER['HTTP_CF_IPCOUNTRY'];
    if (!empty($_SERVER['HTTP_X_COUNTRY_CODE'])) return $_SERVER['HTTP_X_COUNTRY_CODE'];
    return '';
}

// ---------------------------------------------------------
// 1. SETTINGS & ADMIN MENU
// ---------------------------------------------------------

function soft_ai_clear_all_caches_on_save($old_value, $value) {
    if (function_exists('rocket_clean_domain')) rocket_clean_domain();
    if (function_exists('w3tc_flush_all')) w3tc_flush_all();
    if (function_exists('wp_cache_clear_cache')) wp_cache_clear_cache();
    if (class_exists('LiteSpeed\Purge')) \LiteSpeed\Purge::purge_all();
    elseif (has_action('litespeed_purge_all')) do_action('litespeed_purge_all');
    if (class_exists('autoptimizeCache')) autoptimizeCache::clearall();
    if (class_exists('WpFastestCache')) {
        $wpfc = new WpFastestCache();
        $wpfc->deleteCache(true);
    }
}

function soft_ai_chat_add_admin_menu() {
    add_menu_page('AI Chat', 'AI Chat', 'manage_options', 'soft-ai-chat', 'soft_ai_chat_options_page', 'dashicons-format-chat', 80);
    add_submenu_page('soft-ai-chat', 'Kênh mạng xã hội', '🌐 Kênh mạng xã hội', 'manage_options', 'soft-ai-social-channels', 'soft_ai_social_channels_page');
    add_submenu_page('soft-ai-chat', 'Live Chat (Hỗ trợ)', '🟢 Livechat', 'manage_options', 'soft-ai-live-chat', 'soft_ai_live_chat_page');
    add_submenu_page('soft-ai-chat', 'Dữ liệu RAG', '📚 Dữ liệu RAG', 'manage_options', 'soft-ai-rag', 'soft_ai_rag_page');
    add_submenu_page('soft-ai-chat', 'Lịch sử chat', 'Lịch sử chat', 'manage_options', 'soft-ai-chat-history', 'soft_ai_chat_history_page');
    add_submenu_page('soft-ai-chat', 'Leads Khách Hàng', '📝 Leads', 'manage_options', 'soft-ai-leads', 'soft_ai_leads_page');
    add_submenu_page('soft-ai-chat', 'Câu trả lời mẫu', 'Câu trả lời mẫu', 'manage_options', 'soft-ai-canned-responses', 'soft_ai_canned_responses_page');
    add_submenu_page('soft-ai-chat', 'Thống kê', '📊 Thống kê', 'manage_options', 'soft-ai-chat-stats', 'soft_ai_chat_stats_page');
    add_submenu_page('soft-ai-chat', 'Cài đặt', 'Cài đặt', 'manage_options', 'soft-ai-chat', 'soft_ai_chat_options_page');
    add_submenu_page('soft-ai-chat', 'Bản quyền', '🔑 Bản quyền', 'manage_options', 'soft-ai-chat-license', 'soft_ai_chat_license_page');
}

function soft_ai_chat_admin_enqueue($hook_suffix) {
    if ($hook_suffix === 'toplevel_page_soft-ai-chat') {
        wp_enqueue_media();
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        wp_add_inline_script('jquery', "
            jQuery(document).ready(function($){ 
                function toggleFields() {
                    var provider = $('#soft_ai_provider_select').val();
                    $('.api-key-row').closest('tr').hide();
                    $('.row-' + provider).closest('tr').show();
                }
                $('#soft_ai_provider_select').change(toggleFields);
                toggleFields();
                $('.soft-ai-color-field').wpColorPicker();

                $('.soft-ai-upload-btn').on('click', function(e) {
                    e.preventDefault();
                    var btn = $(this);
                    var targetId = btn.data('target');
                    var custom_uploader = wp.media({
                        title: 'Chọn hình ảnh',
                        button: { text: 'Sử dụng ảnh này' },
                        multiple: false
                    })
                    .on('select', function() {
                        var attachment = custom_uploader.state().get('selection').first().toJSON();
                        $('#' + targetId).val(attachment.url);
                        $('#' + targetId + '_preview').attr('src', attachment.url).show();
                        btn.siblings('.soft-ai-remove-btn').show();
                    })
                    .open();
                });

                $('.soft-ai-remove-btn').on('click', function(e) {
                    e.preventDefault();
                    var targetId = $(this).data('target');
                    $('#' + targetId).val('');
                    $('#' + targetId + '_preview').hide();
                    $(this).hide();
                });
            });
        ");
    }
}

function soft_ai_chat_settings_init() {
    register_setting('softAiChat', 'soft_ai_chat_settings');

    add_settings_section('soft_ai_chat_main', __('Cấu hình chung & AI', 'soft-ai-chat'), null, 'softAiChat');
    add_settings_field('save_history', __('Lưu lịch sử chat', 'soft-ai-chat'), 'soft_ai_render_checkbox', 'softAiChat', 'soft_ai_chat_main', ['field' => 'save_history']);
    add_settings_field('admin_email_notify', __('Email thông báo quản trị viên', 'soft-ai-chat'), 'soft_ai_render_text', 'softAiChat', 'soft_ai_chat_main', ['field' => 'admin_email_notify', 'desc' => 'Địa chỉ email nhận thông báo khi có tin nhắn mới từ khách.']);
    add_settings_field('provider', __('Chọn nhà cung cấp AI', 'soft-ai-chat'), 'soft_ai_chat_provider_render', 'softAiChat', 'soft_ai_chat_main');
    add_settings_field('groq_api_key', __('Khóa API Groq', 'soft-ai-chat'), 'soft_ai_render_password', 'softAiChat', 'soft_ai_chat_main', ['field' => 'groq_api_key', 'class' => 'row-groq']);
    add_settings_field('openai_api_key', __('Khóa API OpenAI', 'soft-ai-chat'), 'soft_ai_render_password', 'softAiChat', 'soft_ai_chat_main', ['field' => 'openai_api_key', 'class' => 'row-openai']);
    add_settings_field('gemini_api_key', __('Khóa API Google Gemini', 'soft-ai-chat'), 'soft_ai_render_password', 'softAiChat', 'soft_ai_chat_main', ['field' => 'gemini_api_key', 'class' => 'row-gemini']);
    add_settings_field('claude_api_key', __('Khóa API Claude', 'soft-ai-chat'), 'soft_ai_render_password', 'softAiChat', 'soft_ai_chat_main', ['field' => 'claude_api_key', 'class' => 'row-claude']);
    add_settings_field('model', __('Tên mô hình AI', 'soft-ai-chat'), 'soft_ai_render_text', 'softAiChat', 'soft_ai_chat_main', ['field' => 'model', 'default' => 'openai/gpt-oss-120b','desc' => 'Đề xuất: <code>openai/gpt-oss-120b</code> (Groq), <code>gpt-4o-mini</code> (OpenAI), <code>gemini-1.5-flash</code> (Gemini), <code>claude-sonnet-4-20250514</code> (Claude)']);
    add_settings_field('temperature', __('Độ sáng tạo', 'soft-ai-chat'), 'soft_ai_render_range', 'softAiChat', 'soft_ai_chat_main', ['field' => 'temperature', 'default' => 0.5, 'step' => 0.1, 'min' => 0, 'max' => 2]);
    add_settings_field('max_tokens', __('Số Token tối đa', 'soft-ai-chat'), 'soft_ai_render_number', 'softAiChat', 'soft_ai_chat_main', ['field' => 'max_tokens', 'default' => 4096]);
    add_settings_field('system_prompt', __('Tính cách tùy chỉnh', 'soft-ai-chat'), 'soft_ai_render_textarea', 'softAiChat', 'soft_ai_chat_main', ['field' => 'system_prompt']);
    add_settings_field('admin_timeout', __('Thời gian chờ Admin (phút)', 'soft-ai-chat'), 'soft_ai_render_number', 'softAiChat', 'soft_ai_chat_main', ['field' => 'admin_timeout', 'default' => 10, 'min' => 1, 'desc' => 'Thời gian AI tạm dừng chat tự động sau khi Nhân viên đã vào hỗ trợ (cho phép AI và Human cùng tham gia).']);
    add_settings_field('transcript_timeout', __('Gửi email lịch sử chat sau (phút)', 'soft-ai-chat'), 'soft_ai_render_number', 'softAiChat', 'soft_ai_chat_main', ['field' => 'transcript_timeout', 'default' => 0, 'min' => 0, 'desc' => 'Gửi email toàn bộ lịch sử chat nếu khách ngừng nhắn tin sau khoảng thời gian này (Nhập 0 để tắt).']);
    
    add_settings_section('soft_ai_chat_payment', __('Tích hợp thanh toán (Chỉ trong Chat)', 'soft-ai-chat'), null, 'softAiChat');
    add_settings_field('vietqr_bank', __('Mã ngân hàng VietQR', 'soft-ai-chat'), 'soft_ai_render_text', 'softAiChat', 'soft_ai_chat_payment', ['field' => 'vietqr_bank']);
    add_settings_field('vietqr_acc', __('Số tài khoản VietQR', 'soft-ai-chat'), 'soft_ai_render_text', 'softAiChat', 'soft_ai_chat_payment', ['field' => 'vietqr_acc']);
    add_settings_field('vietqr_name', __('Tên chủ tài khoản (Tùy chọn)', 'soft-ai-chat'), 'soft_ai_render_text', 'softAiChat', 'soft_ai_chat_payment', ['field' => 'vietqr_name']);
    add_settings_field('paypal_me', __('Tên người dùng PayPal.me', 'soft-ai-chat'), 'soft_ai_render_text', 'softAiChat', 'soft_ai_chat_payment', ['field' => 'paypal_me']);

    add_settings_section('soft_ai_chat_ui', __('Giao diện người dùng', 'soft-ai-chat'), null, 'softAiChat');
    add_settings_field('chat_title', __('Tiêu đề cửa sổ chat', 'soft-ai-chat'), 'soft_ai_render_text', 'softAiChat', 'soft_ai_chat_ui', ['field' => 'chat_title', 'default' => 'Trợ lý AI']);
    add_settings_field('welcome_msg', __('Tin nhắn chào mừng', 'soft-ai-chat'), 'soft_ai_render_text', 'softAiChat', 'soft_ai_chat_ui', ['field' => 'welcome_msg', 'default' => 'Xin chào! Bạn cần tìm gì ạ?', 'width' => '100%']);
    
    add_settings_field('enable_pre_chat', __('Bật form trước khi chat', 'soft-ai-chat'), 'soft_ai_render_checkbox', 'softAiChat', 'soft_ai_chat_ui', ['field' => 'enable_pre_chat', 'desc' => 'Bật form yêu cầu điền Tên và SĐT trước khi bắt đầu chat.']);
    add_settings_field('pre_chat_msg', __('Tin nhắn trước khi chat', 'soft-ai-chat'), 'soft_ai_render_text', 'softAiChat', 'soft_ai_chat_ui', ['field' => 'pre_chat_msg', 'default' => 'Vui lòng điền thông tin để bắt đầu chat', 'width' => '100%']);

    add_settings_field('input_placeholder', __('Placeholder ô nhập liệu', 'soft-ai-chat'), 'soft_ai_render_text', 'softAiChat', 'soft_ai_chat_ui', ['field' => 'input_placeholder', 'default' => 'Hỏi gì đó...']);
    add_settings_field('button_text', __('Nội dung nút bấm', 'soft-ai-chat'), 'soft_ai_render_text', 'softAiChat', 'soft_ai_chat_ui', ['field' => 'button_text', 'default' => '➤', 'width' => '100px']);
    
    add_settings_field('trigger_image', __('Tải lên icon tùy chỉnh', 'soft-ai-chat'), 'soft_ai_render_media', 'softAiChat', 'soft_ai_chat_ui', ['field' => 'trigger_image', 'desc' => 'Tải lên icon từ Media. Nếu có ảnh, ảnh này sẽ ghi đè lên mục "Trigger Icon" (Text/Emoji) bên dưới.']);
    
    add_settings_field('trigger_icon', __('Icon nút mở chat', 'soft-ai-chat'), 'soft_ai_render_text', 'softAiChat', 'soft_ai_chat_ui', ['field' => 'trigger_icon', 'default' => '💬', 'width' => '100px', 'desc' => 'Sử dụng text hoặc URL. Bỏ trống nếu muốn dùng ảnh tải lên ở trên.']);
    add_settings_field('trigger_border_radius', __('Bo góc nút mở chat', 'soft-ai-chat'), 'soft_ai_render_text', 'softAiChat', 'soft_ai_chat_ui', ['field' => 'trigger_border_radius', 'default' => '50%', 'width' => '100px', 'desc' => 'e.g., 50% or 8px']);
    add_settings_field('trigger_bg_transparent', __('Nền nút mở chat trong suốt', 'soft-ai-chat'), 'soft_ai_render_checkbox', 'softAiChat', 'soft_ai_chat_ui', ['field' => 'trigger_bg_transparent']);
    
    add_settings_field('theme_color', __('Màu chủ đề', 'soft-ai-chat'), 'soft_ai_render_color', 'softAiChat', 'soft_ai_chat_ui', ['field' => 'theme_color', 'default' => '#027DDD']);
    add_settings_field('bg_color', __('Màu nền', 'soft-ai-chat'), 'soft_ai_render_color', 'softAiChat', 'soft_ai_chat_ui', ['field' => 'bg_color', 'default' => '#ffffff']);
    add_settings_field('text_color', __('Màu chữ', 'soft-ai-chat'), 'soft_ai_render_color', 'softAiChat', 'soft_ai_chat_ui', ['field' => 'text_color', 'default' => '#333333']);

    add_settings_field('pos_bottom', __('Vị trí cách dưới', 'soft-ai-chat'), 'soft_ai_render_text', 'softAiChat', 'soft_ai_chat_ui', ['field' => 'pos_bottom', 'default' => '20px', 'width' => '100px']);
    add_settings_field('pos_right', __('Vị trí cách phải', 'soft-ai-chat'), 'soft_ai_render_text', 'softAiChat', 'soft_ai_chat_ui', ['field' => 'pos_right', 'default' => '20px', 'width' => '100px']);
    add_settings_field('pos_left', __('Vị trí cách trái', 'soft-ai-chat'), 'soft_ai_render_text', 'softAiChat', 'soft_ai_chat_ui', ['field' => 'pos_left', 'default' => 'auto', 'width' => '100px']);
    add_settings_field('clear_on_close', __('Xóa chat khi đóng cửa sổ', 'soft-ai-chat'), 'soft_ai_render_checkbox', 'softAiChat', 'soft_ai_chat_ui', ['field' => 'clear_on_close']);
}

function soft_ai_render_media($args) {
    $options = get_option('soft_ai_chat_settings');
    $val = $options[$args['field']] ?? '';
    echo '<div style="display:flex; align-items:center; gap: 10px;">';
    echo '<input type="hidden" name="soft_ai_chat_settings['.$args['field'].']" id="soft_ai_'.$args['field'].'" value="' . esc_attr($val) . '" />';
    echo '<img src="' . esc_url($val) . '" id="soft_ai_'.$args['field'].'_preview" style="max-width:50px; max-height:50px; border:1px solid #ccc; border-radius:5px; object-fit:cover; display:' . ($val ? 'block' : 'none') . ';" />';
    echo '<button type="button" class="button soft-ai-upload-btn" data-target="soft_ai_'.$args['field'].'">Chọn ảnh</button>';
    echo '<button type="button" class="button soft-ai-remove-btn" data-target="soft_ai_'.$args['field'].'" style="display:' . ($val ? 'inline-block' : 'none') . ';">Xóa ảnh</button>';
    echo '</div>';
    if(isset($args['desc'])) echo "<p class='description'>{$args['desc']}</p>";
}

function soft_ai_render_sep() { echo ''; }
function soft_ai_render_text($args) {
    $options = get_option('soft_ai_chat_settings');
    $val = $options[$args['field']] ?? ($args['default'] ?? '');
    $width = $args['width'] ?? '400px';
    echo "<input type='text' name='soft_ai_chat_settings[{$args['field']}]' value='" . esc_attr($val) . "' style='width: {$width};'>";
    if(isset($args['desc'])) echo "<p class='description'>{$args['desc']}</p>";
}
function soft_ai_render_textarea($args) {
    $options = get_option('soft_ai_chat_settings');
    $val = $options[$args['field']] ?? '';
    echo "<textarea name='soft_ai_chat_settings[{$args['field']}]' rows='5' style='width: 100%;'>" . esc_textarea($val) . "</textarea>";
    if(isset($args['desc'])) echo "<p class='description'>{$args['desc']}</p>";
}
function soft_ai_render_password($args) {
    $options = get_option('soft_ai_chat_settings');
    $val = $options[$args['field']] ?? '';
    $cls = $args['class'] ?? '';
    echo "<div class='api-key-row {$cls}'><input type='password' name='soft_ai_chat_settings[{$args['field']}]' value='" . esc_attr($val) . "' style='width:400px;'>";
    if(isset($args['desc'])) echo "<p class='description'>{$args['desc']}</p>";
    echo "</div>";
}
function soft_ai_render_number($args) {
    $options = get_option('soft_ai_chat_settings');
    $val = $options[$args['field']] ?? ($args['default'] ?? 0);
    $step = $args['step'] ?? 1;
    $min = $args['min'] ?? 0;
    $max = $args['max'] ?? 99999;
    echo "<input type='number' step='{$step}' min='{$min}' max='{$max}' name='soft_ai_chat_settings[{$args['field']}]' value='" . esc_attr($val) . "' style='width:100px;'>";
    if(isset($args['desc'])) echo "<p class='description'>{$args['desc']}</p>";
}
function soft_ai_render_range($args) {
    $options = get_option('soft_ai_chat_settings');
    $val = $options[$args['field']] ?? ($args['default'] ?? 0);
    $step = $args['step'] ?? 1;
    $min = $args['min'] ?? 0;
    $max = $args['max'] ?? 100;
    $id = 'soft-ai-range-' . $args['field'];
    echo "<input type='range' id='{$id}' step='{$step}' min='{$min}' max='{$max}' name='soft_ai_chat_settings[{$args['field']}]' value='" . esc_attr($val) . "' style='width:300px; vertical-align: middle;' oninput=\"document.getElementById('{$id}-output').textContent = this.value;\">";
    echo " <output id='{$id}-output' style='display:inline-block; min-width:30px; font-weight:600;'>" . esc_html($val) . "</output>";
    if(isset($args['desc'])) echo "<p class='description'>{$args['desc']}</p>";
}
function soft_ai_render_checkbox($args) {
    $options = get_option('soft_ai_chat_settings');
    $val = isset($options[$args['field']]) ? $options[$args['field']] : '0';
    echo '<label><input type="checkbox" name="soft_ai_chat_settings['.$args['field'].']" value="1" ' . checked($val, '1', false) . ' /> Enable</label>';
    if(isset($args['desc'])) echo "<p class='description'>{$args['desc']}</p>";
}
function soft_ai_render_color($args) {
    $options = get_option('soft_ai_chat_settings');
    $val = $options[$args['field']] ?? ($args['default'] ?? '');
    echo '<input type="text" name="soft_ai_chat_settings['.$args['field'].']" value="' . esc_attr($val) . '" class="soft-ai-color-field" />';
}

function soft_ai_chat_provider_render() {
    $options = get_option('soft_ai_chat_settings');
    $val = $options['provider'] ?? 'groq';
    ?>
    <select name="soft_ai_chat_settings[provider]" id="soft_ai_provider_select">
        <option value="groq" <?php selected($val, 'groq'); ?>>Groq (Llama 3/Mixtral)</option>
        <option value="openai" <?php selected($val, 'openai'); ?>>OpenAI (GPT-4o/Turbo)</option>
        <option value="gemini" <?php selected($val, 'gemini'); ?>>Google Gemini</option>
        <option value="claude" <?php selected($val, 'claude'); ?>>Claude (Anthropic)</option>
    </select>
    <?php
}

function soft_ai_chat_options_page() {
    if (!current_user_can('manage_options')) return;
    ?>
    <div class="wrap">
        <h1>Cấu hình AI Chat</h1>
        <form action='options.php' method='post'>
            <?php
            settings_fields('softAiChat');
            do_settings_sections('softAiChat');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// ---------------------------------------------------------
// 1.1. RAG KNOWLEDGE BASE PAGE 
// ---------------------------------------------------------

function soft_ai_extract_text_from_file($tmp_name, $ext) {
    $ext = strtolower($ext);
    $content = '';
    
    if (in_array($ext, ['txt', 'csv'])) {
        $content = file_get_contents($tmp_name);
    } elseif (in_array($ext, ['docx', 'xlsx', 'pptx'])) {
        if (class_exists('ZipArchive')) {
            $zip = new ZipArchive();
            if ($zip->open($tmp_name) === TRUE) {
                for ($i = 0; $i < $zip->numFiles; $i++) {
                    $name = $zip->getNameIndex($i);
                    if ($ext == 'docx' && $name == 'word/document.xml') {
                        $content .= strip_tags(str_replace(['<w:p>', '</w:p>'], [" ", "\n"], $zip->getFromIndex($i)));
                    }
                    if ($ext == 'xlsx' && $name == 'xl/sharedStrings.xml') {
                        $content .= strip_tags(str_replace(['<t>', '</t>'], [" ", " "], $zip->getFromIndex($i)));
                    }
                    if ($ext == 'pptx' && strpos($name, 'ppt/slides/slide') !== false) {
                        $content .= strip_tags(str_replace(['<a:t>', '</a:t>'], [" ", "\n"], $zip->getFromIndex($i))) . "\n";
                    }
                }
                $zip->close();
            }
        }
    } elseif ($ext === 'pdf') {
        $raw = file_get_contents($tmp_name);
        if (preg_match_all('/stream[\r\n]*(.*?)[\r\n]*endstream/is', $raw, $matches)) {
            foreach ($matches[1] as $stream) {
                $uncompressed = @gzuncompress($stream);
                if ($uncompressed !== false) {
                    $stream = $uncompressed;
                }
                if (preg_match_all('/\[(.*?)\]\s*TJ/s', $stream, $tj_arrays)) {
                    foreach ($tj_arrays[1] as $tj) {
                        if (preg_match_all('/\((.*?)\)/s', $tj, $inner)) {
                            $content .= implode(" ", $inner[1]) . " ";
                        }
                    }
                }
                if (preg_match_all('/\((.*?)\)\s*T[jJ]/s', $stream, $tj_matches)) {
                    $content .= implode(" ", $tj_matches[1]) . " ";
                }
                if (preg_match_all('/<([0-9a-fA-F]+)>\s*T[jJ]/s', $stream, $hex_matches)) {
                    foreach ($hex_matches[1] as $hex) {
                        $content .= @hex2bin($hex) . " ";
                    }
                }
            }
        }
        $content = preg_replace_callback('/\\\([0-7]{1,3})/', function($m) { return chr(octdec($m[1])); }, $content);
        $content = str_replace(['\(', '\)', '\\\\'], ['(', ')', '\\'], $content);
        $content = preg_replace('/\s+/', ' ', $content);
    } else {
        $raw = file_get_contents($tmp_name);
        $content = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]+/', ' ', $raw);
        $content = strip_tags($content);
    }
    return mb_substr(trim($content), 0, 100000); 
}

function soft_ai_extract_text_from_google($url) {
    $content = '';
    if (preg_match('/docs\.google\.com\/(document|spreadsheets|presentation)\/d\/([a-zA-Z0-9-_]+)/', $url, $matches)) {
        $type = $matches[1];
        $id = $matches[2];
        $export_url = '';

        if ($type == 'document') {
            $export_url = "https://docs.google.com/document/d/{$id}/export?format=txt";
        } elseif ($type == 'spreadsheets') {
            $export_url = "https://docs.google.com/spreadsheets/d/{$id}/export?format=csv";
        } elseif ($type == 'presentation') {
            $export_url = "https://docs.google.com/presentation/d/{$id}/export/txt";
        }

        if ($export_url) {
            $response = wp_remote_get($export_url, ['timeout' => 30]);
            if (!is_wp_error($response)) {
                $content = wp_remote_retrieve_body($response);
                if ($type == 'spreadsheets' || $type == 'presentation') {
                    $content = strip_tags($content);
                }
            }
        }
    }
    return mb_substr(trim($content), 0, 100000);
}

function soft_ai_rag_page() {
    if (!current_user_can('manage_options')) return;
    global $wpdb;
    $table_rag = $wpdb->prefix . 'soft_ai_rag_docs';

    if (isset($_GET['action']) && $_GET['action'] == 'delete_rag' && isset($_GET['id'])) {
        $del_id = intval($_GET['id']);
        $wpdb->delete($table_rag, ['id' => $del_id]);
        echo '<div class="updated"><p>Đã xóa dữ liệu thành công.</p></div>';
    }

    if (isset($_POST['sac_save_rag']) && check_admin_referer('sac_save_rag_nonce')) {
        $title = sanitize_text_field($_POST['title']);
        $gdrive_url = esc_url_raw($_POST['gdrive_url']);
        $json_endpoint_url = esc_url_raw($_POST['json_endpoint_url']);
        $extracted_content = '';
        $type = '';
        $source_url = '';

        if (!empty($gdrive_url)) {
            $extracted_content = soft_ai_extract_text_from_google($gdrive_url);
            $type = 'google_drive';
            $source_url = $gdrive_url;
            if (!$title) $title = "Tài liệu Google Drive";
        } 
        elseif (!empty($json_endpoint_url)) {
            $response = wp_remote_get($json_endpoint_url, ['timeout' => 30]);
            if (!is_wp_error($response)) {
                $body = wp_remote_retrieve_body($response); 
                $data = json_decode($body, true);
                if (is_array($data)) { 
                    $clean_data = wp_strip_all_tags(json_encode($data, JSON_UNESCAPED_UNICODE)); 
                    $extracted_content = mb_substr(trim($clean_data), 0, 100000); 
                    $type = 'json_realtime'; 
                    $source_url = $json_endpoint_url;
                    if (!$title) $title = "JSON API: " . parse_url($json_endpoint_url, PHP_URL_HOST); 
                }
            } else {
                echo '<div class="error"><p>Lỗi kết nối đến JSON API endpoint.</p></div>';
            }
        }
        elseif (!empty($_FILES['rag_file']['name'])) {
            require_once( ABSPATH . 'wp-admin/includes/image.php' );
            require_once( ABSPATH . 'wp-admin/includes/file.php' );
            require_once( ABSPATH . 'wp-admin/includes/media.php' );
            
            $attachment_id = media_handle_upload( 'rag_file', 0 );
            
            if ( !is_wp_error( $attachment_id ) ) {
                $file_path = get_attached_file( $attachment_id );
                $file_url = wp_get_attachment_url( $attachment_id );
                $ext = pathinfo($file_path, PATHINFO_EXTENSION);
                
                $extracted_content = soft_ai_extract_text_from_file($file_path, $ext);
                $type = 'uploaded_file';
                $source_url = $file_url;
                if (!$title) $title = basename($file_path);
            } else {
                echo '<div class="error"><p>Lỗi upload file: ' . $attachment_id->get_error_message() . '</p></div>';
            }
        }

        if (!empty($extracted_content)) {
            $wpdb->insert($table_rag, [
                'title' => $title,
                'source_type' => $type,
                'source_url' => $source_url,
                'content' => $extracted_content
            ]);
            echo '<div class="updated"><p>Đã thêm dữ liệu vào Knowledge Base thành công! (Dung lượng: '.strlen($extracted_content).' bytes)</p></div>';
        } elseif(empty($_FILES['rag_file']['name']) && empty($json_endpoint_url)) {
        } else {
            echo '<div class="error"><p>Không thể trích xuất văn bản từ nguồn này hoặc file rỗng.</p></div>';
        }
    }

    $docs = $wpdb->get_results("SELECT * FROM $table_rag ORDER BY id DESC");
    ?>
    <div class="wrap">
        <h1>📚 Dữ liệu RAG (Knowledge Base)</h1>
        <p>Thêm dữ liệu từ các tài liệu bên ngoài (Google Docs/Sheets/Slides, JSON API hoặc Upload File) để AI có thể đọc và trả lời khách hàng.</p>
        <div style="display:flex; gap: 20px;">
            <div style="width: 400px; background:#fff; padding:20px; border:1px solid #ccc;">
                <h3>Thêm Dữ Liệu Mới</h3>
                <form method="post" enctype="multipart/form-data">
                    <?php wp_nonce_field('sac_save_rag_nonce'); ?>
                    
                    <p>
                        <label><strong>Tên gợi nhớ (Tùy chọn):</strong></label><br>
                        <input type="text" name="title" value="" style="width:100%;" placeholder="Ví dụ: Chính sách bảo hành">
                    </p>
                    <hr>
                    <p><strong>CÁCH 1: Nhập link Google Drive</strong><br>
                        <small>(Hỗ trợ Docs, Sheets, Slides)</small><br>
                        <input type="url" name="gdrive_url" value="" style="width:100%;" placeholder="https://docs.google.com/.../edit">
                    </p>
                    <p style="text-align:center;"><b>--- HOẶC ---</b></p>
                    <p><strong>CÁCH 2: Tải file lên</strong><br>
                        <small>(Hỗ trợ .docx, .xlsx, .pptx, .txt, .csv, .pdf)</small><br>
                        <input type="file" name="rag_file" accept=".docx,.xlsx,.pptx,.txt,.csv,.pdf">
                    </p>
                    <p style="text-align:center;"><b>--- HOẶC ---</b></p>
                    <p><strong>CÁCH 3: Real-time JSON Endpoint</strong><br>
                        <small>(Link API trả về dữ liệu JSON)</small><br>
                        <input type="url" name="json_endpoint_url" value="" style="width:100%;" placeholder="https://api.domain.com/data">
                    </p>
                    
                    <p style="margin-top:20px;">
                        <button type="submit" name="sac_save_rag" class="button button-primary">Trích xuất & Lưu</button>
                    </p>
                </form>
            </div>

            <div style="flex:1;">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th width="50">ID</th>
                            <th>Tiêu đề / Tên File</th>
                            <th width="150">Loại Nguồn</th>
                            <th width="120">Độ dài (Ký tự)</th>
                            <th width="100">Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($docs): foreach($docs as $d): ?>
                        <tr>
                            <td><?php echo $d->id; ?></td>
                            <td>
                                <strong><?php echo esc_html($d->title); ?></strong><br>
                                <small style="color:#666; word-break: break-all;"><a href="<?php echo esc_url($d->source_url); ?>" target="_blank"><?php echo esc_html($d->source_url); ?></a></small>
                            </td>
                            <td><?php echo esc_html($d->source_type); ?></td>
                            <td><?php echo number_format(mb_strlen($d->content)); ?></td>
                            <td>
                                <a href="?page=soft-ai-rag&action=delete_rag&id=<?php echo $d->id; ?>" class="button button-small button-link-delete" onclick="return confirm('Bạn có chắc muốn xóa tài liệu này?')">Xóa</a>
                            </td>
                        </tr>
                        <?php endforeach; else: echo '<tr><td colspan="5">Chưa có dữ liệu nào.</td></tr>'; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php
}

// ---------------------------------------------------------
// 1.2. CANNED RESPONSES PAGE (CRUD)
// ---------------------------------------------------------

function soft_ai_canned_responses_page() {
    if (!current_user_can('manage_options')) return;
    global $wpdb;
    $table = $wpdb->prefix . 'soft_ai_canned_msgs';

    if (isset($_POST['sac_save_canned']) && check_admin_referer('sac_save_canned_nonce')) {
        $shortcut = sanitize_text_field($_POST['shortcut']);
        $content = sanitize_textarea_field($_POST['content']);
        $edit_id = intval($_POST['edit_id']);

        if ($shortcut && $content) {
            if ($edit_id > 0) {
                $wpdb->update($table, ['shortcut' => $shortcut, 'content' => $content], ['id' => $edit_id]);
                echo '<div class="updated"><p>Cập nhật thành công!</p></div>';
            } else {
                $wpdb->insert($table, ['shortcut' => $shortcut, 'content' => $content]);
                echo '<div class="updated"><p>Thêm mới thành công!</p></div>';
            }
        }
    }

    if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
        $del_id = intval($_GET['id']);
        $wpdb->delete($table, ['id' => $del_id]);
        echo '<div class="updated"><p>Đã xóa.</p></div>';
    }

    $edit_data = null;
    if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
        $edit_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", intval($_GET['id'])));
    }

    $responses = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC");
    ?>
    <div class="wrap">
        <h1>Quản lý Câu trả lời mẫu (Canned Responses)</h1>
        <p>Tạo các câu trả lời nhanh để sử dụng trong Live Chat.</p>

        <div style="display:flex; gap: 20px;">
            <div style="width: 350px; background:#fff; padding:20px; border:1px solid #ccc;">
                <h3><?php echo $edit_data ? 'Sửa câu mẫu' : 'Thêm mới'; ?></h3>
                <form method="post" action="<?php echo remove_query_arg(['action', 'id']); ?>">
                    <?php wp_nonce_field('sac_save_canned_nonce'); ?>
                    <input type="hidden" name="edit_id" value="<?php echo $edit_data ? $edit_data->id : 0; ?>">
                    
                    <p>
                        <label><strong>Tên gợi nhớ (Shortcut):</strong></label><br>
                        <input type="text" name="shortcut" value="<?php echo $edit_data ? esc_attr($edit_data->shortcut) : ''; ?>" style="width:100%;" required placeholder="Ví dụ: chào, giá, stk...">
                    </p>
                    <p>
                        <label><strong>Nội dung tin nhắn:</strong></label><br>
                        <textarea name="content" rows="6" style="width:100%;" required><?php echo $edit_data ? esc_textarea($edit_data->content) : ''; ?></textarea>
                    </p>
                    <p>
                        <button type="submit" name="sac_save_canned" class="button button-primary">Lưu lại</button>
                        <?php if($edit_data): ?>
                            <a href="?page=soft-ai-canned-responses" class="button">Hủy</a>
                        <?php endif; ?>
                    </p>
                </form>
            </div>

            <div style="flex:1;">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th width="150">Từ gợi nhớ</th>
                            <th>Nội dung</th>
                            <th width="120">Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($responses): foreach($responses as $r): ?>
                        <tr>
                            <td><strong><?php echo esc_html($r->shortcut); ?></strong></td>
                            <td><?php echo nl2br(esc_html($r->content)); ?></td>
                            <td>
                                <a href="?page=soft-ai-canned-responses&action=edit&id=<?php echo $r->id; ?>" class="button button-small">Sửa</a>
                                <a href="?page=soft-ai-canned-responses&action=delete&id=<?php echo $r->id; ?>" class="button button-small button-link-delete" onclick="return confirm('Xóa?')">Xóa</a>
                            </td>
                        </tr>
                        <?php endforeach; else: echo '<tr><td colspan="3">Chưa có câu mẫu nào.</td></tr>'; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php
}

// ---------------------------------------------------------
// 1.3. SOCIAL CHANNELS PAGE (CRUD)
// ---------------------------------------------------------

function soft_ai_social_channels_page() {
    if (!current_user_can('manage_options')) return;
    global $wpdb;
    $table = $wpdb->prefix . 'soft_ai_social_channels';

    if (isset($_POST['sac_save_channel']) && check_admin_referer('sac_save_channel_nonce')) {
        $platform = sanitize_text_field($_POST['platform']);
        $name = sanitize_text_field($_POST['name']);
        $page_id = sanitize_text_field($_POST['page_id']);
        $access_token = sanitize_text_field($_POST['access_token']);
        $verify_token = sanitize_text_field($_POST['verify_token']);
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        $edit_id = intval($_POST['edit_id']);

        if ($platform && $name) {
            $data = [
                'platform' => $platform,
                'name' => $name,
                'page_id' => $page_id,
                'access_token' => $access_token,
                'verify_token' => $verify_token,
                'is_active' => $is_active
            ];

            if ($edit_id > 0) {
                $wpdb->update($table, $data, ['id' => $edit_id]);
                echo '<div class="updated"><p>Cập nhật kênh thành công!</p></div>';
            } else {
                $wpdb->insert($table, $data);
                echo '<div class="updated"><p>Thêm kênh thành công!</p></div>';
            }
        }
    }

    if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
        $del_id = intval($_GET['id']);
        $wpdb->delete($table, ['id' => $del_id]);
        echo '<div class="updated"><p>Đã xóa kênh.</p></div>';
    }

    $edit_data = null;
    if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
        $edit_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", intval($_GET['id'])));
    }

    $channels = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC");
    ?>
    <div class="wrap">
        <h1>Quản lý kênh mạng xã hội</h1>
        <p>Kết nối AI Bot với nhiều trang Facebook, Zalo OA.</p>
        <p><i>Lưu ý: Bạn có thể copy riêng đường dẫn Webhook cho từng kênh ở cột thông tin bên dưới.</i></p>

        <div style="display:flex; gap: 20px;">
            <div style="width: 400px; background:#fff; padding:20px; border:1px solid #ccc;">
                <h3><?php echo $edit_data ? 'Sửa kênh' : 'Thêm kênh mới'; ?></h3>
                <form method="post" action="<?php echo remove_query_arg(['action', 'id']); ?>">
                    <?php wp_nonce_field('sac_save_channel_nonce'); ?>
                    <input type="hidden" name="edit_id" value="<?php echo $edit_data ? $edit_data->id : 0; ?>">
                    
                    <p>
                        <label><strong>Nền tảng:</strong></label><br>
                        <select name="platform" style="width:100%;" required>
                            <option value="facebook" <?php if($edit_data) selected($edit_data->platform, 'facebook'); ?>>Facebook Messenger</option>
                            <option value="zalo" <?php if($edit_data) selected($edit_data->platform, 'zalo'); ?>>Zalo OA</option>
                        </select>
                    </p>
                    <p>
                        <label><strong>Tên gợi nhớ (Tùy chọn):</strong></label><br>
                        <input type="text" name="name" value="<?php echo $edit_data ? esc_attr($edit_data->name) : ''; ?>" style="width:100%;" required placeholder="Ví dụ: Fanpage Chính">
                    </p>
                    <p>
                        <label><strong>Page ID / OA ID:</strong></label><br>
                        <input type="text" name="page_id" value="<?php echo $edit_data ? esc_attr($edit_data->page_id) : ''; ?>" style="width:100%;" placeholder="Để trống nếu không hiển thị chat widget trên web">
                    </p>
                    <p>
                        <label><strong>Mã Access Token:</strong></label><br>
                        <input type="password" name="access_token" value="<?php echo $edit_data ? esc_attr($edit_data->access_token) : ''; ?>" style="width:100%;" required>
                    </p>
                    <p>
                        <label><strong>Verify Token (Chỉ dành cho FB):</strong></label><br>
                        <input type="text" name="verify_token" value="<?php echo $edit_data ? esc_attr($edit_data->verify_token) : 'soft_ai_verify'; ?>" style="width:100%;">
                    </p>
                    <p>
                        <label>
                            <input type="checkbox" name="is_active" value="1" <?php if(!$edit_data || $edit_data->is_active == 1) echo 'checked'; ?>>
                            <strong>Kích hoạt (Cho phép AI trả lời & Hiển thị widget)</strong>
                        </label>
                    </p>
                    <p>
                        <button type="submit" name="sac_save_channel" class="button button-primary">Lưu lại</button>
                        <?php if($edit_data): ?>
                            <a href="?page=soft-ai-social-channels" class="button">Hủy</a>
                        <?php endif; ?>
                    </p>
                </form>
            </div>

            <div style="flex:1;">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th width="80">Trạng thái</th>
                            <th width="100">Nền tảng</th>
                            <th>Tên kênh & ID</th>
                            <th width="120">Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($channels): foreach($channels as $c): ?>
                        <tr>
                            <td><?php echo $c->is_active ? '<span style="color:green;font-weight:bold;">Đang bật</span>' : '<span style="color:red;">Đã tắt</span>'; ?></td>
                            <td><strong><?php echo ucfirst(esc_html($c->platform)); ?></strong></td>
                            <td>
                                <strong><?php echo esc_html($c->name); ?></strong><br>
                                <small>ID: <?php echo esc_html($c->page_id ?: 'Không có'); ?></small><br>
                                <small style="color: #2271b1;">Đường dẫn Webhook:<br><code style="background:#f0f0f1;padding:2px 4px;border-radius:3px;"><?php echo rest_url('soft-ai-chat/v1/webhook/' . $c->platform . '/' . $c->id); ?></code></small>
                            </td>
                            <td>
                                <a href="?page=soft-ai-social-channels&action=edit&id=<?php echo $c->id; ?>" class="button button-small">Sửa</a>
                                <a href="?page=soft-ai-social-channels&action=delete&id=<?php echo $c->id; ?>" class="button button-small button-link-delete" onclick="return confirm('Xóa?')">Xóa</a>
                            </td>
                        </tr>
                        <?php endforeach; else: echo '<tr><td colspan="4">Chưa có kênh nào được cấu hình.</td></tr>'; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php
}

// ---------------------------------------------------------
// 1.4. LEADS (PRE-CHAT) PAGE
// ---------------------------------------------------------

function soft_ai_leads_page() {
    if (!current_user_can('manage_options')) return;
    global $wpdb;
    $table = $wpdb->prefix . 'soft_ai_leads';

    if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
        $wpdb->delete($table, ['id' => intval($_GET['id'])]);
        echo '<div class="updated"><p>Đã xóa lead.</p></div>';
    }

    $leads = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC");
    ?>
    <div class="wrap">
        <h1>📝 Leads Khách Hàng (Pre-chat)</h1>
        <p>Danh sách thông tin khách hàng thu thập được qua form nhập trước khi bắt đầu chat.</p>
        <table class="wp-list-table widefat fixed striped" style="margin-top: 15px;">
            <thead>
                <tr>
                    <th width="50">ID</th>
                    <th>Họ và Tên</th>
                    <th>Số điện thoại</th>
                    <th>Địa chỉ IP</th>
                    <th>Thời gian</th>
                    <th width="100">Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php if($leads): foreach($leads as $l): ?>
                <tr>
                    <td><?php echo $l->id; ?></td>
                    <td><strong><?php echo esc_html($l->name); ?></strong></td>
                    <td><?php echo esc_html($l->phone); ?></td>
                    <td><?php echo esc_html($l->ip_address); ?></td>
                    <td><?php echo date('H:i, d/m/Y', strtotime($l->created_at)); ?></td>
                    <td>
                        <a href="?page=soft-ai-leads&action=delete&id=<?php echo $l->id; ?>" class="button button-small button-link-delete" onclick="return confirm('Xóa lead này?')">Xóa</a>
                    </td>
                </tr>
                <?php endforeach; else: echo '<tr><td colspan="6">Chưa có dữ liệu khách hàng.</td></tr>'; endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// ---------------------------------------------------------
// 1.5. LIVE CHAT PAGE 
// ---------------------------------------------------------

function soft_ai_live_chat_page() {
    if (!current_user_can('manage_options')) return;
    echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/marked/11.1.1/marked.min.js"></script>';
    ?>
    <style>
        #sac-canned-popup { 
            display: none; position: absolute; bottom: 60px; left: 15px; width: 400px; 
            background: white; border: 1px solid #ccc; box-shadow: 0 -5px 20px rgba(0,0,0,0.1); 
            border-radius: 8px; z-index: 100; overflow: hidden;
        }
        #sac-canned-search { width: 100%; border: none; border-bottom: 1px solid #eee; padding: 10px; box-sizing: border-box; outline: none; }
        #sac-canned-list { max-height: 250px; overflow-y: auto; }
        .sac-canned-item { padding: 8px 12px; border-bottom: 1px solid #f9f9f9; cursor: pointer; font-size: 13px; }
        .sac-canned-item:hover { background: #f0f7fd; color: #0073aa; }
        .sac-canned-shortcut { font-weight: bold; color: #555; display: inline-block; width: 80px; }

        #sac-suggestions { 
            padding: 8px 15px; background: #fffbe6; display: none; border-top: 1px solid #ffe58f; 
            white-space: nowrap; overflow-x: auto; position: absolute; bottom: 100%; left: 0; right: 0; z-index: 99;
        }
        .sac-suggest-chip { 
            display: inline-flex; align-items: center; background: #fff7e6; color: #d46b08; border: 1px solid #ffd591; 
            padding: 4px 10px; border-radius: 15px; font-size: 12px; margin-right: 8px; cursor: pointer; transition: all 0.2s;
        }
        .sac-suggest-chip:hover { background: #ffc069; color: #fff; border-color: #fa8c16; }
        .sac-suggest-label { font-weight:bold; margin-right: 5px; }
    </style>

    <div class="wrap" style="height: auto; display: flex; flex-direction: column;">
        <h1 style="margin-bottom: 20px;">🟢 Livechat</h1>
        
        <div style="display: flex; flex: 1; gap: 20px; height: 100%; overflow: hidden;">
            <div style="height: 100vh; width: 250px; background: #fff; border: 1px solid #ccd0d4; overflow-y: auto;" id="sac-admin-sessions">
                <div style="padding: 10px; border-bottom: 1px solid #eee; background: #f8f9fa;">
                    <div style="font-weight: bold; margin-bottom: 8px;">Khách gần đây</div>
                    <input type="date" id="sac-live-date" value="" style="width: 100%; box-sizing: border-box; padding: 4px; border: 1px solid #ccc; border-radius: 4px;" onchange="loadLiveSessions(); loadLiveMessages();" title="Chọn ngày để lọc">
                    <select id="sac-live-traffic" style="width: 100%; box-sizing: border-box; padding: 4px; border: 1px solid #ccc; border-radius: 4px; margin-top: 5px;" onchange="loadLiveSessions(); loadLiveMessages();">
                        <option value="">Tất cả nguồn (Traffic)</option>
                        <option value="ads">Quảng cáo (Ads)</option>
                        <option value="organic">Tự nhiên (Organic)</option>
                        <option value="direct">Trực tiếp (Direct)</option>
                        <option value="social">Mạng xã hội (Social)</option>
                        <option value="referring">Giới thiệu (Referring)</option>
                    </select>
                    <select id="sac-live-device" style="width: 100%; box-sizing: border-box; padding: 4px; border: 1px solid #ccc; border-radius: 4px; margin-top: 5px;" onchange="loadLiveSessions(); loadLiveMessages();">
                        <option value="">Tất cả thiết bị</option>
                        <option value="Desktop">Máy tính</option>
                        <option value="Mobile">Điện thoại</option>
                        <option value="Tablet">Máy tính bảng</option>
                    </select>
                    <input type="text" id="sac-live-country" placeholder="Mã Quốc gia (VD: VN, US)" style="width: 100%; box-sizing: border-box; padding: 4px; border: 1px solid #ccc; border-radius: 4px; margin-top: 5px;" onchange="loadLiveSessions(); loadLiveMessages();">
                </div>
                <div id="sac-session-list">
                    <div style="padding:20px; text-align:center; color:#999;">Đang tải...</div>
                </div>
            </div>

            <div style="height: 100vh; flex: 1; display: flex; flex-direction: column; background: #fff; border: 1px solid #ccd0d4; position: relative;">
                <div style="padding: 10px 20px; border-bottom: 1px solid #eee; background: #f0f0f1; font-weight: bold; display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <span id="sac-current-user-title">Chọn một khách để bắt đầu chat</span>
                    </div>
                    <div style="display:flex; gap: 10px;">
                        <button class="button button-small" style="color: #a00; border-color: #a00;" id="sac-delete-btn" onclick="deleteConversation()">🗑️ Xóa lịch sử</button>
                        <button class="button button-small" onclick="loadLiveSessions()">Làm mới danh sách</button>
                    </div>
                </div>
                
                <div id="sac-admin-messages" style="flex: 1; padding: 20px; overflow-y: auto; background: #f6f7f7;">
                    <div style="text-align:center; color:#aaa; margin-top: 50px;">Chọn một khách ở bên trái để bắt đầu trò chuyện.</div>
                </div>

                <div style="padding: 15px; background: #fff; border-top: 1px solid #ddd !important; display: flex; gap: 10px; position: relative;">
                    <div id="sac-suggestions"></div>

                    <div id="sac-canned-popup">
                        <input type="text" id="sac-canned-search" placeholder="🔍 Tìm câu mẫu (gõ từ khóa)..." onkeyup="filterCanned()">
                        <div id="sac-canned-list">Đang tải...</div>
                    </div>

                    <button class="button" onclick="toggleCanned()" title="Câu trả lời mẫu">⚡ Câu mẫu</button>
                    <input type="text" id="sac-admin-input" placeholder="Nhập câu trả lời của bạn..." style="flex: 1;" onkeypress="if(event.key==='Enter') sendAdminReply()">
                    <button class="button button-primary" onclick="sendAdminReply()">Gửi</button>
                </div>
            </div>
        </div>
    </div>

    <script>
    var currentChatIp = null;
    var adminPollInterval = null;
    var allCannedMsgs = [];

    function loadLiveSessions() {
        var filterDate = jQuery('#sac-live-date').val();
        var trafficSource = jQuery('#sac-live-traffic').val();
        var filterDevice = jQuery('#sac-live-device').val();
        var filterCountry = jQuery('#sac-live-country').val();

        jQuery.get(ajaxurl, { 
            action: 'sac_get_sessions', 
            date: filterDate, 
            traffic_source: trafficSource,
            device: filterDevice,
            country: filterCountry
        }, function(response) {
            if(response.success) {
                var html = '';
                response.data.forEach(function(sess) {
                    var activeClass = (currentChatIp === sess.ip) ? 'background:#e6f7ff;' : '';
                    var badge = sess.unread > 0 ? '<span style="background:red; color:white; border-radius:50%; padding:2px 6px; font-size:10px; margin-left:5px;">'+sess.unread+'</span>' : '';
                    var safeName = sess.display_name ? sess.display_name.replace(/'/g, "\\'") : sess.ip;
                    html += '<div onclick="openAdminChat(\''+sess.ip+'\', \''+safeName+'\')" style="padding: 12px; border-bottom: 1px solid #eee; cursor: pointer; '+activeClass+'">';
                    html += '<strong>' + sess.source_label + '</strong>' + badge + '<br><small style="color:#666">' + sess.display_name + ' &bull; ' + sess.time + '</small>';
                    html += '</div>';
                });
                if(response.data.length === 0) {
                    html = '<div style="padding:20px; text-align:center; color:#999;">Không tìm thấy khách nào.</div>';
                }
                jQuery('#sac-session-list').html(html);
            }
        });
    }

    function openAdminChat(ip, displayName) {
        currentChatIp = ip;
        var nameToShow = displayName ? displayName : ip;
        jQuery('#sac-current-user-title').text('Đang chat với: ' + nameToShow);
        jQuery('#sac-delete-btn').show(); 
        
        if(allCannedMsgs.length === 0) {
            jQuery.get(ajaxurl, { action: 'sac_get_canned_msgs' }, function(res) {
                if(res.success) allCannedMsgs = res.data;
            });
        }

        loadLiveMessages();
        loadLiveSessions(); 
        
        if(adminPollInterval) clearInterval(adminPollInterval);
        adminPollInterval = setInterval(loadLiveMessages, 3000);
    }

    function loadLiveMessages() {
        if(!currentChatIp) return;
        var filterDate = jQuery('#sac-live-date').val();
        jQuery.get(ajaxurl, { action: 'sac_get_messages', ip: currentChatIp, date: filterDate }, function(response) {
            if(response.success) {
                var html = '';

                response.data.messages.forEach(function(msg) {
                    var align = msg.is_admin ? 'text-align:right;' : 'text-align:left;';
                    var bg = msg.is_admin ? 'background:#0073aa; color:white;' : 'background:#e5e5e5; color:#333;';
                    var parsedContent = marked.parse(msg.content);
                    
                    var adminNameHtml = '';
                    if (msg.is_admin) {
                        var nameLabel = msg.admin_name ? msg.admin_name : 'AI Bot';
                        var icon = (nameLabel === 'AI Bot') ? '🤖' : '🗣️';
                        adminNameHtml = '<div style="font-size:11px; font-weight:bold; margin-bottom:5px; opacity:0.9;">' + icon + ' ' + nameLabel + '</div>';
                    }

                    var urlHtml = '';
                    if (!msg.is_admin && msg.current_url) {
                        urlHtml += '<div style="font-size:11px; margin-top:8px; border-top:1px dashed rgba(0,0,0,0.1); padding-top:5px; word-break:break-all;">';
                        urlHtml += '🔗 <b>Trang:</b> <a href="'+msg.current_url+'" target="_blank" style="color:#0073aa; text-decoration:none;">'+msg.current_url+'</a><br>';
                        if (msg.referrer_url) {
                            urlHtml += '🔙 <b>Nguồn giới thiệu:</b> <a href="'+msg.referrer_url+'" target="_blank" style="color:#0073aa; text-decoration:none;">'+msg.referrer_url+'</a>';
                        }
                        urlHtml += '</div>';
                    }

                    html += '<div style="margin-bottom: 10px; ' + align + '">';
                    html += '<div style="display:inline-block; padding: 8px 12px; border-radius: 15px; max-width: 70%; ' + bg + '">' + adminNameHtml + parsedContent + urlHtml + '</div>';
                    html += '<div style="font-size:10px; color:#666; margin-top:2px;">' + msg.time + '</div>';
                    html += '</div>';
                });
                
                if (response.data.messages.length === 0) {
                    html = '<div style="text-align:center; color:#aaa; margin-top: 50px;">Không có tin nhắn nào.</div>';
                }
                
                var container = document.getElementById('sac-admin-messages');
                container.innerHTML = html;
            }
        });
    }

    jQuery('#sac-admin-input').on('keyup', function() {
        var currentInput = jQuery(this).val();
        checkAutoSuggestions(currentInput); 
    });

    function checkAutoSuggestions(msg) {
        var container = document.getElementById('sac-suggestions');
        if (!msg || allCannedMsgs.length === 0) {
            container.style.display = 'none';
            return;
        }

        var found = [];
        var lowerMsg = msg.toLowerCase();

        allCannedMsgs.forEach(function(item) {
            if (lowerMsg.includes(item.shortcut.toLowerCase())) {
                found.push(item);
            }
        });

        if (found.length > 0) {
            var html = '';
            found.forEach(function(item) {
                var safeContent = item.content.replace(/"/g, '&quot;').replace(/'/g, "\\'");
                html += `<div class="sac-suggest-chip" onclick="insertCanned('${safeContent}')" style="max-width: 400px; white-space: normal; height: auto; padding: 8px 12px; border-radius: 8px;">
                    <span class="sac-suggest-label" style="display:block;">💡 Khớp từ tắt [${item.shortcut}]:</span>
                    <div style="font-size: 13px; line-height: 1.4;">${item.content}</div>
                </div>`;
            });
            container.innerHTML = html;
            container.style.display = 'flex'; 
            container.style.flexWrap = 'wrap';
        } else {
            container.style.display = 'none';
        }
    }

    function deleteConversation() {
        if(!currentChatIp) return;
        if(!confirm('Bạn có chắc muốn xóa TOÀN BỘ lịch sử với ' + currentChatIp + '? Hành động này không thể hoàn tác.')) return;
        jQuery.post(ajaxurl, { action: 'sac_delete_conversation', ip: currentChatIp }, function(response) {
            if(response.success) {
                currentChatIp = null;
                jQuery('#sac-admin-messages').html('<div style="text-align:center; color:#aaa; margin-top: 50px;">Đã xóa cuộc trò chuyện. Vui lòng chọn khách khác.</div>');
                jQuery('#sac-current-user-title').text('Chọn một khách để bắt đầu chat');
                jQuery('#sac-delete-btn').hide();
                document.getElementById('sac-suggestions').style.display = 'none';
                if(adminPollInterval) clearInterval(adminPollInterval);
                loadLiveSessions();
            } else { alert('Có lỗi khi xóa cuộc trò chuyện.'); }
        });
    }

    function sendAdminReply() {
        var txt = jQuery('#sac-admin-input').val().trim();
        if(!txt || !currentChatIp) return;
        jQuery('#sac-admin-input').val(''); 
        document.getElementById('sac-suggestions').style.display = 'none'; 
        jQuery.post(ajaxurl, { action: 'sac_send_reply', ip: currentChatIp, message: txt }, function(response) { loadLiveMessages(); });
    }

    function toggleCanned() {
        var p = document.getElementById('sac-canned-popup');
        if(p.style.display === 'block') { p.style.display = 'none'; return; }
        p.style.display = 'block';
        document.getElementById('sac-canned-search').focus();
        
        if(allCannedMsgs.length === 0) {
            jQuery.get(ajaxurl, { action: 'sac_get_canned_msgs' }, function(res) {
                if(res.success) {
                    allCannedMsgs = res.data;
                    renderCannedList(allCannedMsgs);
                }
            });
        } else {
            renderCannedList(allCannedMsgs);
        }
    }

    function renderCannedList(list) {
        var html = '';
        list.forEach(function(item) {
            var safeContent = item.content.replace(/"/g, '&quot;').replace(/'/g, "\\'");
            html += `<div class="sac-canned-item" onclick="insertCanned('${safeContent}')">
                <span class="sac-canned-shortcut">[${item.shortcut}]</span> ${item.content.substring(0, 40)}...
            </div>`;
        });
        if(list.length === 0) html = '<div style="padding:10px;color:#999;">Không tìm thấy.</div>';
        document.getElementById('sac-canned-list').innerHTML = html;
    }

    function filterCanned() {
        var q = document.getElementById('sac-canned-search').value.toLowerCase();
        var filtered = allCannedMsgs.filter(function(item) {
            return item.shortcut.toLowerCase().includes(q) || item.content.toLowerCase().includes(q);
        });
        renderCannedList(filtered);
    }

    function insertCanned(text) {
        var decoded = text.replace(/&quot;/g, '"');
        jQuery('#sac-admin-input').val(decoded);
        document.getElementById('sac-canned-popup').style.display = 'none';
        document.getElementById('sac-suggestions').style.display = 'none';
        document.getElementById('sac-admin-input').focus();
    }

    jQuery(document).on('click', function(e) {
        if (!jQuery(e.target).closest('#sac-canned-popup, button[onclick="toggleCanned()"]').length) {
            jQuery('#sac-canned-popup').hide();
        }
    });

    jQuery(document).ready(function(){
        jQuery('#sac-delete-btn').hide(); 
        jQuery.get(ajaxurl, { action: 'sac_get_canned_msgs' }, function(res) {
            if(res.success) allCannedMsgs = res.data;
        });
        loadLiveSessions();
        setInterval(loadLiveSessions, 10000); 
    });
    </script>
    <?php
}

// ---------------------------------------------------------
// 1.5.5. THỐNG KÊ (STATS) PAGE 
// ---------------------------------------------------------

function soft_ai_chat_stats_page() {
    if (!current_user_can('manage_options')) return;
    global $wpdb;
    $table = $wpdb->prefix . 'soft_ai_chat_stats'; 

    $filter_date = isset($_GET['filter_date']) ? sanitize_text_field($_GET['filter_date']) : '';
    $date_cond = $filter_date ? $wpdb->prepare(" AND date_day = %s", $filter_date) : "";

    $total_conversations = (int) $wpdb->get_var("SELECT COUNT(DISTINCT user_ip) FROM $table WHERE 1=1 $date_cond");
    $human_takeover = (int) $wpdb->get_var("SELECT COUNT(DISTINCT user_ip) FROM $table WHERE is_taken_over = 1 $date_cond");
    $total_ai_msgs = (int) $wpdb->get_var("SELECT SUM(ai_msgs) FROM $table WHERE 1=1 $date_cond");
    $total_admin_msgs = (int) $wpdb->get_var("SELECT SUM(admin_msgs) FROM $table WHERE 1=1 $date_cond");
    $total_sent_msgs = $total_admin_msgs + $total_ai_msgs;
    $total_ai_orders = (int) $wpdb->get_var("SELECT SUM(ai_orders) FROM $table WHERE 1=1 $date_cond");

    $threads = $wpdb->get_results("SELECT first_user_time, first_admin_time, last_admin_time FROM $table WHERE 1=1 $date_cond");
    
    $total_response_time = 0;
    $response_count = 0;
    $total_handle_time = 0;
    $handle_count = 0;

    foreach($threads as $row) {
        if ($row->first_user_time && $row->first_admin_time) {
            $t_user = strtotime($row->first_user_time);
            $t_admin = strtotime($row->first_admin_time);
            if ($t_admin >= $t_user) {
                $total_response_time += ($t_admin - $t_user);
                $response_count++;
            }
        }
        if ($row->first_admin_time && $row->last_admin_time) {
            $total_handle_time += (strtotime($row->last_admin_time) - strtotime($row->first_admin_time));
            $handle_count++;
        }
    }

    $avg_response_time = $response_count > 0 ? round($total_response_time / $response_count) : 0;
    $avg_handle_time = $handle_count > 0 ? round($total_handle_time / $handle_count) : 0;

    $first_msg_day = $wpdb->get_var("SELECT MIN(first_admin_time) FROM $table WHERE 1=1 $date_cond");
    $last_msg_day = $wpdb->get_var("SELECT MAX(last_admin_time) FROM $table WHERE 1=1 $date_cond");
    $online_time = 0;
    if ($first_msg_day && $last_msg_day) {
         $online_time = strtotime($last_msg_day) - strtotime($first_msg_day);
    }
    
    $online_rate = ($online_time > 0) ? round(($online_time / 86400) * 100, 2) : 0;
    if ($online_rate > 100) $online_rate = 100;

    function soft_ai_format_seconds($seconds) {
        if ($seconds == 0) return '0s';
        $h = floor($seconds / 3600);
        $m = floor(($seconds % 3600) / 60);
        $s = $seconds % 60;
        $res = '';
        if ($h > 0) $res .= $h . 'h ';
        if ($m > 0) $res .= $m . 'm ';
        $res .= $s . 's';
        return trim($res);
    }
    ?>
    <style>
        .sac-stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-top: 20px; }
        .sac-stat-card { background: #fff; padding: 20px; border: 1px solid #ccd0d4; border-left: 4px solid #2271b1; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04); }
        .sac-stat-title { font-size: 14px; color: #646970; font-weight: 600; margin-bottom: 10px; }
        .sac-stat-value { font-size: 28px; font-weight: bold; color: #1d2327; }
        .sac-stat-desc { font-size: 12px; color: #8c8f94; margin-top: 5px; }
    </style>
    <div class="wrap">
        <h1>📊 Thống kê hiệu suất AI & Chat</h1>
        <div style="margin-bottom: 20px; background: #fff; padding: 15px; border: 1px solid #ccd0d4; display: inline-block;">
            <form method="get">
                <input type="hidden" name="page" value="soft-ai-chat-stats">
                <strong>Lọc theo ngày:</strong>
                <input type="date" name="filter_date" value="<?php echo esc_attr($filter_date); ?>">
                <button type="submit" class="button button-primary">Xem thống kê</button>
                <?php if($filter_date): ?>
                    <a href="?page=soft-ai-chat-stats" class="button">Bỏ lọc (Toàn thời gian)</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="sac-stats-grid">
            <div class="sac-stat-card">
                <div class="sac-stat-title">👥 Tổng hội thoại tiếp nhận</div>
                <div class="sac-stat-value"><?php echo number_format($total_conversations); ?></div>
                <div class="sac-stat-desc">Số lượng người dùng đã tương tác (IP/User riêng biệt).</div>
            </div>

            <div class="sac-stat-card">
                <div class="sac-stat-title">🔄 Hội thoại tiếp quản từ AI</div>
                <div class="sac-stat-value"><?php echo number_format($human_takeover); ?></div>
                <div class="sac-stat-desc">Số lượng khách hàng được nhân viên vào hỗ trợ trực tiếp.</div>
            </div>

            <div class="sac-stat-card">
                <div class="sac-stat-title">💬 Tổng số tin nhắn đã gửi</div>
                <div class="sac-stat-value"><?php echo number_format($total_sent_msgs); ?></div>
                <div class="sac-stat-desc">
                    AI tự động trả lời: <strong><?php echo number_format($total_ai_msgs); ?></strong><br>
                    Nhân viên phản hồi: <strong><?php echo number_format($total_admin_msgs); ?></strong>
                </div>
            </div>

            <div class="sac-stat-card" style="border-left-color: #f56e28;">
                <div class="sac-stat-title">🛒 Số đơn hàng do AI tạo</div>
                <div class="sac-stat-value"><?php echo number_format($total_ai_orders); ?></div>
                <div class="sac-stat-desc">Số lượng đơn hàng được chốt thành công qua Chatbot AI.</div>
            </div>

            <div class="sac-stat-card" style="border-left-color: #00a32a;">
                <div class="sac-stat-title">⏱️ Thời gian phản hồi trung bình</div>
                <div class="sac-stat-value"><?php echo soft_ai_format_seconds($avg_response_time); ?></div>
                <div class="sac-stat-desc">Thời gian kể từ lúc khách nhắn đến khi nhân viên phản hồi đầu tiên (First Response Time).</div>
            </div>

            <div class="sac-stat-card" style="border-left-color: #00a32a;">
                <div class="sac-stat-title">⚙️ Thời gian xử lý trung bình</div>
                <div class="sac-stat-value"><?php echo soft_ai_format_seconds($avg_handle_time); ?></div>
                <div class="sac-stat-desc">Thời gian trung bình để giải quyết một cuộc trò chuyện do nhân viên đảm nhận.</div>
            </div>

            <div class="sac-stat-card" style="border-left-color: #d63638;">
                <div class="sac-stat-title">🟢 Thời gian trực chat (Ước tính)</div>
                <div class="sac-stat-value"><?php echo soft_ai_format_seconds($online_time); ?></div>
                <div class="sac-stat-desc">Tỷ lệ online: <strong><?php echo $online_rate; ?>%</strong> (Tính toán dựa trên khoảng cách giữa tin nhắn đầu và cuối của admin trong kỳ).</div>
            </div>
        </div>
    </div>
    <?php
}

// ---------------------------------------------------------
// 1.6. ADMIN AJAX HANDLERS 
// ---------------------------------------------------------

function soft_ai_ajax_get_sessions() {
    global $wpdb;
    $table = $wpdb->prefix . 'soft_ai_chat_logs';
    $date = isset($_GET['date']) ? sanitize_text_field($_GET['date']) : '';
    $traffic = isset($_GET['traffic_source']) ? sanitize_text_field($_GET['traffic_source']) : '';
    $device = isset($_GET['device']) ? sanitize_text_field($_GET['device']) : '';
    $country = isset($_GET['country']) ? sanitize_text_field($_GET['country']) : '';
    
    $where = "WHERE 1=1";
    if ($date) {
        $where .= $wpdb->prepare(" AND DATE(time) = %s", $date);
    } else {
        $where .= " AND time > NOW() - INTERVAL 24 HOUR";
    }

    $having_clauses = [];
    if ($traffic === 'direct') {
        $having_clauses[] = " MAX(referrer_url) = '' AND MAX(source) = 'widget' ";
    } elseif ($traffic === 'ads') {
        $having_clauses[] = " MAX(current_url) REGEXP 'gclid=|msclkid=|ttclid=|fbclid=|utm_medium=(cpc|ppc|paid|display|banner|cpm)' ";
    } elseif ($traffic === 'organic') {
        $having_clauses[] = " MAX(referrer_url) REGEXP 'google|bing|yahoo|coccoc|duckduckgo' AND MAX(current_url) NOT REGEXP 'gclid=|msclkid=|ttclid=|fbclid=|utm_medium=(cpc|ppc|paid|display|banner|cpm)' ";
    } elseif ($traffic === 'social') {
        $having_clauses[] = " (MAX(source) IN ('facebook', 'zalo') OR MAX(referrer_url) REGEXP 'facebook|fb\\.com|instagram|tiktok|zalo|twitter|t\\.co') AND MAX(current_url) NOT REGEXP 'gclid=|msclkid=|ttclid=|fbclid=|utm_medium=(cpc|ppc|paid|display|banner|cpm)' ";
    } elseif ($traffic === 'referring') {
        $having_clauses[] = " MAX(referrer_url) != '' AND MAX(source) = 'widget' AND MAX(referrer_url) NOT REGEXP 'google|bing|yahoo|coccoc|duckduckgo|facebook|fb\\.com|instagram|tiktok|zalo|twitter|t\\.co' AND MAX(current_url) NOT REGEXP 'gclid=|msclkid=|ttclid=|fbclid=|utm_medium=(cpc|ppc|paid|display|banner|cpm)' ";
    }

    if ($device) {
        $having_clauses[] = $wpdb->prepare(" MAX(device) = %s ", $device);
    }
    if ($country) {
        $having_clauses[] = $wpdb->prepare(" MAX(country) = %s ", strtoupper($country));
    }

    $having = "";
    if (!empty($having_clauses)) {
        $having = " HAVING " . implode(" AND ", $having_clauses);
    }

    $query = "
        SELECT user_ip as ip, MAX(time) as latest_time, MAX(source) as source, MAX(referrer_url) as ref_url, MAX(current_url) as cur_url, MAX(device) as device_val, MAX(country) as country_val,
        SUM(CASE WHEN is_read = 0 AND provider != 'live_admin' THEN 1 ELSE 0 END) as unread
        FROM $table 
        $where 
        GROUP BY user_ip 
        $having
        ORDER BY latest_time DESC
    ";

    $results = $wpdb->get_results($query);

    $data = [];
    foreach($results as $r) {
        $source_icon = '🌐'; 
        if($r->source === 'facebook') $source_icon = '🔵';
        if($r->source === 'zalo') $source_icon = '🟡';

        $traffic_label = '';
        if ($r->source === 'widget') {
            if (!empty($r->cur_url) && preg_match('/gclid=|msclkid=|ttclid=|fbclid=|utm_medium=(cpc|ppc|paid|display|banner|cpm)/i', $r->cur_url)) $traffic_label = ' [Quảng cáo]';
            elseif (empty($r->ref_url)) $traffic_label = ' [Trực tiếp]';
            elseif (preg_match('/google|bing|yahoo|coccoc|duckduckgo/i', $r->ref_url)) $traffic_label = ' [Tự nhiên]';
            elseif (preg_match('/facebook|fb\.com|instagram|tiktok|zalo|twitter|t\.co/i', $r->ref_url)) $traffic_label = ' [Mạng XH]';
            else $traffic_label = ' [Giới thiệu]';
        }

        $device_icon = '';
        if ($r->device_val === 'Mobile') $device_icon = '📱';
        elseif ($r->device_val === 'Tablet') $device_icon = '⬛';
        elseif ($r->device_val === 'Desktop') $device_icon = '💻';

        $country_flag = $r->country_val ? ' [' . strtoupper($r->country_val) . ']' : '';

        $display_ip = $r->ip;
        if ($r->source === 'facebook') {
            $fb_name = get_transient('soft_ai_fb_name_' . $r->ip);
            if ($fb_name && $fb_name !== 'Khách Facebook ẩn danh') {
                $display_ip = $fb_name . ' (' . $r->ip . ')';
            }
        }

        $data[] = [
            'ip' => $r->ip, 
            'display_name' => $display_ip,
            'time' => date('H:i, d/m/Y', strtotime($r->latest_time)), 
            'unread' => $r->unread,
            'source_label' => $source_icon . ' ' . ucfirst($r->source) . $traffic_label . ' ' . $device_icon . $country_flag
        ];
    }
    wp_send_json_success($data);
}

function soft_ai_ajax_get_messages() {
    global $wpdb;
    $ip = sanitize_text_field($_GET['ip']);
    $date = isset($_GET['date']) ? sanitize_text_field($_GET['date']) : '';
    $table = $wpdb->prefix . 'soft_ai_chat_logs';
    $wpdb->update($table, ['is_read' => 1], ['user_ip' => $ip]);
    
    if ($date) {
        $logs = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE user_ip = %s AND DATE(time) = %s ORDER BY time ASC LIMIT 100", $ip, $date));
    } else {
        $logs = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE user_ip = %s ORDER BY time ASC LIMIT 100", $ip));
    }
    
    $messages = [];
    foreach($logs as $log) {
        $is_admin = ($log->provider === 'live_admin');
        $content = $is_admin ? $log->answer : $log->question;
        $admin_name = '';

        if ($log->provider == 'live_user') { 
            $content = $log->question; 
            $is_admin = false; 
        } elseif ($log->provider == 'live_admin') { 
            $content = $log->answer; 
            $is_admin = true; 
            $admin_name = (!empty($log->model) && $log->model !== 'human') ? $log->model : 'Nhân viên';
        } elseif (!empty($log->answer) && !empty($log->question)) {
            $messages[] = [
                'content' => $log->question, 
                'is_admin' => false, 
                'time' => date('H:i, d/m/Y', strtotime($log->time)),
                'current_url' => isset($log->current_url) ? $log->current_url : '',
                'referrer_url' => isset($log->referrer_url) ? $log->referrer_url : ''
            ];
            $messages[] = [
                'content' => $log->answer, 
                'is_admin' => true, 
                'admin_name' => 'AI Bot', 
                'time' => date('H:i, d/m/Y', strtotime($log->time))
            ];
            continue;
        }

        if ($is_admin && empty($admin_name)) {
            $admin_name = 'AI Bot';
        }

        $messages[] = [
            'content' => $content, 
            'is_admin' => $is_admin, 
            'admin_name' => $admin_name, 
            'time' => date('H:i, d/m/Y', strtotime($log->time)),
            'current_url' => isset($log->current_url) ? $log->current_url : '',
            'referrer_url' => isset($log->referrer_url) ? $log->referrer_url : ''
        ];
    }
    wp_send_json_success(['messages' => $messages]);
}

function soft_ai_ajax_delete_conversation() {
    if (!current_user_can('manage_options')) wp_send_json_error('Không có quyền truy cập');
    global $wpdb;
    $ip = sanitize_text_field($_POST['ip']);
    $table = $wpdb->prefix . 'soft_ai_chat_logs';
    $wpdb->delete($table, ['user_ip' => $ip]);
    wp_send_json_success();
}

function soft_ai_ajax_send_reply() {
    global $wpdb;
    $ip = sanitize_text_field($_POST['ip']);
    $msg = sanitize_textarea_field(wp_unslash($_POST['message']));
    if (!$ip || !$msg) wp_send_json_error();

    $table = $wpdb->prefix . 'soft_ai_chat_logs';
    $last_source = $wpdb->get_var($wpdb->prepare("SELECT source FROM $table WHERE user_ip = %s ORDER BY id DESC LIMIT 1", $ip)) ?: 'widget';

    $current_user = wp_get_current_user();
    $admin_name = !empty($current_user->display_name) ? $current_user->display_name : 'Nhân viên';

    $wpdb->insert($table, [
        'time' => current_time('mysql'), 
        'user_ip' => $ip, 
        'provider' => 'live_admin', 
        'model' => $admin_name,
        'question' => '', 
        'answer' => $msg, 
        'source' => $last_source, 
        'is_read' => 1,
        'device' => soft_ai_get_device(),
        'country' => soft_ai_get_country()
    ]);
    
    soft_ai_update_stats_table($ip, 'admin_reply');
    
    if ($last_source === 'facebook') {
        $channel = $wpdb->get_row("SELECT access_token FROM {$wpdb->prefix}soft_ai_social_channels WHERE platform = 'facebook' AND is_active = 1 LIMIT 1");
        $token = $channel ? $channel->access_token : '';
        soft_ai_send_fb_message($ip, $msg, $token);
    } elseif ($last_source === 'zalo') {
        $channel = $wpdb->get_row("SELECT access_token FROM {$wpdb->prefix}soft_ai_social_channels WHERE platform = 'zalo' AND is_active = 1 LIMIT 1");
        $token = $channel ? $channel->access_token : '';
        if ($token) {
            wp_remote_post("https://openapi.zalo.me/v3.0/oa/message/cs", [
                'headers' => ['access_token' => $token, 'Content-Type' => 'application/json'],
                'body' => wp_json_encode(['recipient' => ['user_id' => (string)$ip], 'message' => ['text' => $msg]])
            ]);
        }
    }

    $context = new Soft_AI_Context($ip, $last_source);
    $context->set('admin_last_reply_time', time());
    
    wp_send_json_success();
}

function soft_ai_ajax_get_canned_msgs() {
    global $wpdb;
    $table = $wpdb->prefix . 'soft_ai_canned_msgs';
    $results = $wpdb->get_results("SELECT id, shortcut, content FROM $table ORDER BY shortcut ASC");
    wp_send_json_success($results);
}

// ---------------------------------------------------------
// 1.7. HISTORY PAGE 
// ---------------------------------------------------------

function soft_ai_chat_history_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'soft_ai_chat_logs';

    if (isset($_POST['clear_all_logs']) && check_admin_referer('clear_all_logs')) {
        $wpdb->query("TRUNCATE TABLE $table_name");
        echo '<div class="updated"><p>Đã xóa toàn bộ lịch sử.</p></div>';
    }

    if (isset($_POST['delete_thread']) && isset($_POST['thread_ip']) && check_admin_referer('delete_thread_' . $_POST['thread_ip'])) {
        $del_ip = sanitize_text_field($_POST['thread_ip']);
        $wpdb->delete($table_name, ['user_ip' => $del_ip]);
        echo '<div class="updated"><p>Đã xóa cuộc trò chuyện.</p></div>';
    }

    $view_ip = isset($_GET['view_ip']) ? sanitize_text_field($_GET['view_ip']) : null;
    
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline">Lịch sử Chat (Logs)</h1>
        
        <?php if(!$view_ip): ?>
            <form method="post" style="display:inline-block; margin-left:10px;">
                <?php wp_nonce_field('clear_all_logs'); ?>
                <input type="hidden" name="clear_all_logs" value="1">
                <button type="submit" class="page-title-action" style="border:1px solid #d63638; color:#d63638; background:white; cursor:pointer;" onclick="return confirm('Xóa TOÀN BỘ lịch sử?')">Xóa toàn bộ lịch sử</button>
            </form>
        <?php else: ?>
            <a href="<?php echo admin_url('admin.php?page=soft-ai-chat-history'); ?>" class="page-title-action">← Quay lại danh sách</a>
        <?php endif; ?>

        <hr class="wp-header-end">

        <style>
            .sac-container { margin-top: 20px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
            .sac-thread-list { background: #fff; border: 1px solid #ccd0d4; box-shadow: 0 1px 1px rgba(0,0,0,.04); border-radius: 4px; overflow: hidden; }
            .sac-thread-item { display: flex; align-items: center; padding: 15px 20px; border-bottom: 1px solid #f0f0f1; transition: background 0.2s; position: relative; }
            .sac-thread-item:last-child { border-bottom: none; }
            .sac-thread-item:hover { background: #f6f7f7; }
            .sac-avatar { width: 45px; height: 45px; background: #e0e0e0; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; color: #777; font-size: 18px; margin-right: 15px; }
            .sac-thread-info { flex: 1; }
            .sac-ip-title { font-size: 16px; font-weight: 600; color: #1d2327; margin-bottom: 4px; display: block; text-decoration: none; }
            .sac-ip-title:hover { color: #2271b1; }
            .sac-thread-meta { font-size: 13px; color: #646970; }
            .sac-badge { background: #f0f0f1; color: #50575e; padding: 2px 8px; border-radius: 12px; font-size: 11px; margin-left: 5px; font-weight: 500; border: 1px solid #dcdcde; }
            .sac-action-btn { margin-left: 10px; text-decoration: none; padding: 6px 12px; border: 1px solid #2271b1; color: #2271b1; border-radius: 4px; font-size: 13px; transition: all 0.2s; }
            .sac-action-btn:hover { background: #2271b1; color: #fff; }
            .sac-del-btn { border-color: #d63638; color: #d63638; background: transparent; cursor: pointer; }
            .sac-del-btn:hover { background: #d63638; color: #fff; }
            .sac-pagination { margin-top: 20px; display: flex; justify-content: center; gap: 5px; }
            .sac-page-num { padding: 5px 10px; border: 1px solid #ddd !important; background: #fff; text-decoration: none; color: #333; border-radius: 3px; }
            .sac-page-num.current { background: #2271b1; color: #fff; border-color: #2271b1; }
            .sac-chat-window { max-width: 800px; margin: 0 auto; background: #fff; border: 1px solid #ccd0d4; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
            .sac-chat-header { background: #f8f9fa; padding: 15px 20px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center; }
            .sac-chat-body { padding: 20px; background: #fff; max-height: 70vh; overflow-y: auto; display: flex; flex-direction: column; gap: 15px; }
            .sac-bubble-row { display: flex; width: 100%; margin-bottom: 10px; }
            .sac-bubble-row.user { justify-content: flex-end; }
            .sac-bubble-row.bot { justify-content: flex-start; }
            .sac-bubble { max-width: 70%; padding: 10px 15px; border-radius: 18px; position: relative; font-size: 14px; line-height: 1.5; word-wrap: break-word; }
            .sac-bubble-row.user .sac-bubble { background: #0073aa; color: #fff; border-bottom-right-radius: 4px; }
            .sac-bubble-row.bot .sac-bubble { background: #f0f0f1; color: #1d2327; border-bottom-left-radius: 4px; border: 1px solid #e5e5e5; }
            .sac-bubble-row.bot .sac-bubble strong { color: #0073aa; }
            .sac-bubble-row.bot .sac-bubble img { max-width: 100%; height: auto; border-radius: 8px; margin-top: 5px; }
            .sac-bubble-row.admin .sac-bubble { background: #e6f7ff; border: 1px solid #91d5ff; color: #0050b3; } 
            .sac-time { font-size: 11px; color: #888; margin-top: 4px; display: block; opacity: 0.8; }
            .sac-bubble-row.user .sac-time { text-align: right; color: rgba(255,255,255,0.8); }
        </style>

        <div class="sac-container">
            <?php 
            if ($view_ip): 
                $view_date = isset($_GET['view_date']) ? sanitize_text_field($_GET['view_date']) : '';
                if ($view_date) {
                    $logs = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE user_ip = %s AND DATE(time) = %s ORDER BY time ASC", $view_ip, $view_date));
                } else {
                    $logs = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE user_ip = %s ORDER BY time ASC", $view_ip));
                }
                echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/marked/11.1.1/marked.min.js"></script>';
                
                $chat_title = esc_html($view_ip);
                if ($logs && $logs[0]->source === 'facebook') {
                    $fb_name = get_transient('soft_ai_fb_name_' . $view_ip);
                    if ($fb_name && $fb_name !== 'Khách Facebook ẩn danh') {
                        $chat_title = esc_html($fb_name) . ' (' . esc_html($view_ip) . ')';
                    }
                }
                ?>
                <div class="sac-chat-window">
                    <div class="sac-chat-header">
                        <h2 style="margin:0; font-size: 16px;">Trò chuyện với: <strong><?php echo $chat_title; ?></strong></h2>
                        <div style="display: flex; gap: 10px; align-items: center;">
                            <form method="get" style="margin:0;">
                                <input type="hidden" name="page" value="soft-ai-chat-history">
                                <input type="hidden" name="view_ip" value="<?php echo esc_attr($view_ip); ?>">
                                <input type="date" name="view_date" value="<?php echo esc_attr($view_date); ?>" onchange="this.form.submit()" style="padding: 2px 5px; font-size: 13px;">
                                <?php if($view_date): ?>
                                    <a href="?page=soft-ai-chat-history&view_ip=<?php echo urlencode($view_ip); ?>" class="button button-small">Bỏ lọc</a>
                                <?php endif; ?>
                            </form>
                            <form method="post" style="margin:0;">
                                 <?php wp_nonce_field('delete_thread_' . $view_ip); ?>
                                 <input type="hidden" name="delete_thread" value="1">
                                 <input type="hidden" name="thread_ip" value="<?php echo esc_attr($view_ip); ?>">
                                 <button type="submit" class="button button-link-delete" onclick="return confirm('Xóa cuộc trò chuyện này?')">Xóa cuộc trò chuyện</button>
                            </form>
                        </div>
                    </div>
                    <div class="sac-chat-body">
                        <?php if ($logs): foreach ($logs as $log): 
                            $is_admin_reply = ($log->provider === 'live_admin');
                            if (!empty($log->question) && $log->provider !== 'live_admin') {
                                $qid = 'q-' . $log->id;
                                
                                $url_info = '';
                                if (!empty($log->current_url)) {
                                    $url_info .= "<div style='font-size:11px; margin-top:8px; border-top:1px dashed rgba(255,255,255,0.3); padding-top:5px; word-break:break-all; line-height:1.4;'>";
                                    $url_info .= "🔗 <b>Trang:</b> <a href='".esc_url($log->current_url)."' target='_blank' style='color:#cce5ff; text-decoration:none;'>".esc_html($log->current_url)."</a><br>";
                                    if (!empty($log->referrer_url)) {
                                        $url_info .= "🔙 <b>Nguồn giới thiệu:</b> <a href='".esc_url($log->referrer_url)."' target='_blank' style='color:#cce5ff; text-decoration:none;'>".esc_html($log->referrer_url)."</a>";
                                    }
                                    $url_info .= "</div>";
                                }

                                echo '<div class="sac-bubble-row user">
                                        <div class="sac-bubble">
                                            <div id="'.$qid.'"></div>' . $url_info . '
                                            <span class="sac-time">' . date('H:i, d/m/Y', strtotime($log->time)) . '</span>
                                        </div>
                                        <textarea id="raw-'.$qid.'" style="display:none;">'.esc_textarea($log->question).'</textarea>
                                        <script>
                                            document.getElementById("'.$qid.'").innerHTML = marked.parse(document.getElementById("raw-'.$qid.'").value);
                                        </script>
                                      </div>';
                            }
                            if (!empty($log->answer)) {
                                $cls = $is_admin_reply ? 'admin' : 'bot';
                                $aid = 'a-' . $log->id;
                                $raw_answer = $log->answer; 
                                $admin_name_html = '';
                                if ($is_admin_reply) {
                                    $name = (!empty($log->model) && $log->model !== 'human') ? esc_html($log->model) : 'Nhân viên';
                                    $admin_name_html = "<div style='font-size:12px; font-weight:bold; margin-bottom:6px;'>🗣️ {$name}</div>";
                                } else {
                                    $admin_name_html = "<div style='font-size:12px; font-weight:bold; margin-bottom:6px; color:#555;'>🤖 AI Bot</div>";
                                }

                                echo '<div class="sac-bubble-row bot '.$cls.'">
                                        <div class="sac-bubble">
                                             ' . $admin_name_html . '
                                             <div id="'.$aid.'"></div>
                                             <span class="sac-time">' . date('H:i, d/m/Y', strtotime($log->time)) . '</span>
                                        </div>
                                        <textarea id="raw-'.$aid.'" style="display:none;">'.esc_textarea($raw_answer).'</textarea>
                                        <script>
                                            var raw = document.getElementById("raw-'.$aid.'").value;
                                            document.getElementById("'.$aid.'").innerHTML = marked.parse(raw);
                                        </script>
                                      </div>';
                            }
                        endforeach; else: echo '<p style="text-align:center; color:#999;">Không tìm thấy tin nhắn nào.</p>'; endif; ?>
                    </div>
                </div>

            <?php else: 
                $filter_date = isset($_GET['filter_date']) ? sanitize_text_field($_GET['filter_date']) : '';
                $traffic_filter = isset($_GET['traffic_source']) ? sanitize_text_field($_GET['traffic_source']) : '';
                $filter_device = isset($_GET['filter_device']) ? sanitize_text_field($_GET['filter_device']) : '';
                $filter_country = isset($_GET['filter_country']) ? sanitize_text_field($_GET['filter_country']) : '';

                $per_page = 15;
                $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
                $offset = ($paged - 1) * $per_page;
                
                $base_query = "SELECT user_ip, MAX(time) as last_time, COUNT(*) as msg_count, MAX(source) as source, MAX(referrer_url) as ref_url, MAX(current_url) as cur_url, MAX(device) as device_val, MAX(country) as country_val FROM $table_name WHERE 1=1";
                if ($filter_date) {
                    $base_query .= $wpdb->prepare(" AND DATE(time) = %s", $filter_date);
                }
                $base_query .= " GROUP BY user_ip";

                $having_clauses = [];
                if ($traffic_filter === 'direct') {
                    $having_clauses[] = " MAX(referrer_url) = '' AND MAX(source) = 'widget' ";
                } elseif ($traffic_filter === 'ads') {
                    $having_clauses[] = " MAX(current_url) REGEXP 'gclid=|msclkid=|ttclid=|fbclid=|utm_medium=(cpc|ppc|paid|display|banner|cpm)' ";
                } elseif ($traffic_filter === 'organic') {
                    $having_clauses[] = " MAX(referrer_url) REGEXP 'google|bing|yahoo|coccoc|duckduckgo' AND MAX(current_url) NOT REGEXP 'gclid=|msclkid=|ttclid=|fbclid=|utm_medium=(cpc|ppc|paid|display|banner|cpm)' ";
                } elseif ($traffic_filter === 'social') {
                    $having_clauses[] = " (MAX(source) IN ('facebook', 'zalo') OR MAX(referrer_url) REGEXP 'facebook|fb\\.com|instagram|tiktok|zalo|twitter|t\\.co') AND MAX(current_url) NOT REGEXP 'gclid=|msclkid=|ttclid=|fbclid=|utm_medium=(cpc|ppc|paid|display|banner|cpm)' ";
                } elseif ($traffic_filter === 'referring') {
                    $having_clauses[] = " MAX(referrer_url) != '' AND MAX(source) = 'widget' AND MAX(referrer_url) NOT REGEXP 'google|bing|yahoo|coccoc|duckduckgo|facebook|fb\\.com|instagram|tiktok|zalo|twitter|t\\.co' AND MAX(current_url) NOT REGEXP 'gclid=|msclkid=|ttclid=|fbclid=|utm_medium=(cpc|ppc|paid|display|banner|cpm)' ";
                }

                if ($filter_device) {
                    $having_clauses[] = $wpdb->prepare(" MAX(device) = %s ", $filter_device);
                }
                if ($filter_country) {
                    $having_clauses[] = $wpdb->prepare(" MAX(country) = %s ", strtoupper($filter_country));
                }

                $having = "";
                if (!empty($having_clauses)) {
                    $having = " HAVING " . implode(" AND ", $having_clauses);
                }

                $count_query = "SELECT COUNT(*) FROM ($base_query $having) as temp_table";
                $total_threads = $wpdb->get_var($count_query);
                
                $total_pages = ceil($total_threads / $per_page);
                
                $fetch_query = "$base_query $having ORDER BY last_time DESC LIMIT %d OFFSET %d";
                $threads = $wpdb->get_results($wpdb->prepare($fetch_query, $per_page, $offset));
                ?>
                
                <div style="margin-bottom: 15px; display: flex; align-items: center; gap: 10px; background: #fff; padding: 10px 15px; border: 1px solid #ccd0d4; border-radius: 4px;">
                    <form method="get" style="margin: 0; display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                        <input type="hidden" name="page" value="soft-ai-chat-history">
                        <strong>Lọc theo:</strong>
                        <input type="date" name="filter_date" value="<?php echo esc_attr($filter_date); ?>" title="Ngày">
                        <select name="traffic_source">
                            <option value="">Tất cả nguồn (Traffic)</option>
                            <option value="ads" <?php selected($traffic_filter, 'ads'); ?>>Quảng cáo (Ads)</option>
                            <option value="organic" <?php selected($traffic_filter, 'organic'); ?>>Tự nhiên (Organic)</option>
                            <option value="direct" <?php selected($traffic_filter, 'direct'); ?>>Trực tiếp (Direct)</option>
                            <option value="social" <?php selected($traffic_filter, 'social'); ?>>Mạng xã hội (Social)</option>
                            <option value="referring" <?php selected($traffic_filter, 'referring'); ?>>Giới thiệu (Referring)</option>
                        </select>
                        <select name="filter_device">
                            <option value="">Tất cả thiết bị</option>
                            <option value="Desktop" <?php selected($filter_device, 'Desktop'); ?>>Máy tính</option>
                            <option value="Mobile" <?php selected($filter_device, 'Mobile'); ?>>Điện thoại</option>
                            <option value="Tablet" <?php selected($filter_device, 'Tablet'); ?>>Máy tính bảng</option>
                        </select>
                        <input type="text" name="filter_country" value="<?php echo esc_attr($filter_country); ?>" placeholder="Mã QG (VD: VN, US)" style="width: 130px;">
                        
                        <button type="submit" class="button">Lọc</button>
                        <?php if($filter_date || $traffic_filter || $filter_device || $filter_country): ?>
                            <a href="?page=soft-ai-chat-history" class="button">Bỏ lọc</a>
                        <?php endif; ?>
                    </form>
                </div>
                
                <div class="sac-thread-list">
                    <?php if ($threads): foreach ($threads as $th): 
                        $first_char = strtoupper(substr($th->user_ip, 0, 1));
                        $is_numeric_ip = filter_var($th->user_ip, FILTER_VALIDATE_IP);
                        $display_name = $is_numeric_ip ? "Khách (" . $th->user_ip . ")" : $th->user_ip;
                        $time_ago = human_time_diff(strtotime($th->last_time), current_time('timestamp')) . ' trước';

                        $traffic_label = '';
                        if ($th->source === 'widget') {
                            if (!empty($th->cur_url) && preg_match('/gclid=|msclkid=|ttclid=|fbclid=|utm_medium=(cpc|ppc|paid|display|banner|cpm)/i', $th->cur_url)) $traffic_label = ' [Quảng cáo]';
                            elseif (empty($th->ref_url)) $traffic_label = ' [Trực tiếp]';
                            elseif (preg_match('/google|bing|yahoo|coccoc|duckduckgo/i', $th->ref_url)) $traffic_label = ' [Tự nhiên]';
                            elseif (preg_match('/facebook|fb\.com|instagram|tiktok|zalo|twitter|t\.co/i', $th->ref_url)) $traffic_label = ' [Mạng XH]';
                            else $traffic_label = ' [Giới thiệu: ' . parse_url($th->ref_url, PHP_URL_HOST) . ']';
                        }
                        
                        if ($th->source === 'facebook') {
                            $fb_name = get_transient('soft_ai_fb_name_' . $th->user_ip);
                            if ($fb_name && $fb_name !== 'Khách Facebook ẩn danh') {
                                $display_name = $fb_name . ' (' . $th->user_ip . ')';
                            }
                        }
                    ?>
                    <div class="sac-thread-item">
                        <div class="sac-avatar">
                            <?php 
                            if($th->source === 'facebook') echo '🔵';
                            elseif($th->source === 'zalo') echo '🟡';
                            else echo '🌐';
                            ?>
                        </div>
                        <div class="sac-thread-info">
                            <a href="?page=soft-ai-chat-history&view_ip=<?php echo urlencode($th->user_ip); ?>" class="sac-ip-title">
                                <?php echo '[' . strtoupper($th->source) . '] ' . esc_html($display_name) . '<span style="color:#2271b1; font-weight:normal;">' . esc_html($traffic_label) . '</span>'; ?>
                            </a>
                            <div class="sac-thread-meta">
                                Hoạt động gần nhất: <?php echo $time_ago; ?> 
                                <span class="sac-badge"><?php echo $th->msg_count; ?> tin nhắn</span>
                                <span class="sac-badge" style="background:transparent; border:none; color:#888;">
                                    <?php echo $th->device_val ? '💻 ' . esc_html($th->device_val) : ''; ?>
                                    <?php echo $th->country_val ? '🌍 ' . strtoupper(esc_html($th->country_val)) : ''; ?>
                                </span>
                            </div>
                        </div>
                        <div style="display:flex; gap:5px;">
                            <a href="?page=soft-ai-chat-history&view_ip=<?php echo urlencode($th->user_ip); ?>" class="sac-action-btn">Xem chat</a>
                            <form method="post" style="display:inline;">
                                <?php wp_nonce_field('delete_thread_' . $th->user_ip); ?>
                                <input type="hidden" name="delete_thread" value="1">
                                <input type="hidden" name="thread_ip" value="<?php echo esc_attr($th->user_ip); ?>">
                                <button type="submit" class="sac-action-btn sac-del-btn" onclick="return confirm('Xóa cuộc trò chuyện này?')">×</button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; else: ?>
                        <div style="padding:40px; text-align:center; color:#999;">Không tìm thấy lịch sử chat nào.</div>
                    <?php endif; ?>
                </div>

                <?php if ($total_pages > 1): ?>
                <div class="sac-pagination-wrapper">
                    <div class="sac-pagination">
                        <?php 
                        echo paginate_links([
                            'base' => add_query_arg('paged', '%#%'),
                            'add_args' => array_filter(['filter_date' => $filter_date, 'traffic_source' => $traffic_filter, 'filter_device' => $filter_device, 'filter_country' => $filter_country]),
                            'total' => $total_pages,
                            'current' => $paged,
                            'prev_text' => '«',
                            'next_text' => '»'
                        ]); 
                        ?>
                    </div>
                </div>
                <?php endif; ?>

            <?php endif; ?>
        </div>
    </div>
    <?php
}

// ---------------------------------------------------------
// 2. CONTEXT & STATE MANAGER
// ---------------------------------------------------------

class Soft_AI_Context {
    public $user_id;
    public $source;
    
    public function __construct($user_id, $source) {
        $this->user_id = $user_id;
        $this->source = $source;
    }

    public function get($key) {
        if ($this->source === 'widget') {
            return (function_exists('WC') && WC()->session) ? WC()->session->get('soft_ai_' . $key) : null;
        } else {
            $data = get_transient('soft_ai_sess_' . $this->user_id);
            return isset($data[$key]) ? $data[$key] : null;
        }
    }
    
    public function set($key, $val) {
        if ($this->source === 'widget') {
            if (function_exists('WC') && WC()->session) WC()->session->set('soft_ai_' . $key, $val);
        } else {
            $data = get_transient('soft_ai_sess_' . $this->user_id) ?: [];
            $data[$key] = $val;
            set_transient('soft_ai_sess_' . $this->user_id, $data, 24 * HOUR_IN_SECONDS);
        }
    }

    public function add_to_cart($product_id, $qty = 1, $variation_id = 0, $variation = []) {
        if ($this->source === 'widget' && function_exists('WC')) {
            WC()->cart->add_to_cart($product_id, $qty, $variation_id, $variation);
        } else {
            $cart = $this->get('cart') ?: [];
            $cart_key = $variation_id ? $variation_id : $product_id;
            
            if (isset($cart[$cart_key])) {
                $cart[$cart_key]['qty'] += $qty;
            } else {
                $cart[$cart_key] = [
                    'qty' => $qty, 
                    'product_id' => $product_id, 
                    'variation_id' => $variation_id,
                    'variation' => $variation 
                ];
            }
            $this->set('cart', $cart);
        }
    }

    public function empty_cart() {
        if ($this->source === 'widget' && function_exists('WC')) WC()->cart->empty_cart();
        else {
            $this->set('cart', []);
            $this->set('coupons', []); 
        }
    }

    public function get_cart_count() {
        if ($this->source === 'widget' && function_exists('WC')) return WC()->cart->get_cart_contents_count();
        else {
            $c = 0; $cart = $this->get('cart') ?: [];
            foreach($cart as $i) $c += $i['qty'];
            return $c;
        }
    }

    public function get_cart_total_string() {
        if ($this->source === 'widget' && function_exists('WC')) return WC()->cart->get_cart_total();
        else {
            $total = 0; $cart = $this->get('cart') ?: [];
            foreach($cart as $pid => $item) {
                $p = function_exists('wc_get_product') ? wc_get_product($pid) : null;
                if($p) $total += ($p->get_price() * $item['qty']);
            }
            return function_exists('wc_price') ? wc_price($total) : number_format($total) . 'đ';
        }
    }
}

// ---------------------------------------------------------
// 3. CORE LOGIC
// ---------------------------------------------------------

function soft_ai_notify_admin_by_email($question, $platform, $user_id) {
    $options = get_option('soft_ai_chat_settings');
    $admin_email_setting = $options['admin_email_notify'] ?? get_option('admin_email');

    if (empty($admin_email_setting)) return;

    $admin_emails = array_map('trim', explode(',', $admin_email_setting));
    $admin_emails = array_filter($admin_emails, 'is_email');

    if (empty($admin_emails)) return;

    $subject = "[Soft AI Chat] Tin nhắn mới từ " . strtoupper($platform);
    $body = "Bạn có tin nhắn mới từ khách hàng trên website.<br/>\n\n";
    $body .= "------------------------------------------<br/>\n";
    $body .= "Nền tảng: " . $platform . "<br/>\n";
    $body .= "Mã khách hàng/IP: " . $user_id . "<br/>\n";
    $body .= "Nội dung: " . $question . "<br/>\n";
    $body .= "------------------------------------------<br/>\n\n";
    $body .= "Đi tới Live Chat để trả lời: " . admin_url('admin.php?page=soft-ai-live-chat');

    $headers = array('Content-Type: text/html; charset=UTF-8');

    wp_mail($admin_emails, $subject, $body, $headers);
}

function soft_ai_clean_content($content) {
    if (!is_string($content)) return '';
    $content = strip_shortcodes($content);
    $content = preg_replace('/\[\/?et_pb_[^\]]+\]/', '', $content);
    $content = wp_strip_all_tags($content);
    $content = preg_replace('/\s+/', ' ', $content);
    return mb_substr(trim($content), 0, 1500);
}

function soft_ai_chat_get_context($question) {
    global $wpdb;

    $rag_context = "";
    $table_rag = $wpdb->prefix . 'soft_ai_rag_docs';
    
    $search_terms = array_filter(explode(' ', mb_strtolower(trim($question))), function($w) {
        return mb_strlen($w) > 2;
    });

    if (!empty($search_terms)) {
        $likes = [];
        $params = [];
        foreach ($search_terms as $term) {
            $likes[] = "content LIKE %s";
            $params[] = '%' . $wpdb->esc_like($term) . '%';
        }
        $where = implode(' OR ', $likes);
        $rag_docs = $wpdb->get_results($wpdb->prepare("SELECT title, content FROM $table_rag WHERE $where LIMIT 3", $params));
        
        foreach ($rag_docs as $doc) {
            $content_lower = mb_strtolower($doc->content);
            $pos = 0;
            foreach ($search_terms as $term) {
                $p = mb_strpos($content_lower, $term);
                if ($p !== false) {
                    $pos = $p;
                    break;
                }
            }
            $start = max(0, $pos - 200); 
            $snippet = mb_substr($doc->content, $start, 800); 
            $rag_context .= "--- Source (RAG Knowledge Base): {$doc->title} ---\nContent: ...{$snippet}...\n\n";
        }
    }

    $args = ['post_type' => ['post', 'page', 'product'], 'post_status' => 'publish', 'posts_per_page' => 4, 's' => $question, 'orderby' => 'relevance'];
    $posts = get_posts($args);

    $wp_context = "";
    if ($posts) {
        foreach ($posts as $post) {
            $info = "";
            if ($post->post_type === 'product' && function_exists('wc_get_product')) {
                $p = wc_get_product($post->ID);
                if ($p) $info = " | Price: " . $p->get_price_html() . " | Status: " . $p->get_stock_status();
            }
            $clean_body = soft_ai_clean_content($post->post_content);
            $wp_context .= "--- Source (Website): {$post->post_title} ---\nLink: " . get_permalink($post->ID) . $info . "\nContent: $clean_body\n\n";
        }
    }
    
    $final_context = $rag_context . $wp_context;
    return $final_context ?: "No specific website content or Knowledge Base found for this query.";
}

function soft_ai_log_chat($question, $answer, $source = 'widget', $provider_override = '', $model_override = '', $current_url = '', $referrer_url = '', $user_id_override = '') {
    global $wpdb;
    $opt = get_option('soft_ai_chat_settings');
    
    $ip = !empty($user_id_override) ? $user_id_override : ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');

    if (!empty($question)) {
        soft_ai_update_stats_table($ip, 'user_msg');
    }
    if ($provider_override === 'system_switch' || $provider_override === 'live_user') {
        soft_ai_update_stats_table($ip, 'takeover');
    } elseif (!empty($answer)) {
        soft_ai_update_stats_table($ip, 'ai_reply');
    }
    
    $is_live = (strpos($provider_override, 'live_') !== false);
    if (empty($opt['save_history']) && !$is_live) return;

    $wpdb->insert($wpdb->prefix . 'soft_ai_chat_logs', [
        'time' => current_time('mysql'),
        'user_ip' => $ip,
        'provider' => $provider_override ?: ($opt['provider'] ?? 'unknown'),
        'model' => $model_override ?: ($opt['model'] ?? 'unknown'),
        'question' => $question,
        'answer' => $answer,
        'source' => $source,
        'current_url' => $current_url,
        'referrer_url' => $referrer_url,
        'device' => soft_ai_get_device(),
        'country' => soft_ai_get_country()
    ]);
}

function soft_ai_clean_text_for_social($content) {
    $content = html_entity_decode($content, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $content = preg_replace('/^\|?\s*[-:]+\s*(\|\s*[-:]+\s*)+\|?\s*$/m', '', $content);
    $content = preg_replace('/^\|\s*/m', '', $content);
    $content = preg_replace('/\s*\|$/m', '', $content);
    $content = str_replace('|', ' - ', $content);
    $content = preg_replace('/!\[([^\]]*)\]\(([^)]+)\)/', '$2', $content);
    $content = preg_replace('/\[([^\]]+)\]\(([^)]+)\)/', '$1: $2', $content);
    $content = str_replace(['**', '__', '`'], '', $content);
    $content = preg_replace('/^#+\s*/m', '', $content);
    return trim(wp_strip_all_tags($content));
}

function soft_ai_generate_answer($question, $platform = 'widget', $user_id = '', $current_url = '', $referrer_url = '') {
    global $wpdb;
    if (empty($user_id)) $user_id = get_current_user_id() ?: md5($_SERVER['REMOTE_ADDR']);
    $context = new Soft_AI_Context($user_id, $platform);
    $options = get_option('soft_ai_chat_settings');
    
    $clean_q = mb_strtolower(trim($question));
    
    $admin_timeout_mins = floatval($options['admin_timeout'] ?? 10);
    $last_admin_time = $context->get('admin_last_reply_time');
    
    $exit_keywords = ['thoát', 'exit', 'bye', 'bot', 'gặp bot'];
    if (in_array($clean_q, $exit_keywords)) {
        $context->set('admin_last_reply_time', 0);
        return "Đã quay lại chế độ AI Bot 🤖. Bạn cần giúp gì không?";
    }

    $human_keywords = ['human', 'người thật', 'nhân viên', 'tư vấn viên', 'gặp người', 'chat với người', 'support', 'live chat'];
    if (in_array($clean_q, $human_keywords)) {
        $context->set('admin_last_reply_time', time());
        $msg = "Đã chuyển sang chế độ Chat với Nhân Viên 🔴.\nVui lòng nhắn tin, nhân viên sẽ trả lời bạn sớm nhất có thể.";
        soft_ai_log_chat($question, $msg, $platform, 'system_switch', '', $current_url, $referrer_url, $user_id);
        return $msg;
    }

    if ($last_admin_time && (time() - $last_admin_time) < ($admin_timeout_mins * 60)) {
        soft_ai_log_chat($question, '', $platform, 'live_user', 'human', $current_url, $referrer_url, $user_id);
        return '[WAIT_FOR_HUMAN]';
    }

    $current_step = $context->get('bot_collecting_info_step');
    $cancel_keywords = ['huỷ', 'hủy', 'cancel', 'thôi', 'stop', 'thoát'];
    if (in_array($clean_q, $cancel_keywords)) {
        $context->set('bot_collecting_info_step', null);
        return "Đã hủy thao tác hiện tại. Mình có thể giúp gì khác không?";
    }

    if ($current_step && class_exists('WooCommerce')) {
        $response = soft_ai_handle_ordering_steps($question, $current_step, $context);
        if ($platform === 'facebook' || $platform === 'zalo') {
            return soft_ai_clean_text_for_social($response);
        }
        return $response;
    }

    $checkout_triggers = ['thanh toán', 'thanh toan', 'xác nhận', 'xac nhan', 'chốt đơn', 'chot don', 'đặt hàng', 'dat hang', 'mua ngay', 'pay'];
    $is_checkout_intent = false;
    foreach ($checkout_triggers as $trigger) {
        if (strpos($clean_q, $trigger) !== false) {
            $is_checkout_intent = true;
            break;
        }
    }

    if ($is_checkout_intent && class_exists('WooCommerce')) {
        $response = soft_ai_process_order_logic(['action' => 'checkout'], $context);
        if ($platform === 'facebook' || $platform === 'zalo') return soft_ai_clean_text_for_social($response);
        return $response;
    }

    $provider = $options['provider'] ?? 'groq';
    $model = $options['model'] ?? 'openai/gpt-oss-120b';
    
    $site_context = soft_ai_chat_get_context($question);
    $user_instruction = $options['system_prompt'] ?? '';
    
    $system_prompt = "You are a helpful AI assistant for this website.\n" .
                     ($user_instruction ? "Additional Persona: $user_instruction\n" : "") .
                     "Website & RAG Knowledge Base Context:\n" . $site_context . "\n\n" .
                     "CRITICAL INSTRUCTIONS:\n" . 
                     "1. If user wants to BUY/ORDER/FIND products, return STRICT JSON only (no markdown):\n" .
                     "   {\"action\": \"find_product\", \"query\": \"product name\"}\n" .
                     "   {\"action\": \"list_products\"}\n" .
                     "   {\"action\": \"check_cart\"}\n" .
                     "   {\"action\": \"checkout\"}\n" .
                     "   {\"action\": \"list_coupons\"}\n" .
                     "   {\"action\": \"apply_coupon\", \"code\": \"CODE_HERE\"}\n" .
                     "2. If user asks general discovery questions like 'bán gì', 'có gì', 'sản phẩm gì', 'menu', use action 'list_products'.\n" .
                     "3. If user asks about 'mã giảm giá', 'coupon', 'voucher', 'khuyến mãi', 'ưu đãi', 'discount', use action 'list_coupons'.\n" .
                     "4. If user wants to apply a code (e.g. 'dùng mã ABC', 'nhập mã XYZ', 'áp dụng mã...'), use action 'apply_coupon'.\n" .
                     "5. For general chat or questions related to the RAG context, answer normally in Vietnamese based strictly on the context provided.\n" .
                     "6. If you use tables, use standard Markdown table format. Keep tables simple with 2-3 columns maximum for mobile view." .
                     "7. If unknown, admit it politely.";

    $ai_response = soft_ai_chat_call_api($provider, $model, $system_prompt, $question, $options);
    if (is_wp_error($ai_response)) return "Lỗi hệ thống: " . $ai_response->get_error_message();

    $clean_response = trim($ai_response);
    if (preg_match('/```json\s*(.*?)\s*```/s', $clean_response, $matches)) {
        $clean_response = $matches[1];
    } elseif (preg_match('/```\s*(.*?)\s*```/s', $clean_response, $matches)) {
        $clean_response = $matches[1];
    }

    $intent = json_decode($clean_response, true);
    
    if (json_last_error() === JSON_ERROR_NONE && isset($intent['action']) && class_exists('WooCommerce')) {
        $response = soft_ai_process_order_logic($intent, $context);
        if ($platform === 'facebook' || $platform === 'zalo') return soft_ai_clean_text_for_social($response);
        return $response;
    }

    if ($platform === 'facebook' || $platform === 'zalo') {
        return soft_ai_clean_text_for_social($clean_response);
    }
    return $clean_response;
}

function soft_ai_process_order_logic($intent, $context) {
    $action = $intent['action'];
    $source = $context->source;

    switch ($action) {
        case 'list_coupons':
            $args = ['post_type' => 'shop_coupon', 'post_status' => 'publish', 'posts_per_page' => 5];
            $coupons = get_posts($args);
            if (empty($coupons)) return "Hiện tại không có mã giảm giá nào ạ.";

            $msg = "Dạ, shop đang có các mã ưu đãi này:\n";
            foreach ($coupons as $c) {
                $code = $c->post_title;
                $wc_coupon = new WC_Coupon($code);
                if ($wc_coupon->get_usage_limit() > 0 && $wc_coupon->get_usage_count() >= $wc_coupon->get_usage_limit()) continue;
                if ($wc_coupon->get_date_expires() && $wc_coupon->get_date_expires()->getTimestamp() < time()) continue;

                $desc = $c->post_excerpt ? "({$c->post_excerpt})" : "";
                $amount = strip_tags(wc_price($wc_coupon->get_amount()));
                if($wc_coupon->get_discount_type() == 'percent') $amount = $wc_coupon->get_amount() . '%';
                
                $msg .= "- **$code** $desc: Giảm $amount\n";
            }
            return $msg . "\nBạn muốn dùng mã nào cứ nhắn 'Dùng mã [CODE]' nhé!";

        case 'apply_coupon':
            $code = strtoupper(sanitize_text_field($intent['code'] ?? ''));
            if (!$code) return "Bạn chưa nhập mã. Vui lòng nhập mã cụ thể.";

            if ($source === 'widget' && function_exists('WC')) {
                if (!WC()->cart->has_discount($code)) {
                    $res = WC()->cart->apply_coupon($code);
                    if ($res === true) {
                        return "✅ Đã áp dụng mã **$code** thành công! Tổng đơn hiện tại: " . WC()->cart->get_cart_total();
                    } else {
                        return "❌ Mã này không hợp lệ hoặc không áp dụng được cho đơn này ạ.";
                    }
                } else {
                    return "Mã này đã được áp dụng rồi ạ.";
                }
            } else {
                $saved_coupons = $context->get('coupons') ?: [];
                if (!in_array($code, $saved_coupons)) {
                    $saved_coupons[] = $code;
                    $context->set('coupons', $saved_coupons);
                    return "✅ Đã lưu mã **$code**. Sẽ áp dụng khi tạo đơn.";
                }
                return "Mã này đã lưu rồi ạ.";
            }

        case 'list_products':
            $args = ['limit' => 12, 'status' => 'publish', 'orderby' => 'rand', 'order' => 'ASC'];
            $products = wc_get_products($args);

            if (empty($products)) return "Dạ hiện tại shop chưa cập nhật sản phẩm lên web ạ.";

            $msg = "Dạ, bên em đang có những sản phẩm nổi bật này ạ:<br>";
            if ($source !== 'widget') $msg = "Dạ, bên em đang có những sản phẩm nổi bật này ạ:\n";

            foreach ($products as $p) {
                $price = $p->get_price_html();
                $name = $p->get_name();
                
                if ($source === 'widget') {
                    $img_id = $p->get_image_id();
                    $img_url = $img_id ? wp_get_attachment_image_url($img_id, 'thumbnail') : wc_placeholder_img_src();
                    $msg .= "
                    <div style='display:flex; align-items:center; gap:10px; margin-top:10px; border:1px solid #f0f0f0; padding:8px; border-radius:8px; background:#fff;'>
                        <img src='{$img_url}' style='width:50px; height:50px; object-fit:cover; border-radius:6px; flex-shrink:0;'>
                        <div style='font-size:13px; line-height:1.4;'>
                            <div style='font-weight:bold; color:#333;'>{$name}</div>
                            <div style='color:#d63031; font-weight:600;'>{$price}</div>
                        </div>
                    </div>";
                } else {
                    $plain_price = strip_tags(wc_price($p->get_price()));
                    $msg .= "- {$name} ({$plain_price})\n";
                }
            }
            $suffix = ($source === 'widget') ? "<br>Bạn quan tâm món nào nhắn tên để em tư vấn nhé!" : "\nBạn quan tâm món nào nhắn tên để em tư vấn nhé!";
            return $msg . $suffix;

        case 'find_product':
            $query = sanitize_text_field($intent['query'] ?? '');
            $products = wc_get_products(['status' => 'publish', 'limit' => 1, 's' => $query]);
            
            if (!empty($products)) {
                $p = $products[0];
                if (!$p->is_in_stock()) return "Sản phẩm " . $p->get_name() . " hiện đang hết hàng ạ.";

                $context->set('pending_product_id', $p->get_id());
                $attributes = $p->get_attributes();
                $attr_keys = array_keys($attributes); 
                
                if (!empty($attr_keys) && $p->is_type('variable')) {
                    $group_attr_key = null;
                    $group_terms = [];
                    $keywords = ['người lớn', 'trẻ em', 'em bé', 'nguoi lon', 'tre em', 'em be', 'adult', 'child', 'infant', 'người', 'khách'];

                    foreach ($attr_keys as $attr_key) {
                        $terms = wc_get_product_terms($p->get_id(), $attr_key, array('fields' => 'names'));
                        if (!is_wp_error($terms) && !empty($terms)) {
                            foreach ($terms as $term) {
                                $lower_term = mb_strtolower($term);
                                foreach ($keywords as $kw) {
                                    if (strpos($lower_term, $kw) !== false) {
                                        $group_attr_key = $attr_key;
                                        $group_terms = $terms;
                                        break 3;
                                    }
                                }
                            }
                        }
                    }

                    $normal_attrs = [];
                    if ($group_attr_key) {
                        foreach ($attr_keys as $k) {
                            if ($k !== $group_attr_key) $normal_attrs[] = $k;
                        }
                        $context->set('group_attr_key', $group_attr_key);
                        $context->set('group_qty_queue', $group_terms);
                        $context->set('group_qty_answers', []);
                    } else {
                        $normal_attrs = $attr_keys;
                        $context->set('group_attr_key', null);
                    }

                    $context->set('attr_queue', $normal_attrs);
                    $context->set('attr_answers', []); 
                    $context->set('bot_collecting_info_step', 'process_attribute_loop'); 
                    $question = soft_ai_ask_next_attribute($context, $p);
                    return ($source == 'widget') ? "Tìm thấy: <b>" . $p->get_name() . "</b>.<br>" . $question : "Tìm thấy: " . $p->get_name() . ".\n" . $question;
                } else {
                    $context->set('bot_collecting_info_step', 'ask_quantity');
                    return "Đã tìm thấy " . $p->get_name() . ". Bạn muốn lấy số lượng bao nhiêu?";
                }
            }
            return "Xin lỗi, mình không tìm thấy sản phẩm nào khớp với '$query'.";

        case 'check_cart':
            $count = $context->get_cart_count();
            return $count > 0 
                ? "Giỏ hàng có $count sản phẩm (" . $context->get_cart_total_string() . "). Gõ 'Thanh toán' để đặt hàng nhé." 
                : "Giỏ hàng của bạn đang trống.";

        case 'checkout':
            if ($context->get_cart_count() == 0) return "Giỏ hàng trống. Hãy chọn sản phẩm trước nhé!";
            
            $has_info = false;
            $name = '';
            
            if ($source === 'widget' && WC()->customer->get_billing_first_name() && WC()->customer->get_billing_email()) {
                $has_info = true; 
                $name = WC()->customer->get_billing_first_name();
            } else {
                $saved = $context->get('user_info');
                if (!empty($saved['name']) && !empty($saved['email'])) { 
                    $has_info = true; 
                    $name = $saved['name']; 
                }
            }

            if ($has_info) {
                return soft_ai_present_payment_gateways($context, "Chào $name! Bạn muốn thanh toán qua đâu?");
            } else {
                $context->set('bot_collecting_info_step', 'fullname');
                return "Để đặt hàng, cho em xin Họ và Tên của bạn ạ?";
            }
            break;
    }
    return "Tôi chưa hiểu yêu cầu này. Bạn có thể nói rõ hơn không?";
}

function soft_ai_handle_ordering_steps($message, $step, $context) {
    $clean_message = trim($message);
    $source = $context->source;

    switch ($step) {
        case 'process_attribute_loop':
            $current_slug = $context->get('current_asking_attr');
            $valid_options = $context->get('valid_options_for_' . $current_slug);
            $is_valid = false;
            
            if (empty($valid_options)) {
                $is_valid = true; 
            } else {
                foreach ($valid_options as $opt) {
                    if (mb_strtolower(trim($opt)) === mb_strtolower($clean_message)) {
                        $is_valid = true;
                        $clean_message = $opt; 
                        break;
                    }
                }
            }

            if (!$is_valid) {
                $label = wc_attribute_label($current_slug);
                $list_str = implode(', ', $valid_options);
                return "⚠️ Dạ shop không có $label '{$message}' ạ.\nVui lòng chỉ chọn một trong các loại sau: **$list_str**";
            }

            $answers = $context->get('attr_answers') ?: [];
            $answers[$current_slug] = $clean_message;
            $context->set('attr_answers', $answers);
            $context->set('valid_options_for_' . $current_slug, null); 

            $p = wc_get_product($context->get('pending_product_id'));
            return soft_ai_ask_next_attribute($context, $p);

        case 'process_group_qty_loop':
            $current_term = $context->get('current_asking_group_term');
            $qty = intval($clean_message);
            if ($qty < 0) return "Số lượng không hợp lệ. Vui lòng nhập lại số lượng cho **$current_term** (nhập 0 nếu không có):";
            
            $answers = $context->get('group_qty_answers') ?: [];
            if ($qty > 0) {
                $answers[$current_term] = $qty;
            }
            $context->set('group_qty_answers', $answers);

            $pid = $context->get('pending_product_id');
            $p = wc_get_product($pid);
            if (!$p) return "Có lỗi xảy ra, không tìm thấy sản phẩm.";

            return soft_ai_ask_next_group_qty($context, $p);

        case 'ask_quantity':
            $qty = intval($clean_message);
            if ($qty <= 0) return "Số lượng phải lớn hơn 0. Vui lòng nhập lại:";
            
            $pid = $context->get('pending_product_id');
            $p = wc_get_product($pid);
            
            if ($p) {
                $var_id = 0; $var_data = [];
                
                if ($p->is_type('variable')) {
                    $collected = $context->get('attr_answers') ?: [];
                    $var_data = [];
                    foreach ($collected as $attr_key => $user_val_name) {
                        $slug_val = $user_val_name; 
                        if (taxonomy_exists($attr_key)) {
                            $term = get_term_by('name', $user_val_name, $attr_key);
                            if ($term) $slug_val = $term->slug;
                        } else {
                            $slug_val = sanitize_title($user_val_name);
                        }
                        $var_data['attribute_' . $attr_key] = $slug_val;
                    }
                    $data_store = new WC_Product_Data_Store_CPT();
                    $var_id = $data_store->find_matching_product_variation($p, $var_data);
                    if (!$var_id) return "Xin lỗi, phiên bản bạn chọn hiện không tồn tại hoặc đã hết hàng. Vui lòng chọn lại.";
                }

                $context->add_to_cart($pid, $qty, $var_id, $var_data);
                $context->set('bot_collecting_info_step', null);
                $total = $context->get_cart_total_string();
                return "✅ Đã thêm vào giỏ ($qty cái). Tổng tạm tính: $total.\nGõ 'Thanh toán' để chốt đơn hoặc hỏi mua tiếp.";
            }
            return "Có lỗi xảy ra với sản phẩm. Vui lòng tìm lại.";

        case 'fullname':
            $context->set('temp_name', $clean_message);
            if ($source === 'widget') WC()->customer->set_billing_first_name($clean_message);
            $context->set('bot_collecting_info_step', 'phone');
            return "Chào $clean_message, cho em xin Số điện thoại liên hệ?";

        case 'phone':
            if (!preg_match('/^[0-9]{9,12}$/', $clean_message)) return "Số điện thoại không hợp lệ. Vui lòng nhập lại:";
            $context->set('temp_phone', $clean_message);
            if ($source === 'widget') WC()->customer->set_billing_phone($clean_message);
            $context->set('bot_collecting_info_step', 'email');
            return "Dạ, cho em xin địa chỉ Email để gửi thông tin đơn hàng và thanh toán ạ?";

        case 'email':
            if (!is_email($clean_message)) return "Email không hợp lệ. Vui lòng nhập lại (ví dụ: ten@gmail.com):";
            $context->set('temp_email', $clean_message);
            if ($source === 'widget') WC()->customer->set_billing_email($clean_message);
            $context->set('bot_collecting_info_step', 'address');
            return "Cuối cùng, cho em xin Địa chỉ giao hàng cụ thể ạ?";

        case 'address':
            $context->set('temp_address', $clean_message);
            if ($source === 'widget') {
                WC()->customer->set_billing_address_1($clean_message);
                WC()->customer->save();
            } else {
                $context->set('user_info', [
                    'name' => $context->get('temp_name'),
                    'phone' => $context->get('temp_phone'),
                    'email' => $context->get('temp_email'),
                    'address' => $clean_message
                ]);
            }
            return soft_ai_present_payment_gateways($context, "Đã lưu địa chỉ. Bạn chọn hình thức thanh toán nào?");

        case 'payment_method':
            $method_key = mb_strtolower($clean_message);
            if (strpos($method_key, 'vietqr') !== false || strpos($method_key, 'chuyển khoản') !== false || strpos($method_key, 'qr') !== false) {
                return soft_ai_finalize_order($context, 'vietqr_custom');
            }
            if (strpos($method_key, 'paypal') !== false) {
                return soft_ai_finalize_order($context, 'paypal_custom');
            }

            $gateways = WC()->payment_gateways->get_available_payment_gateways();
            $selected = null;
            foreach ($gateways as $g) {
                if (stripos($g->title, $clean_message) !== false || stripos($g->id, $clean_message) !== false) { 
                    $selected = $g; break; 
                }
            }
            if (!$selected && (stripos($clean_message, 'cod') !== false || stripos($clean_message, 'mặt') !== false)) {
                $selected = $gateways['cod'] ?? null;
            }

            if (!$selected) return "Phương thức chưa đúng. Vui lòng nhập lại (ví dụ: VietQR, PayPal, COD).";
            return soft_ai_finalize_order($context, $selected);
    }
    return "";
}

function soft_ai_ask_next_attribute($context, $product) {
    $queue = $context->get('attr_queue');
    if (empty($queue)) {
        if ($context->get('group_attr_key')) {
            $context->set('bot_collecting_info_step', 'process_group_qty_loop');
            return soft_ai_ask_next_group_qty($context, $product);
        }

        $context->set('bot_collecting_info_step', 'ask_quantity');
        return "Dạ bạn đã chọn đủ thông tin. Bạn muốn lấy số lượng bao nhiêu ạ?";
    }
    $current_slug = array_shift($queue);
    $context->set('attr_queue', $queue); 
    $context->set('current_asking_attr', $current_slug); 
    
    $terms = wc_get_product_terms($product->get_id(), $current_slug, array('fields' => 'names'));
    $options_text = "";
    if (!empty($terms) && !is_wp_error($terms)) {
        $context->set('valid_options_for_' . $current_slug, $terms);
        $options_text = "\n(" . implode(', ', $terms) . ")";
    } else {
        $context->set('valid_options_for_' . $current_slug, []);
    }
    $label = wc_attribute_label($current_slug);
    return "Bạn chọn **$label** loại nào?$options_text";
}

function soft_ai_ask_next_group_qty($context, $product) {
    $queue = $context->get('group_qty_queue');
    if (empty($queue)) {
        return soft_ai_add_group_variations_to_cart($context, $product);
    }
    $current_term = array_shift($queue);
    $context->set('group_qty_queue', $queue);
    $context->set('current_asking_group_term', $current_term);
    return "Bạn muốn lấy số lượng cho nhóm **" . $current_term . "** là bao nhiêu? (Nhập 0 nếu không có)";
}

function soft_ai_add_group_variations_to_cart($context, $product) {
    $group_answers = $context->get('group_qty_answers');
    $normal_answers = $context->get('attr_answers') ?: [];
    $group_attr_key = $context->get('group_attr_key');
    $pid = $product->get_id();
    
    if (empty($group_answers)) {
        $context->set('bot_collecting_info_step', null);
        return "Bạn đã không chọn số lượng cho bất kỳ nhóm nào. Đã hủy thêm vào giỏ. Bạn cần giúp gì khác không?";
    }

    $data_store = new WC_Product_Data_Store_CPT();
    $added_count = 0;
    $total_qty = 0;

    foreach ($group_answers as $term_name => $qty) {
        if ($qty <= 0) continue;

        $var_data = [];
        foreach ($normal_answers as $attr_key => $user_val_name) {
            $slug_val = $user_val_name; 
            if (taxonomy_exists($attr_key)) {
                $term = get_term_by('name', $user_val_name, $attr_key);
                if ($term) $slug_val = $term->slug;
            } else {
                $slug_val = sanitize_title($user_val_name);
            }
            $var_data['attribute_' . $attr_key] = $slug_val;
        }
        
        $group_slug_val = $term_name;
        if (taxonomy_exists($group_attr_key)) {
            $term = get_term_by('name', $term_name, $group_attr_key);
            if ($term) $group_slug_val = $term->slug;
        } else {
            $group_slug_val = sanitize_title($term_name);
        }
        $var_data['attribute_' . $group_attr_key] = $group_slug_val;

        $var_id = $data_store->find_matching_product_variation($product, $var_data);
        
        if ($var_id) {
            $context->add_to_cart($pid, $qty, $var_id, $var_data);
            $added_count++;
            $total_qty += $qty;
        }
    }

    $context->set('bot_collecting_info_step', null);
    if ($added_count > 0) {
        $total = $context->get_cart_total_string();
        return "✅ Đã thêm thành công vào giỏ ($total_qty vé/sản phẩm). Tổng tạm tính: $total.\nGõ 'Thanh toán' để chốt đơn hoặc hỏi mua tiếp.";
    } else {
        return "Xin lỗi, phiên bản bạn chọn hiện không tồn tại hoặc đã hết hàng. Vui lòng tìm và chọn lại.";
    }
}

function soft_ai_present_payment_gateways($context, $msg) {
    $gateways = WC()->payment_gateways->get_available_payment_gateways();
    $opts = get_option('soft_ai_chat_settings');
    $list = "";
    $prefix = ($context->source == 'widget') ? "<br>• " : "\n- ";

    foreach ($gateways as $g) $list .= $prefix . $g->get_title();
    
    if (!empty($opts['vietqr_bank']) && !empty($opts['vietqr_acc'])) $list .= $prefix . "VietQR (Chuyển khoản nhanh)";
    if (!empty($opts['paypal_me'])) $list .= $prefix . "PayPal";

    $context->set('bot_collecting_info_step', 'payment_method');
    return $msg . $list;
}

function soft_ai_finalize_order($context, $gateway_or_code) {
    try {
        $order = wc_create_order();
        $opts = get_option('soft_ai_chat_settings');

        if ($context->source === 'widget' && function_exists('WC')) {
            foreach (WC()->cart->get_cart() as $values) $order->add_product($values['data'], $values['quantity']);
        } else {
            $cart = $context->get('cart') ?: [];
            foreach ($cart as $key => $item) {
                $pid = isset($item['product_id']) ? $item['product_id'] : $key;
                $vid = isset($item['variation_id']) ? $item['variation_id'] : 0;
                $p = wc_get_product($vid ? $vid : $pid);
                if ($p) $order->add_product($p, $item['qty']);
            }
            $stored_coupons = $context->get('coupons') ?: [];
            foreach($stored_coupons as $code) {
                $order->apply_coupon($code);
            }
        }

        $name    = $context->get('temp_name');
        $phone   = $context->get('temp_phone');
        $email   = $context->get('temp_email');
        $address = $context->get('temp_address');

        if ($context->source === 'widget' && function_exists('WC') && WC()->customer) {
            if (empty($name))    $name = WC()->customer->get_billing_first_name();
            if (empty($phone))   $phone = WC()->customer->get_billing_phone();
            if (empty($email))   $email = WC()->customer->get_billing_email();
            if (empty($address)) $address = WC()->customer->get_billing_address_1();
        }

        $parts = explode(' ', trim($name));
        $last_name  = (count($parts) > 1) ? array_pop($parts) : '';
        $first_name = implode(' ', $parts);
        if (empty($first_name)) $first_name = $name;

        $billing_info = [
            'first_name' => $first_name, 'last_name'  => $last_name, 'phone' => $phone,
            'email' => $email ?: 'no-email@example.com', 'address_1'  => $address, 'country' => 'VN',
        ];
        $order->set_address($billing_info, 'billing');
        $order->set_address($billing_info, 'shipping');

        $extra_msg = "";
        
        if ($gateway_or_code === 'vietqr_custom') {
            $order->set_payment_method('bacs');
            $order->set_payment_method_title('VietQR (Qua Chat)');
            $order->calculate_totals();
            
            $bacs_accounts = get_option('woocommerce_bacs_accounts');
            $bank = ''; $acc = ''; $name_acc = '';
            if (!empty($bacs_accounts) && is_array($bacs_accounts)) {
                $account = $bacs_accounts[0];
                $bank = str_replace(' ', '', $account['bank_name']); 
                $acc  = str_replace(' ', '', $account['account_number']);
                $name_acc = str_replace(' ', '%20', $account['account_name']);
            } else {
                 $bank = str_replace(' ', '', $opts['vietqr_bank'] ?? '');
                 $acc  = str_replace(' ', '', $opts['vietqr_acc'] ?? '');
                 $name_acc = str_replace(' ', '%20', $opts['vietqr_name'] ?? '');
            }
            $amt = intval($order->get_total()); 
            $desc = "DH" . $order->get_id(); 
            if ($bank && $acc) {
                $qr_url = "https://img.vietqr.io/image/{$bank}-{$acc}-compact.jpg?amount={$amt}&addInfo={$desc}&accountName={$name_acc}";
                $extra_msg = "\n\n⬇️ **Quét mã để thanh toán:**\n![VietQR]($qr_url)";
                if ($context->source == 'widget') $extra_msg = "<br><br><b>Quét mã để thanh toán:</b><br><img src='$qr_url' style='max-width:100%; border-radius:8px;'>";
            }
        } elseif ($gateway_or_code === 'paypal_custom') {
            $order->set_payment_method('paypal');
            $order->set_payment_method_title('PayPal (Liên kết qua Chat)');
            $order->calculate_totals();
            $raw_user = $opts['paypal_me'] ?? '';
            $raw_user = str_replace(['https://', 'http://', 'paypal.me/', '/'], '', $raw_user);
            $currency = get_woocommerce_currency(); 
            $amt = $order->get_total();
            $pp_link = "https://paypal.me/{$raw_user}/{$amt}{$currency}";
            $extra_msg = "\n\n👉 [Nhấn để thanh toán PayPal]($pp_link)";
            if ($context->source == 'widget') $extra_msg = "<br><br><a href='$pp_link' target='_blank' style='background:#0070ba;color:white;padding:10px 15px;border-radius:5px;text-decoration:none;font-weight:bold;'>Thanh toán ngay với PayPal</a>";
        } else {
            $order->set_payment_method($gateway_or_code);
            $order->calculate_totals();
        }

        $order->update_status('on-hold', "Đơn hàng được tạo qua Soft AI Chat. IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'Không xác định'));
        $context->empty_cart();
        $context->set('bot_collecting_info_step', null);

        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        soft_ai_update_stats_table($ip, 'ai_order');

        return "🎉 ĐẶT HÀNG THÀNH CÔNG!\nMã đơn: #" . $order->get_id() . "\nEmail xác nhận đã gửi tới " . $billing_info['email'] . "." . $extra_msg;

    } catch (Exception $e) {
        return "Lỗi khi tạo đơn: " . $e->getMessage();
    }
}

// ---------------------------------------------------------
// 3.5. CRON & TRANSCRIPT EMAILS
// ---------------------------------------------------------

function soft_ai_add_cron_interval($schedules) {
    $schedules['soft_ai_5min'] = array(
        'interval' => 300,
        'display'  => esc_html__('Mỗi 5 phút'),
    );
    return $schedules;
}

function soft_ai_process_transcripts() {
    global $wpdb;
    $options = get_option('soft_ai_chat_settings');
    $timeout_mins = intval($options['transcript_timeout'] ?? 0);
    
    if ($timeout_mins <= 0) return;
    
    $admin_email_setting = $options['admin_email_notify'] ?? get_option('admin_email');
    if (empty($admin_email_setting)) return;
    
    $admin_emails = array_filter(array_map('trim', explode(',', $admin_email_setting)), 'is_email');
    if (empty($admin_emails)) return;

    $table_stats = $wpdb->prefix . 'soft_ai_chat_stats';
    $table_logs = $wpdb->prefix . 'soft_ai_chat_logs';
    
    $today = current_time('Y-m-d');
    
    $pending = $wpdb->get_results($wpdb->prepare("SELECT id, user_ip FROM $table_stats WHERE date_day = %s AND transcript_sent = 0", $today));
    
    if (!$pending) return;
    
    $timeout_seconds = $timeout_mins * 60;
    $current_time = current_time('timestamp');
    
    foreach ($pending as $stat) {
        $latest_log = $wpdb->get_row($wpdb->prepare("SELECT time FROM $table_logs WHERE user_ip = %s ORDER BY time DESC LIMIT 1", $stat->user_ip));
        
        if ($latest_log) {
            $last_msg_time = strtotime($latest_log->time);
            if (($current_time - $last_msg_time) >= $timeout_seconds) {
                $logs = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_logs WHERE user_ip = %s AND DATE(time) = %s ORDER BY time ASC", $stat->user_ip, $today));
                
                if ($logs) {
                    $subject = "[Soft AI Chat] Transcript: Khách hàng " . $stat->user_ip;
                    $body = "<h2>Lịch sử trò chuyện (Ngừng tương tác sau {$timeout_mins} phút)</h2>";
                    $body .= "<p><strong>Khách hàng (IP/ID):</strong> " . esc_html($stat->user_ip) . "</p>";
                    $body .= "<p><strong>Nguồn:</strong> " . esc_html($logs[0]->source) . "</p><hr/>";
                    
                    foreach ($logs as $log) {
                        $q = soft_ai_clean_text_for_social($log->question);
                        $a = soft_ai_clean_text_for_social($log->answer);

                        $time_str = date('H:i', strtotime($log->time));
                        if (!empty($log->question) && $log->provider !== 'live_admin') {
                            $body .= "<p><strong>Khách:</strong><br>" . nl2br(esc_html($q)) . "</p>";
                        }
                        if (!empty($log->answer)) {
                            $sender_name = ($log->provider === 'live_admin') ? (!empty($log->model) && $log->model !== 'human' ? esc_html($log->model) : 'Nhân viên') : 'AI Bot';
                            $color = ($log->provider === 'live_admin') ? '#d63638' : '#2271b1';
                            $body .= "<p style='margin-bottom: 15px; background: #f0f0f1; padding: 10px; border-left: 3px solid {$color};'><span style='color: {$color};'><strong>{$sender_name} ({$time_str}):</strong></span><br/>" . nl2br(esc_html($a)) . "</p>";
                        }
                    }
                    
                    $headers = array('Content-Type: text/html; charset=UTF-8');
                    wp_mail($admin_emails, $subject, $body, $headers);
                }
                
                $wpdb->update($table_stats, ['transcript_sent' => 1], ['id' => $stat->id]);
            }
        } else {
            $wpdb->update($table_stats, ['transcript_sent' => 1], ['id' => $stat->id]);
        }
    }
}

// ---------------------------------------------------------
// 4. API CALLER
// ---------------------------------------------------------

function soft_ai_chat_call_api($provider, $model, $sys, $user, $opts) {
    $api_key = $opts[$provider . '_api_key'] ?? '';
    if (!$api_key) return new WP_Error('missing_key', 'Thiếu khóa API (API Key)');

    $url = '';
    $headers = ['Content-Type' => 'application/json'];
    $body = [];

    switch ($provider) {
        case 'groq':
            $url = 'https://api.groq.com/openai/v1/chat/completions';
            $headers['Authorization'] = 'Bearer ' . $api_key;
            $body = [
                'model' => $model,
                'messages' => [['role' => 'system', 'content' => $sys], ['role' => 'user', 'content' => $user]],
                'temperature' => (float)$opts['temperature'],
                'max_tokens' => (int)$opts['max_tokens']
            ];
            break;
        case 'openai':
            $url = 'https://api.openai.com/v1/chat/completions';
            $headers['Authorization'] = 'Bearer ' . $api_key;
            $body = [
                'model' => $model,
                'messages' => [['role' => 'system', 'content' => $sys], ['role' => 'user', 'content' => $user]],
                'temperature' => (float)$opts['temperature'],
                'max_tokens' => (int)$opts['max_tokens']
            ];
            break;
        case 'gemini':
            $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$api_key}";
            $body = [
                'system_instruction' => ['parts' => [['text' => $sys]]],
                'contents' => [['role' => 'user', 'parts' => [['text' => $user]]]],
                'generationConfig' => ['temperature' => (float)$opts['temperature'], 'maxOutputTokens' => (int)$opts['max_tokens']]
            ];
            break;
        case 'claude':
            $url = 'https://api.anthropic.com/v1/messages';
            $headers['x-api-key'] = $api_key;
            $headers['anthropic-version'] = '2023-06-01';
            $body = [
                'model' => $model,
                'max_tokens' => (int)$opts['max_tokens'],
                'temperature' => (float)$opts['temperature'],
                'system' => $sys,
                'messages' => [
                    ['role' => 'user', 'content' => $user]
                ]
            ];
            break;
    }

    $response = wp_remote_post($url, [
        'headers' => $headers, 
        'body' => json_encode($body), 
        'timeout' => 60
    ]);

    if (is_wp_error($response)) return $response;
    $data = json_decode(wp_remote_retrieve_body($response), true);
    
    if (isset($data['choices'][0]['message']['content'])) return $data['choices'][0]['message']['content'];
    if (isset($data['candidates'][0]['content']['parts'][0]['text'])) return $data['candidates'][0]['content']['parts'][0]['text'];
    if (isset($data['content'][0]['text'])) return $data['content'][0]['text'];

    return "Lỗi API: " . wp_remote_retrieve_body($response);
}

// ---------------------------------------------------------
// 5. REST API & WEBHOOKS
// ---------------------------------------------------------

function soft_ai_chat_submit_lead($request) {
    global $wpdb;
    $params = $request->get_json_params();
    $name = sanitize_text_field($params['name'] ?? '');
    $phone = sanitize_text_field($params['phone'] ?? '');
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

    if (!$name || !$phone) {
        return new WP_Error('invalid_data', 'Thiếu tên hoặc số điện thoại', ['status' => 400]);
    }

    $wpdb->insert($wpdb->prefix . 'soft_ai_leads', [
        'name' => $name,
        'phone' => $phone,
        'ip_address' => $ip,
        'created_at' => current_time('mysql')
    ]);

    return rest_ensure_response(['success' => true]);
}

function soft_ai_get_facebook_user_profile($psid, $token) {
    if (!$token) return 'Khách Facebook ẩn danh';
    $url = "https://graph.facebook.com/v19.0/{$psid}?fields=first_name,last_name,profile_pic&access_token={$token}";
    $response = wp_remote_get($url, ['timeout' => 5]);
    if (is_wp_error($response)) return 'Khách Facebook ẩn danh';
    
    $body = json_decode(wp_remote_retrieve_body($response), true);
    if (isset($body['first_name'])) {
        return trim($body['first_name'] . ' ' . ($body['last_name'] ?? ''));
    }
    return 'Khách Facebook ẩn danh';
}

function soft_ai_chat_handle_widget_request($request) {
    if (function_exists('WC') && !WC()->session) {
        $session_class = apply_filters('woocommerce_session_handler', 'WC_Session_Handler');
        WC()->session = new $session_class();
        WC()->session->init();
        if (!WC()->cart) { WC()->cart = new WC_Cart(); WC()->cart->get_cart(); }
        if (!WC()->customer) { WC()->customer = new WC_Customer(get_current_user_id()); }
    }

    $params = $request->get_json_params();
    $question = sanitize_text_field($params['question'] ?? '');
    $current_url = esc_url_raw($params['current_url'] ?? '');
    $referrer_url = esc_url_raw($params['referrer_url'] ?? '');
    
    if (!$question) return new WP_Error('no_input', 'Câu hỏi trống', ['status' => 400]);

    $answer = soft_ai_generate_answer($question, 'widget', '', $current_url, $referrer_url);
    
    if ($answer === '[WAIT_FOR_HUMAN]' || $answer === '[PAUSED_BY_ADMIN]') {
        return rest_ensure_response(['answer' => '', 'live_mode' => true]);
    }

    soft_ai_log_chat($question, $answer, 'widget', '', '', $current_url, $referrer_url);
    return rest_ensure_response(['answer' => $answer]);
}

function soft_ai_chat_poll_messages($request) {
    global $wpdb;
    $ip = $_SERVER['REMOTE_ADDR'];
    $table = $wpdb->prefix . 'soft_ai_chat_logs';
    $last_id = (int) ($request->get_json_params()['last_id'] ?? 0);
    
    $new_msgs = $wpdb->get_results($wpdb->prepare("SELECT id, answer, time, model FROM $table WHERE user_ip = %s AND provider = 'live_admin' AND id > %d ORDER BY time ASC", $ip, $last_id));

    $data = [];
    foreach($new_msgs as $m) {
        $admin_name = (!empty($m->model) && $m->model !== 'human') ? $m->model : 'Nhân viên';
        $data[] = ['id' => $m->id, 'text' => $m->answer, 'admin_name' => $admin_name];
    }

    return rest_ensure_response(['messages' => $data]);
}

function soft_ai_chat_webhook_facebook($request) {
    global $wpdb;
    $table = $wpdb->prefix . 'soft_ai_social_channels';
    $channel_id = intval($request->get_param('channel_id'));

    if ($request->get_method() === 'GET') {
        $verify_token = $request->get_param('hub_verify_token') ?: $request->get_param('hub.verify_token');
        $challenge = $request->get_param('hub_challenge') ?: $request->get_param('hub.challenge');

        if ($verify_token) {
            $verify_token = sanitize_text_field($verify_token);
            $channel = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d AND platform = 'facebook' AND verify_token = %s AND is_active = 1", $channel_id, $verify_token));
            
            if ($channel) {
                echo sanitize_text_field($challenge); 
                exit;
            }
        }
        return new WP_Error('forbidden', 'Mã xác thực không hợp lệ', ['status' => 403]);
    }

    $body = $request->get_json_params();
    if (isset($body['object']) && $body['object'] === 'page') {
        
        $channel = $wpdb->get_row($wpdb->prepare("SELECT access_token FROM $table WHERE id = %d AND platform = 'facebook' AND is_active = 1", $channel_id));
        if (!$channel) return new WP_Error('not_found', 'Kênh chưa kích hoạt hoặc không tồn tại', ['status' => 404]);
        
        $token = $channel->access_token;

        foreach ($body['entry'] as $entry) {
            foreach ($entry['messaging'] as $event) {
                if (isset($event['message']['text']) && !isset($event['message']['is_echo'])) {
                    $sender = $event['sender']['id'];
                    $user_msg = $event['message']['text'];

                    $fb_name = get_transient('soft_ai_fb_name_' . $sender);
                    if ($fb_name === false) {
                        $fb_name = soft_ai_get_facebook_user_profile($sender, $token);
                        set_transient('soft_ai_fb_name_' . $sender, $fb_name, 30 * DAY_IN_SECONDS);
                    }

                    $email_sender_id = ($fb_name && $fb_name !== 'Khách Facebook ẩn danh') ? "$fb_name (ID: $sender)" : $sender;
                    
                    $reply = soft_ai_generate_answer($user_msg, 'facebook', $sender);
                    
                    if ($reply !== '[WAIT_FOR_HUMAN]' && $reply !== '[PAUSED_BY_ADMIN]') {
                        soft_ai_send_fb_message($sender, $reply, $token);
                        soft_ai_log_chat($event['message']['text'], $reply, 'facebook', '', '', '', '', $sender);
                    }
                }
            }
        }
        return rest_ensure_response(['status' => 'EVENT_RECEIVED']);
    }
    return new WP_Error('bad_req', 'Dữ liệu Facebook không hợp lệ', ['status' => 404]);
}

function soft_ai_send_fb_message($recipient, $text, $token) {
    if (!$token) return;
    $chunks = function_exists('mb_str_split') ? mb_str_split($text, 1900) : str_split($text, 1900);
    foreach ($chunks as $chunk) {
        wp_remote_post("https://graph.facebook.com/v21.0/me/messages?access_token=$token", [
            'headers' => ['Content-Type' => 'application/json'],
            'body' => wp_json_encode([
                'messaging_type' => 'RESPONSE',
                'recipient' => ['id' => (string)$recipient], 
                'message' => ['text' => $chunk]
            ])
        ]);
    }
}

function soft_ai_chat_webhook_zalo($request) {
    global $wpdb;
    $table = $wpdb->prefix . 'soft_ai_social_channels';
    $channel_id = intval($request->get_param('channel_id'));

    $body = $request->get_json_params();
    if (isset($body['event_name']) && $body['event_name'] === 'user_send_text') {
        $sender = $body['sender']['id'];
        $user_msg = $body['message']['text'];

        $channel = $wpdb->get_row($wpdb->prepare("SELECT access_token FROM $table WHERE id = %d AND platform = 'zalo' AND is_active = 1", $channel_id));
        if (!$channel) return rest_ensure_response(['status' => 'ignored']);
        
        $token = $channel->access_token;

        $reply = soft_ai_generate_answer($user_msg, 'zalo', $sender);
        
        if ($reply !== '[WAIT_FOR_HUMAN]' && $reply !== '[PAUSED_BY_ADMIN]') {
            if ($token) {
                wp_remote_post("https://openapi.zalo.me/v3.0/oa/message/cs", [
                    'headers' => ['access_token' => $token, 'Content-Type' => 'application/json'],
                    'body' => wp_json_encode(['recipient' => ['user_id' => (string)$sender], 'message' => ['text' => $reply]])
                ]);
            }
            soft_ai_log_chat($body['message']['text'], $reply, 'zalo', '', '', '', '', $sender);
        }
        return rest_ensure_response(['status' => 'success']);
    }
    return rest_ensure_response(['status' => 'ignored']);
}

// ---------------------------------------------------------
// 6. FRONTEND WIDGETS 
// ---------------------------------------------------------

function soft_ai_social_widgets_render() {
    global $wpdb;
    $table = $wpdb->prefix . 'soft_ai_social_channels';
    $channels = $wpdb->get_results("SELECT * FROM $table WHERE is_active = 1");
    $options = get_option('soft_ai_chat_settings');

    foreach ($channels as $ch) {
        if ($ch->platform === 'zalo' && !empty($ch->page_id)) {
            $zalo_id = esc_attr($ch->page_id);
            $welcome = esc_attr($options['welcome_msg'] ?? 'Xin chào!');
            echo <<<HTML
            <div class="zalo-chat-widget" data-oaid="{$zalo_id}" data-welcome-message="{$welcome}" data-autopopup="0" data-width="350" data-height="420"></div>
            <script src="https://sp.zalo.me/plugins/sdk.js"></script>
HTML;
        }
        
        if ($ch->platform === 'facebook' && !empty($ch->page_id)) {
            $fb_id = esc_attr($ch->page_id);
            echo <<<HTML
            <div id="fb-root"></div>
            <div id="fb-customer-chat" class="fb-customerchat"></div>
            <script>
            var chatbox = document.getElementById('fb-customer-chat');
            chatbox.setAttribute("page_id", "{$fb_id}");
            chatbox.setAttribute("attribution", "biz_inbox");
            window.fbAsyncInit = function() { FB.init({ xfbml : true, version : 'v18.0' }); };
            (function(d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id)) return;
                js = d.createElement(s); js.id = id;
                js.src = 'https://connect.facebook.net/vi_VN/sdk/xfbml.customerchat.js';
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
            </script>
HTML;
        }
    }
}

function soft_ai_chat_inject_widget() {
    global $wpdb;
    $options = get_option('soft_ai_chat_settings');
    if (is_admin() || empty($options['provider'])) return;

    $color = $options['theme_color'] ?? '#027DDD';
    $bg_color = $options['bg_color'] ?? '#ffffff';
    $text_color = $options['text_color'] ?? '#333333';
    
    $welcome = $options['welcome_msg'] ?? 'Xin chào! Bạn cần tìm gì ạ?';
    $chat_title = $options['chat_title'] ?? 'Trợ lý AI';
    $input_placeholder = $options['input_placeholder'] ?? 'Hỏi gì đó...';
    $button_text = $options['button_text'] ?? '➤';
    
    $trigger_image = $options['trigger_image'] ?? '';
    $trigger_icon = $options['trigger_icon'] ?? '💬';
    
    $pos_bottom = $options['pos_bottom'] ?? '20px';
    $pos_right = $options['pos_right'] ?? '20px';
    $pos_left = $options['pos_left'] ?? 'auto';
    $clear_on_close = !empty($options['clear_on_close']) ? 'true' : 'false';
    $trigger_border_radius = $options['trigger_border_radius'] ?? '50%';
    $trigger_bg_transparent = !empty($options['trigger_bg_transparent']);
    $trigger_bg_css = $trigger_bg_transparent ? 'background: transparent; box-shadow: none;' : "background: {$color}; box-shadow: 0 4px 15px rgba(0,0,0,0.2);";
    
    $shop_name = get_bloginfo('name');
    
    $enable_pre_chat = !empty($options['enable_pre_chat']) ? 'true' : 'false';
    $pre_chat_msg = $options['pre_chat_msg'] ?? 'Vui lòng điền thông tin để bắt đầu chat';

    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $table = $wpdb->prefix . 'soft_ai_chat_logs';
    $max_id = (int) $wpdb->get_var("SELECT MAX(id) FROM $table"); 

    if (!empty($trigger_image)) {
        $trigger_html = "<img src='" . esc_url($trigger_image) . "' style='width:100%; height:100%; border-radius:{$trigger_border_radius}; object-fit:cover; pointer-events:none;' alt='Trò chuyện' />";
    } elseif (filter_var($trigger_icon, FILTER_VALIDATE_URL)) {
        $trigger_html = "<img src='" . esc_url($trigger_icon) . "' style='width:100%; height:100%; border-radius:{$trigger_border_radius}; object-fit:cover; pointer-events:none;' alt='Trò chuyện' />";
    } else {
        $trigger_html = wp_kses_post($trigger_icon);
    }

    ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/marked/11.1.1/marked.min.js"></script>
    <style>
        .sac-msg.bot table { border-collapse: collapse; width: 100%; margin: 10px 0; font-size: 13px; }
        .sac-msg.bot th, .sac-msg.bot td { border: 1px solid #ddd !important; padding: 8px; text-align: left; }
        .sac-msg.bot th { background-color: #f2f2f2; font-weight: bold; }
        .sac-msg.bot pre { background: #1e293b; color: #f8fafc; padding: 10px; border-radius: 8px; overflow-x: auto; font-size: 13px; margin: 8px 0; }
        .sac-msg.bot code { background: rgba(0,0,0,0.05); padding: 2px 4px; border-radius: 4px; font-family: 'JetBrains Mono', monospace; font-size: 13px; color: #db2777; }
        .sac-msg.bot pre code { background: transparent; padding: 0; color: inherit; }
        
        #sac-trigger { 
            position: fixed; 
            bottom: <?php echo esc_attr($pos_bottom); ?>; 
            <?php if ($pos_left !== 'auto' && $pos_left !== '') { ?>
                left: <?php echo esc_attr($pos_left); ?>;
                right: auto;
            <?php } else { ?>
                right: <?php echo esc_attr($pos_right); ?>; 
                left: auto;
            <?php } ?>
            width: 60px; height: 60px; <?php echo $trigger_bg_css; ?> color: white; border-radius: <?php echo esc_attr($trigger_border_radius); ?>; display: flex; align-items: center; justify-content: center; cursor: pointer; z-index: 999999; transition: all 0.3s; font-size: 28px; 
        }
        .zalo-chat-widget + #sac-trigger { bottom: calc(<?php echo esc_attr($pos_bottom); ?> + 70px); }
        #sac-trigger:hover { transform: scale(1.05); <?php if(!$trigger_bg_transparent) echo 'box-shadow: 0 6px 20px rgba(0,0,0,0.3);'; ?> }
        
        #sac-window { 
            position: fixed; 
            bottom: calc(<?php echo esc_attr($pos_bottom); ?> + 70px); 
            <?php if ($pos_left !== 'auto' && $pos_left !== '') { ?>
                left: <?php echo esc_attr($pos_left); ?>;
                right: auto;
            <?php } else { ?>
                right: <?php echo esc_attr($pos_right); ?>; 
                left: auto;
            <?php } ?>
            width: 360px; height: 500px; max-height: calc(100vh - 120px); background: <?php echo esc_attr($bg_color); ?>; border-radius: 15px; box-shadow: 0 10px 40px rgba(0,0,0,0.2); display: none; flex-direction: column; z-index: 999999; overflow: hidden; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; border: 1px solid #f0f0f0; 
        }
        .sac-header { background: <?php echo esc_attr($color); ?>; color: white; padding: 15px; font-weight: 600; display: flex; justify-content: space-between; align-items: center; }
        .sac-close { cursor: pointer; font-size: 18px; opacity: 0.8; }
        .sac-close:hover { opacity: 1; }
        
        #sac-messages { flex: 1; padding: 15px; overflow-y: auto; background: <?php echo esc_attr($bg_color); ?>; display: flex; flex-direction: column; gap: 12px; font-size: 14px; color: <?php echo esc_attr($text_color); ?>; }
        .sac-msg { padding: 10px 14px; border-radius: 12px; line-height: 1.5; max-width: 85%; word-wrap: break-word; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }
        .sac-msg.user { align-self: flex-end; background: <?php echo esc_attr($color); ?>; color: white; border-bottom-right-radius: 2px; }
        .sac-msg.bot { align-self: flex-start; background: #fff; border: 1px solid #e5e5e5; color: <?php echo esc_attr($text_color); ?>; border-bottom-left-radius: 2px; }
        .sac-msg.bot p { margin: 0 0 8px 0; } .sac-msg.bot p:last-child { margin: 0; }
        .sac-msg.bot img { max-width: 100%; border-radius: 8px; margin-top: 5px; }
        .sac-msg.bot strong { color: <?php echo esc_attr($color); ?>; }
        .sac-msg.admin { align-self: flex-start; background: #e6f7ff; border: 1px solid #91d5ff; color: #0050b3; border-bottom-left-radius: 2px; position: relative; }
        
        .sac-input-area { padding: 12px !important; border-top: 1px solid #eee; background: white; display: flex; gap: 8px; align-items: center; }
        #sac-input { flex: 1; padding: 10px 14px; border: 1px solid #cbd5e1; border-radius: 20px; outline: none; transition: border 0.2s; color: #333; font-size: 14px; }
        #sac-input:focus { border-color: <?php echo esc_attr($color); ?>; }
        
        #sac-mic-btn { background: transparent; color: <?php echo esc_attr($text_color); ?>; border: none; font-size: 18px; cursor: pointer; padding: 0 8px; transition: 0.2s; opacity: 0.7; display: flex; align-items: center; justify-content: center; }
        #sac-mic-btn:hover { opacity: 1; transform: scale(1.1); }
        #sac-mic-btn.recording { color: #ef4444; animation: sacPulse 1s infinite; opacity: 1; }
        @keyframes sacPulse { 0% { transform: scale(1); } 50% { transform: scale(1.2); } 100% { transform: scale(1); } }
        
        #sac-send { width: auto; min-width: 40px; height: 40px; background: <?php echo esc_attr($color); ?>; color: white; border: none; border-radius: 20px; cursor: pointer; display: flex; align-items: center; justify-content: center; padding: 0 16px !important; transition: 0.2s; font-family: inherit;}
        #sac-send:hover { filter: brightness(1.1); }
        #sac-send:disabled { background: #ccc; cursor: not-allowed; }
        
        .typing-dot { display: inline-block; width: 6px; height: 6px; border-radius: 50%; background: #888; margin-right: 3px; animation: typing 1.4s infinite ease-in-out both; }
        .typing-dot:nth-child(1) { animation-delay: -0.32s; } .typing-dot:nth-child(2) { animation-delay: -0.16s; }
        @keyframes typing { 0%, 80%, 100% { transform: scale(0); } 40% { transform: scale(1); } }

        #sac-pre-chat { padding: 30px 20px; display: flex; flex-direction: column; gap: 15px; flex: 1; background: #fff; overflow-y: auto; }
        .sac-pre-input { padding: 12px !important; border: 1px solid #ddd !important; border-radius: 8px; width: 100%; box-sizing: border-box; font-size: 14px; outline: none; transition: border 0.2s; }
        .sac-pre-input:focus { border-color: <?php echo esc_attr($color); ?>; }
        #sac-pre-submit { background: <?php echo esc_attr($color); ?>; color: #fff; border: none; padding: 12px !important; border-radius: 8px; cursor: pointer; font-weight: bold; font-size: 15px; transition: 0.2s; }
        #sac-pre-submit:hover { filter: brightness(1.1); }
        #sac-pre-submit:disabled { background: #ccc; cursor: not-allowed; }
    </style>

    <div id="sac-trigger" onclick="toggleSac()"><?php echo $trigger_html; ?></div>
    <div id="sac-window">
        <div class="sac-header">
            <span><?php echo esc_html($chat_title); ?></span>
            <span class="sac-close" onclick="toggleSac()">✕</span>
        </div>
        
        <div id="sac-pre-chat" style="display:none;">
            <div style="text-align: center; margin-bottom: 10px;">
                <div style="font-size: 40px; margin-bottom: 10px;">👋</div>
                <p style="margin:0; font-weight:600; color:#333; font-size: 15px; line-height: 1.4;"><?php echo esc_html($pre_chat_msg); ?></p>
            </div>
            <input type="text" id="sac-pre-name" class="sac-pre-input" placeholder="Họ và tên của bạn *" required>
            <input type="tel" id="sac-pre-phone" class="sac-pre-input" placeholder="Số điện thoại liên hệ *" required>
            <button id="sac-pre-submit" onclick="submitSacLead()">Bắt đầu Chat</button>
            <p style="text-align:center; font-size: 11px; color: #999; margin-top: 10px;">Thông tin của bạn sẽ được bảo mật và chỉ dùng để hỗ trợ.</p>
        </div>

        <div id="sac-messages">
        </div>
        <div class="sac-input-area">
            <input type="text" id="sac-input" placeholder="<?php echo esc_attr($input_placeholder); ?>" onkeypress="handleEnter(event)">
            <button id="sac-mic-btn" title="Nhập bằng giọng nói">🎤</button>
            <button id="sac-send" onclick="sendSac()"><span style="font-size:15px; font-weight:600;"><?php echo esc_html($button_text); ?></span></button>
        </div>
    </div>

    <script>
        const apiUrl = '<?php echo esc_url(rest_url('soft-ai-chat/v1/ask')); ?>';
        const pollUrl = '<?php echo esc_url(rest_url('soft-ai-chat/v1/poll')); ?>';
        const submitLeadUrl = '<?php echo esc_url(rest_url('soft-ai-chat/v1/submit-lead')); ?>';
        
        let lastMsgId = <?php echo $max_id; ?>; 
        let pollInterval = null;
        const shopName = '<?php echo esc_js($shop_name); ?>'; 
        const clearOnClose = <?php echo $clear_on_close; ?>;
        const enablePreChat = <?php echo $enable_pre_chat; ?>;
        let isFirstOpen = true;

        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        const micBtn = document.getElementById('sac-mic-btn');
        const inputField = document.getElementById('sac-input');

        if (SpeechRecognition && micBtn) {
            const recognition = new SpeechRecognition();
            recognition.continuous = false;
            recognition.interimResults = false;
            recognition.lang = 'vi-VN';
            let isRecording = false;

            micBtn.onclick = () => {
                if (isRecording) { recognition.stop(); return; }
                try { recognition.start(); } catch(e) { console.error(e); }
            };
            recognition.onstart = () => { isRecording = true; micBtn.classList.add('recording'); micBtn.innerHTML = '🛑'; };
            recognition.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                inputField.value += (inputField.value ? ' ' : '') + transcript;
                inputField.focus();
            };
            recognition.onerror = (e) => { console.error(e); isRecording = false; micBtn.classList.remove('recording'); micBtn.innerHTML = '🎤'; };
            recognition.onend = () => { isRecording = false; micBtn.classList.remove('recording'); micBtn.innerHTML = '🎤'; };
        } else if (micBtn) {
            micBtn.style.display = 'none';
        }

        function toggleSac() {
            const win = document.getElementById('sac-window');
            const isHidden = win.style.display === '' || win.style.display === 'none';
            win.style.display = isHidden ? 'flex' : 'none';
            
            if (isHidden) {
                const leadSubmitted = sessionStorage.getItem('sac_lead_submitted') === 'true';
                
                if (enablePreChat && !leadSubmitted) {
                    document.getElementById('sac-messages').style.display = 'none';
                    document.querySelector('.sac-input-area').style.display = 'none';
                    document.getElementById('sac-pre-chat').style.display = 'flex';
                } else {
                    document.getElementById('sac-messages').style.display = 'flex';
                    document.querySelector('.sac-input-area').style.display = 'flex';
                    document.getElementById('sac-pre-chat').style.display = 'none';
                    
                    const msgs = document.getElementById('sac-messages');
                    if (clearOnClose || isFirstOpen) {
                        msgs.innerHTML = `<div class="sac-msg bot"><?php echo esc_js($welcome); ?></div>`; 
                        isFirstOpen = false;
                    }
                    lastMsgId = <?php echo (int) $wpdb->get_var("SELECT MAX(id) FROM {$wpdb->prefix}soft_ai_chat_logs") ?: 0; ?>; 

                    setTimeout(() => document.getElementById('sac-input').focus(), 100);
                    startPolling();
                }
            } else {
                stopPolling();
                if (clearOnClose) {
                    const msgs = document.getElementById('sac-messages');
                    msgs.innerHTML = '';
                }
            }
        }

        async function submitSacLead() {
            const name = document.getElementById('sac-pre-name').value.trim();
            const phone = document.getElementById('sac-pre-phone').value.trim();
            const btn = document.getElementById('sac-pre-submit');
            
            if (!name || !phone) {
                alert('Vui lòng nhập đầy đủ Họ tên và Số điện thoại');
                return;
            }

            btn.disabled = true;
            btn.innerText = 'Đang kết nối...';

            try {
                const res = await fetch(submitLeadUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name: name, phone: phone })
                });
                const data = await res.json();
                
                if (data.success) {
                    sessionStorage.setItem('sac_lead_submitted', 'true');
                    
                    document.getElementById('sac-pre-chat').style.display = 'none';
                    document.getElementById('sac-messages').style.display = 'flex';
                    document.querySelector('.sac-input-area').style.display = 'flex';
                    
                    const msgs = document.getElementById('sac-messages');
                    msgs.innerHTML = `<div class="sac-msg bot"><?php echo esc_js($welcome); ?></div>`;
                    isFirstOpen = false;
                    
                    setTimeout(() => document.getElementById('sac-input').focus(), 100);
                    startPolling();
                } else {
                    alert('Có lỗi xảy ra, vui lòng thử lại.');
                    btn.disabled = false;
                    btn.innerText = 'Bắt đầu Chat';
                }
            } catch (err) {
                alert('Không thể kết nối đến máy chủ.');
                btn.disabled = false;
                btn.innerText = 'Bắt đầu Chat';
            }
        }
        
        function handleEnter(e) { if (e.key === 'Enter') sendSac(); }

        function startPolling() {
            if(pollInterval) clearInterval(pollInterval);
            pollInterval = setInterval(async () => {
                try {
                    const res = await fetch(pollUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ last_id: lastMsgId }) 
                    });
                    const data = await res.json();
                    if(data.messages && data.messages.length > 0) {
                        const msgs = document.getElementById('sac-messages');
                        data.messages.forEach(m => {
                            lastMsgId = Math.max(lastMsgId, parseInt(m.id)); 
                            msgs.innerHTML += `<div class="sac-msg admin"><div style="font-size:12px; font-weight:bold; margin-bottom:4px; color:#0050b3;">🧑‍💻 ${shopName}</div>${marked.parse(m.text)}</div>`;
                        });
                        msgs.scrollTop = msgs.scrollHeight;
                    }
                } catch(e) {}
            }, 5000); 
        }

        function stopPolling() {
            if(pollInterval) clearInterval(pollInterval);
        }

        async function sendSac() {
            const input = document.getElementById('sac-input');
            const msgs = document.getElementById('sac-messages');
            const btn = document.getElementById('sac-send');
            const txt = input.value.trim();
            if (!txt) return;

            msgs.innerHTML += `<div class="sac-msg user">${txt.replace(/</g, "&lt;")}</div>`;
            const loadingId = 'sac-load-' + Date.now();
            msgs.innerHTML += `<div class="sac-msg bot" id="${loadingId}"><span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span></div>`;
            msgs.scrollTop = msgs.scrollHeight;
            input.value = ''; input.disabled = true; btn.disabled = true;

            try {
                const res = await fetch(apiUrl, {
                    method: 'POST', 
                    headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
                    body: JSON.stringify({ 
                        question: txt,
                        current_url: window.location.href,
                        referrer_url: document.referrer
                    })
                });
                const data = await res.json();
                document.getElementById(loadingId)?.remove();
                
                if (data.answer) {
                    msgs.innerHTML += `<div class="sac-msg bot">${marked.parse(data.answer)}</div>`;
                } else if(data.live_mode) {
                    
                } else {
                    msgs.innerHTML += `<div class="sac-msg bot" style="color:red">Lỗi: ${data.message || 'Unknown'}</div>`;
                }
            } catch (err) {
                document.getElementById(loadingId)?.remove();
                msgs.innerHTML += `<div class="sac-msg bot" style="color:red">Mất kết nối server.</div>`;
            }
            
            input.disabled = false; btn.disabled = false; input.focus();
            msgs.scrollTop = msgs.scrollHeight;
        }
    </script>
    <?php
}