<?php
/**
 * Plugin Name:       SOFTY Custom Layouts for TinyMCE
 * Plugin URI:        https://sales.soft.io.vn
 * Description:       Thêm một menu thả xuống tùy chỉnh vào Trình soạn thảo cổ điển (TinyMCE) để chèn các khối bố cục được thiết kế sẵn (CTA, Mục lục, Sản phẩm, v.v.).
 * Version:           1.0.2
 * Requires at least: 5.0
 * Requires PHP:      7.2
 * Author:            Tung Pham
 * Author URI:        https://soft.io.vn/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       softy-layouts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Thoát nếu truy cập trực tiếp
}

// ==============================================================================
// 1. API XÁC THỰC GIẤY PHÉP
// ==============================================================================

/**
 * Xác thực khóa bản quyền với endpoint Netlify.
 */
function softy_layouts_verify_license( $license_key, $force_check = false ) {
    $transient_key = 'softy_layouts_license_' . md5( $license_key );
    
    // Kiểm tra cache trước để tránh gửi quá nhiều yêu cầu đến API Netlify
    if ( ! $force_check ) {
        $cached_status = get_transient( $transient_key );
        if ( false !== $cached_status ) {
            return $cached_status;
        }
    }

    // Trích xuất tên miền sạch
    $site_url = home_url();
    $parsed_url = wp_parse_url( $site_url );
    $domain = isset( $parsed_url['host'] ) ? $parsed_url['host'] : '';
    $domain = preg_replace( '/^www\./', '', $domain );

    // URL API Netlify dựa trên các chuyển hướng trong netlify.toml của bạn
    $api_url = 'https://license.soft.io.vn/api/verify-license';

    // Gửi yêu cầu POST, mong đợi phản hồi JSON gồm valid/message
    $response = wp_remote_post( $api_url, array(
        'timeout'     => 15,
        'headers'     => array(
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json'
        ),
        'body'        => wp_json_encode( array(
            'licenseKey' => sanitize_text_field( $license_key ),
            'domain'     => $domain,
        ) ),
    ) );

    if ( is_wp_error( $response ) ) {
        return array( 'valid' => false, 'message' => 'Lỗi kết nối: ' . $response->get_error_message() );
    }

    $response_code = wp_remote_retrieve_response_code( $response );
    $body          = wp_remote_retrieve_body( $response );
    $data          = json_decode( $body, true );

    $result = array(
        'valid'   => false,
        'message' => isset( $data['message'] ) ? $data['message'] : 'Lỗi không xác định.',
    );

    // Kiểm tra nếu API trả về statusCode 200 và valid = true
    if ( $response_code === 200 && ! empty( $data['valid'] ) ) {
        $result['valid'] = true;
    }

    // Lưu cache kết quả trong 12 giờ
    set_transient( $transient_key, $result, 12 * HOUR_IN_SECONDS );
    return $result;
}

// ==============================================================================
// 2. TRANG CÀI ĐẶT QUẢN TRỊ
// ==============================================================================

add_action( 'admin_menu', 'softy_layouts_add_admin_menu' );
function softy_layouts_add_admin_menu() {
    add_options_page(
        'Bản quyền Softy Layouts',
        'Softy Layouts',
        'manage_options',
        'softy-layouts-license',
        'softy_layouts_options_page'
    );
}

function softy_layouts_options_page() {
    // Xử lý lưu form
    if ( isset( $_POST['softy_layouts_save_license'] ) && check_admin_referer( 'softy_layouts_save_nonce' ) ) {
        $license_key = sanitize_text_field( $_POST['softy_layouts_license_key'] );
        update_option( 'softy_layouts_license_key', $license_key );
        
        // Buộc kiểm tra API ngay khi lưu
        $verification = softy_layouts_verify_license( $license_key, true );
        
        if ( $verification['valid'] ) {
            echo '<div class="notice notice-success is-dismissible"><p>Kích hoạt bản quyền thành công!</p></div>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>Lỗi: ' . esc_html( $verification['message'] ) . '</p></div>';
        }
    }

    $current_key = get_option( 'softy_layouts_license_key', '' );
    ?>
    <div class="wrap">
        <h1>Cấu hình Softy Layouts</h1>
        <form method="post" action="">
            <?php wp_nonce_field( 'softy_layouts_save_nonce' ); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Khóa bản quyền</th>
                    <td>
                        <input type="text" name="softy_layouts_license_key" value="<?php echo esc_attr( $current_key ); ?>" class="regular-text" autocomplete="off" />
                        <p class="description">Điền key bản quyền được cung cấp cho miền này để mở khóa các tính năng của plugin.</p>
                        <p class="description">Để tạo bài viết hoặc trang mới và sử dụng Softy Layouts, hãy truy cập <a href="<?php echo esc_url( admin_url( 'post-new.php' ) ); ?>">Thêm bài viết / trang mới</a>.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button( 'Lưu bản quyền', 'primary', 'softy_layouts_save_license' ); ?>
        </form>
    </div>
    <?php
}

// ==============================================================================
// 3. KHỞI TẠO & THỰC THI PLUGIN
// ==============================================================================

add_action( 'plugins_loaded', 'softy_layouts_init' );
function softy_layouts_init() {
    $license_key = get_option( 'softy_layouts_license_key' );
    
    // Nếu chưa lưu khóa, hiển thị cảnh báo và không tải các tính năng cốt lõi
    if ( ! $license_key ) {
        add_action( 'admin_notices', 'softy_layouts_no_key_notice' );
        return;
    }

    // Xác thực khóa
    $status = softy_layouts_verify_license( $license_key );

    // Nếu hợp lệ, tải các chức năng cốt lõi của plugin
    if ( $status['valid'] ) {
        // Vô hiệu hóa Gutenberg cho bài viết, trang và các loại bài viết tùy chỉnh
        add_filter( 'use_block_editor_for_post', '__return_false', 10 );
        // Vô hiệu hóa trình soạn thảo khối Gutenberg cho Widget
        add_filter( 'use_widgets_block_editor', '__return_false' );

        // Nạp CSS và scripts
        add_action( 'wp_enqueue_scripts', 'softy_layouts_enqueue_frontend_styles' );
        add_filter( 'mce_css', 'softy_layouts_add_editor_styles' );
        add_action( 'admin_head', 'softy_layouts_add_tinymce_plugin' );
    } else {
        // Nếu không hợp lệ hoặc đã hết hạn, hiển thị lỗi và không tải các tính năng cốt lõi
        add_action( 'admin_notices', function() use ( $status ) {
            echo '<div class="notice notice-error"><p><strong>Xác thực Softy Layouts thất bại:</strong> ' . esc_html( $status['message'] ) . '</p></div>';
        });
    }
}

function softy_layouts_no_key_notice() {
    echo '<div class="notice notice-warning"><p><strong>Softy Layouts</strong> yêu cầu khóa bản quyền hợp lệ để hoạt động. Vui lòng <a href="' . esc_url( admin_url( 'options-general.php?page=softy-layouts-license' ) ) . '">nhập tại đây</a>.</p></div>';
}

// ==============================================================================
// 4. TÍNH NĂNG CỐT LÕI CỦA PLUGIN (Chỉ thực thi khi đã xác thực)
// ==============================================================================

// 1. Nạp CSS ở frontend để các layout hiển thị giống hệt trong trình soạn thảo
function softy_layouts_enqueue_frontend_styles() {
    wp_enqueue_style( 'softy-layouts-css', plugins_url( 'css/softy-style.css', __FILE__ ), array(), '1.0' );
}

// 2. Nạp cùng file CSS bên trong trình soạn thảo TinyMCE để đạt WYSIWYG thực sự
function softy_layouts_add_editor_styles( $mce_css ) {
    $css_url = plugins_url( 'css/softy-style.css', __FILE__ );
    
    if ( ! empty( $mce_css ) ) {
        $mce_css .= ',';
    }
    $mce_css .= $css_url;
    
    return $mce_css;
}

// 3. Gắn hook vào TinyMCE để thêm plugin và nút tùy chỉnh của chúng ta
function softy_layouts_add_tinymce_plugin() {
    global $typenow;
    
    // Chỉ tải trên màn hình chỉnh sửa bài viết và trang
    if ( ! in_array( $typenow, array( 'post', 'page', 'product' ) ) ) {
        return;
    }
    
    // Kiểm tra xem người dùng có bật chế độ soạn thảo rich text hay không
    if ( get_user_option( 'rich_editing' ) == 'true' ) {
        add_filter( 'mce_external_plugins', 'softy_layouts_add_tinymce_js' );
        add_filter( 'mce_buttons', 'softy_layouts_register_tinymce_button' );
    }
}

// 4. Đăng ký nút trên thanh công cụ chính
function softy_layouts_register_tinymce_button( $buttons ) {
    array_push( $buttons, 'softy_elements_button' );
    return $buttons;
}

// 5. Trỏ đến file JavaScript xử lý dropdown TinyMCE
function softy_layouts_add_tinymce_js( $plugin_array ) {
    $plugin_array['softy_elements'] = plugins_url( 'js/softy-tinymce.js', __FILE__ );
    return $plugin_array;
}