<?php
/**
 * Plugin Name:       SOFTY Custom Layouts for TinyMCE
 * Plugin URI:        https://sales.soft.io.vn
 * Description:       Adds a custom dropdown to the Classic Editor (TinyMCE) to insert pre-styled layout blocks (CTAs, TOC, Products, etc.).
 * Version:           1.0.2
 * Requires at least: 5.0
 * Requires PHP:      7.2
 * Author:            Tung Pham
 * Author URI:        https://soft.io.vn/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       softy-layouts
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// ==============================================================================
// 1. LICENSE VERIFICATION API
// ==============================================================================

/**
 * Verifies the license key against the Netlify endpoint.
 */
function softy_layouts_verify_license( $license_key, $force_check = false ) {
    $transient_key = 'softy_layouts_license_' . md5( $license_key );
    
    // Check cache first to avoid spamming the Netlify API
    if ( ! $force_check ) {
        $cached_status = get_transient( $transient_key );
        if ( false !== $cached_status ) {
            return $cached_status;
        }
    }

    // Extract the clean domain name
    $site_url = home_url();
    $parsed_url = wp_parse_url( $site_url );
    $domain = isset( $parsed_url['host'] ) ? $parsed_url['host'] : '';
    $domain = preg_replace( '/^www\./', '', $domain );

    // Netlify API URL based on your netlify.toml redirects
    $api_url = 'https://license.soft.io.vn/api/verify-license';

    // Send POST request expecting a valid/message JSON response
    $response = wp_remote_post( $api_url, array(
        'timeout'     => 15,
        'headers'     => array(
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json'
        ),
        'body'        => wp_json_encode( array(
            'licenseKey' => sanitize_text_field( $license_key ),
            'domain'     => $domain,
        ) ),
    ) );

    if ( is_wp_error( $response ) ) {
        return array( 'valid' => false, 'message' => 'Connection error: ' . $response->get_error_message() );
    }

    $response_code = wp_remote_retrieve_response_code( $response );
    $body          = wp_remote_retrieve_body( $response );
    $data          = json_decode( $body, true );

    $result = array(
        'valid'   => false,
        'message' => isset( $data['message'] ) ? $data['message'] : 'Unknown error.',
    );

    // Check if the API returns statusCode 200 and valid = true
    if ( $response_code === 200 && ! empty( $data['valid'] ) ) {
        $result['valid'] = true;
    }

    // Cache the result for 12 hours
    set_transient( $transient_key, $result, 12 * HOUR_IN_SECONDS );
    return $result;
}

// ==============================================================================
// 2. ADMIN SETTINGS PAGE
// ==============================================================================

add_action( 'admin_menu', 'softy_layouts_add_admin_menu' );
function softy_layouts_add_admin_menu() {
    add_options_page(
        'Softy Layouts License',
        'Softy Layouts',
        'manage_options',
        'softy-layouts-license',
        'softy_layouts_options_page'
    );
}

function softy_layouts_options_page() {
    // Handle form save
    if ( isset( $_POST['softy_layouts_save_license'] ) && check_admin_referer( 'softy_layouts_save_nonce' ) ) {
        $license_key = sanitize_text_field( $_POST['softy_layouts_license_key'] );
        update_option( 'softy_layouts_license_key', $license_key );
        
        // Force an API check immediately upon saving
        $verification = softy_layouts_verify_license( $license_key, true );
        
        if ( $verification['valid'] ) {
            echo '<div class="notice notice-success is-dismissible"><p>License activated successfully!</p></div>';
        } else {
            echo '<div class="notice notice-error is-dismissible"><p>Error: ' . esc_html( $verification['message'] ) . '</p></div>';
        }
    }

    $current_key = get_option( 'softy_layouts_license_key', '' );
    ?>
    <div class="wrap">
        <h1>Softy Layouts Configuration</h1>
        <form method="post" action="">
            <?php wp_nonce_field( 'softy_layouts_save_nonce' ); ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">License Key</th>
                    <td>
                        <input type="text" name="softy_layouts_license_key" value="<?php echo esc_attr( $current_key ); ?>" class="regular-text" autocomplete="off" />
                        <p class="description">Enter the license key provided for this domain to unlock the plugin features.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button( 'Save License', 'primary', 'softy_layouts_save_license' ); ?>
        </form>
    </div>
    <?php
}

// ==============================================================================
// 3. PLUGIN INITIALIZATION & ENFORCEMENT
// ==============================================================================

add_action( 'plugins_loaded', 'softy_layouts_init' );
function softy_layouts_init() {
    $license_key = get_option( 'softy_layouts_license_key' );
    
    // If no key is saved, show a warning and do not load core features
    if ( ! $license_key ) {
        add_action( 'admin_notices', 'softy_layouts_no_key_notice' );
        return;
    }

    // Verify the key
    $status = softy_layouts_verify_license( $license_key );

    // If valid, load the plugin's core functionalities
    if ( $status['valid'] ) {
        // Disable Gutenberg for posts, pages, and custom post types
        add_filter( 'use_block_editor_for_post', '__return_false', 10 );
        // Disable the Gutenberg block editor for Widgets
        add_filter( 'use_widgets_block_editor', '__return_false' );

        // Enqueue CSS and scripts
        add_action( 'wp_enqueue_scripts', 'softy_layouts_enqueue_frontend_styles' );
        add_filter( 'mce_css', 'softy_layouts_add_editor_styles' );
        add_action( 'admin_head', 'softy_layouts_add_tinymce_plugin' );
    } else {
        // If invalid or expired, show an error and do not load core features
        add_action( 'admin_notices', function() use ( $status ) {
            echo '<div class="notice notice-error"><p><strong>Softy Layouts Authorization Failed:</strong> ' . esc_html( $status['message'] ) . '</p></div>';
        });
    }
}

function softy_layouts_no_key_notice() {
    echo '<div class="notice notice-warning"><p><strong>Softy Layouts</strong> requires a valid license key to function. Please <a href="' . esc_url( admin_url( 'options-general.php?page=softy-layouts-license' ) ) . '">enter it here</a>.</p></div>';
}

// ==============================================================================
// 4. CORE PLUGIN FEATURES (Only execute if authorized)
// ==============================================================================

// 1. Enqueue CSS on the frontend so the layouts look exactly like the editor
function softy_layouts_enqueue_frontend_styles() {
    wp_enqueue_style( 'softy-layouts-css', plugins_url( 'css/softy-style.css', __FILE__ ), array(), '1.0' );
}

// 2. Load the same CSS inside the TinyMCE editor for true WYSIWYG
function softy_layouts_add_editor_styles( $mce_css ) {
    $css_url = plugins_url( 'css/softy-style.css', __FILE__ );
    
    if ( ! empty( $mce_css ) ) {
        $mce_css .= ',';
    }
    $mce_css .= $css_url;
    
    return $mce_css;
}

// 3. Hook into TinyMCE to add our custom plugin and button
function softy_layouts_add_tinymce_plugin() {
    global $typenow;
    
    // Only load on post and page edit screens
    if ( ! in_array( $typenow, array( 'post', 'page', 'product' ) ) ) {
        return;
    }
    
    // Check if rich editing is enabled by the user
    if ( get_user_option( 'rich_editing' ) == 'true' ) {
        add_filter( 'mce_external_plugins', 'softy_layouts_add_tinymce_js' );
        add_filter( 'mce_buttons', 'softy_layouts_register_tinymce_button' );
    }
}

// 4. Register the button in the primary toolbar
function softy_layouts_register_tinymce_button( $buttons ) {
    array_push( $buttons, 'softy_elements_button' );
    return $buttons;
}

// 5. Point to the JavaScript file handling the TinyMCE dropdown
function softy_layouts_add_tinymce_js( $plugin_array ) {
    $plugin_array['softy_elements'] = plugins_url( 'js/softy-tinymce.js', __FILE__ );
    return $plugin_array;
}