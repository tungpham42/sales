(function () {
  // Changed "gb_elements" to "softy_elements" to match the PHP file registration
  tinymce.PluginManager.add("softy_elements", function (editor, url) {
    // Changed "gb_elements_button" to "softy_elements_button" to match the PHP file
    editor.addButton("softy_elements_button", {
      text: "SOFTY Layouts",
      icon: false,
      type: "menubutton",
      menu: [
        {
          text: "Intro Text (Sapo)",
          onclick: function () {
            editor.insertContent('<p class="softy-sapo">Giới thiệu</p>');
          },
        },
        {
          text: "Table of Contents",
          onclick: function () {
            editor.insertContent(
              '<div class="softy-toc">' +
                '<p class="softy-toc-title">Mục lục nội dung</p>' +
                '<ul class="softy-toc-list">' +
                '<li><a href="#section1">1. Tiêu đề 1</a></li>' +
                '<li><a href="#section2">2. Tiêu đề 2</a></li>' +
                "</ul>" +
                "</div><p>&nbsp;</p>",
            );
          },
        },
        {
          text: "Multi-Sectoral CTA (Blog)",
          onclick: function () {
            editor.insertContent(
              '<div class="softy-cta-multi">' +
                '<div class="softy-cta-multi-badge">ĐÀO TẠO THỰC CHIẾN</div>' +
                '<div class="softy-cta-multi-img-col">' +
                // Removed data-mce-* attributes from the image tag
                '<img class="alignnone size-full wp-image-41137" src="/wp-content/uploads/2026/07/placeholder.jpg" alt="Placeholder" width="300" height="200">' +
                '<p class="softy-cta-multi-img-caption">Chương trình tối ưu</p>' +
                "</div>" +
                '<div class="softy-cta-multi-content-col">' +
                "<div>" +
                '<h3 class="softy-cta-multi-title">Khóa học SEO Website - Đào tạo SEO Online</h3>' +
                '<p class="softy-cta-multi-text">Bứt phá thứ hạng bền vững bằng việc ứng dụng tư duy Phễu nội dung (Content Funnel) kết hợp công nghệ AI (công thức C.R.E.A.T.E). Đào tạo thực chiến đo lường hiệu quả chuyển đổi thực tế.</p>' +
                "</div>" +
                "<div>" +
                '<hr class="softy-cta-multi-divider" />' +
                '<div class="softy-cta-multi-footer">' +
                '<p class="softy-cta-multi-price">Hotline: 0878.18.78.78</p>' +
                '<a href="#" class="softy-cta-multi-btn">ĐĂNG KÝ HỌC</a>' +
                "</div>" +
                "</div>" +
                "</div>" +
                "</div><p>&nbsp;</p>",
            );
          },
        },
        {
          text: "Category CTA",
          onclick: function () {
            editor.insertContent(
              '<div class="softy-cta-category">' +
                '<div class="softy-cta-category-badge">ƯU ĐÃI THÁNG NÀY</div>' +
                '<div class="softy-cta-category-flex">' +
                '<div class="softy-cta-category-img-wrap">' +
                // Removed data-mce-* attributes from the image tag
                '<img class="alignnone size-full wp-image-41137" src="/wp-content/uploads/2026/07/placeholder.jpg" alt="Placeholder" width="300" height="200">' +
                "</div>" +
                '<div class="softy-cta-category-content">' +
                '<h3 class="softy-cta-category-title">Dịch vụ</h3>' +
                '<p class="softy-cta-category-text">Giải pháp đột phá giúp doanh nghiệp xây dựng phễu bán hàng tự động, tối ưu hóa ROI tối đa và loại bỏ hoàn toàn các chỉ số traffic ảo.</p>' +
                '<div class="softy-cta-category-divider"></div>' +
                '<div class="softy-cta-category-footer">' +
                '<span class="softy-cta-category-price">Đo lường minh bạch</span>' +
                '<a href="#" class="softy-cta-category-btn">LIÊN HỆ NGAY</a>' +
                "</div>" +
                "</div>" +
                "</div>" +
                "</div><p>&nbsp;</p>",
            );
          },
        },
        {
          text: "Best-Selling Product",
          onclick: function () {
            editor.insertContent(
              '<div class="softy-product-best">' +
                '<div class="softy-product-best-img-wrap">' +
                // Removed data-mce-* attributes from the image tag
                '<img class="alignnone size-full wp-image-41137" src="/wp-content/uploads/2026/07/placeholder.jpg" alt="Placeholder" width="300" height="200">' +
                "</div>" +
                '<div class="softy-product-best-content">' +
                '<h3 class="softy-product-best-title">Dịch vụ SEO Website Chuyển đổi</h3>' +
                '<p class="softy-product-best-text">Thiết kế quy trình SEO đồng hành tối ưu hóa chuyển đổi, giúp website của doanh nghiệp bứt phá thứ hạng từ khóa ra đơn hàng thực tế.</p>' +
                '<div class="softy-product-best-divider"></div>' +
                '<div class="softy-product-best-footer">' +
                '<span class="softy-product-best-price">Liên hệ tư vấn</span>' +
                '<a href="#" class="softy-product-best-btn">XEM CHI TIẾT</a>' +
                "</div>" +
                "</div>" +
                "</div><p>&nbsp;</p>",
            );
          },
        },
        {
          text: "Cross-Sell Box (Product)",
          onclick: function () {
            editor.insertContent(
              '<div class="softy-cross-sell">' +
                '<span class="softy-cross-sell-badge">COMBO KHUYẾN NGHỊ</span>' +
                '<div class="softy-cross-sell-img-wrap">' +
                // Removed data-mce-* attributes from the image tag
                '<img class="alignnone size-full wp-image-41137" src="/wp-content/uploads/2026/07/placeholder.jpg" alt="Placeholder" width="300" height="200">' +
                "</div>" +
                '<div class="softy-cross-sell-content">' +
                '<h3 class="softy-cross-sell-title">Khóa học SEO Website</h3>' +
                '<p class="softy-cross-sell-text">Kết hợp kiến thức lý thuyết và thực thi giúp doanh nghiệp hoàn toàn tự vận hành hệ thống SEO chuyển đổi nội bộ hiệu quả.</p>' +
                '<div class="softy-cross-sell-divider"></div>' +
                '<div class="softy-cross-sell-footer">' +
                '<span class="softy-cross-sell-price">Tối ưu hóa ROI</span>' +
                '<a href="#" class="softy-cross-sell-btn">MUA KÈM NGAY</a>' +
                "</div>" +
                "</div>" +
                "</div><p>&nbsp;</p>",
            );
          },
        },
        {
          text: "Read More Section",
          onclick: function () {
            editor.insertContent(
              '<div class="softy-read-more">' +
                '<p class="softy-read-more-title">' +
                '<img draggable="false" role="img" class="emoji" alt="🔍" src="https://s.w.org/images/core/emoji/17.0.2/svg/1f50d.svg" /> ' +
                "Đọc thêm các bài viết tư vấn chuyên sâu:" +
                "</p>" +
                '<ul class="softy-read-more-list">' +
                '<li><strong><a href="https://giftbusiness.vn/tin-tuc/tang-qua-sinh-nhat-y-nghia/">Quà sinh nhật tặng gì?</a> 30+ gợi ý quà tặng HOT, dễ trúng tim người nhận nhất</strong></li>' +
                '<li><strong>Khám phá 20+ <a href="https://giftbusiness.vn/tin-tuc/qua-tang-tot-nghiep-dai-hoc/">quà tặng tốt nghiệp đại học</a> cho nam nữ ý nghĩa, tối ưu ngân sách</strong></li>' +
                '<li><strong>Tổng hợp 20+ món <a href="https://giftbusiness.vn/tin-tuc/qua-cong-nghe-cho-nam/">quà công nghệ cho nam</a> Hot-hit đột phá xu hướng 2026</strong></li>' +
                "</ul>" +
                "</div><p>&nbsp;</p>",
            );
          },
        },
      ],
    });
  });
})();
